# M-AI owned English phoneme audio

Canonical destination for independently recorded M-AI phoneme masters.
Do not copy third-party audio into this folder.
Production upload contract: `/assets/audio/phonemes/en-US/mai-owned/<fileName>` and update the phoneme manifest through the server upload service.
The v344 static prototype stores uploaded test audio in browser localStorage as a data URL so the replacement flow can be tested without a backend. Runtime automatically prefers an approved M-AI override and otherwise falls back to the existing external reference.
