# M-AI Học centralized English phoneme audio registry — v394

All isolated English phoneme playback resolves through `assets/js/maihoc-phoneme-audio.js` (`window.MAIHOC_PHONEME_AUDIO`). Lessons, Sage, questions, games, and tests store only a stable `phonemeKey`; they must not own phoneme URLs.

Resolution order:
1. M-AI-owned recording uploaded/activated by Super Admin (stable override key `maihoc.phoneme.owned.overrides.v344`).
2. Verified exact-match external fallback in the central registry.

The primary external fallback is University of Hamburg, Explorations in English Language Learning, “All English phonemes”. Grade 1 v394 uses Hamburg exact recordings for /b k æ d ɪ e g h m ʌ l n t f w/. The Grade 1 /ɒ/ target uses a separately verified exact-/ɒ/ fallback because Hamburg's table does not publish an audio file for its low-back /ɑ/ row.

Never use TTS to speak IPA symbols. Never approximate one phoneme with another. Super Admin replacement changes only the registry override; content code remains unchanged.
