(()=>{'use strict';
const KEY='maihoc.questionbank.overrides.v204';
const clone=x=>JSON.parse(JSON.stringify(x));
function base(){return window.MAIHOC_QB_INDEX||{}}
function overrides(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch{return{}}}
function save(o){localStorage.setItem(KEY,JSON.stringify(o));return o}
function all(grade){const b=base(),o=overrides(),grades=grade?[String(grade)]:Object.keys(b);let out=[];grades.forEach(g=>{const m=new Map((b[g]||[]).map(q=>[q.id,{...clone(q),grade:+g,status:'published',source:'canonical'}]));Object.values(o).filter(q=>String(q.grade)===g).forEach(q=>{if(q._deleted)m.delete(q.id);else m.set(q.id,{...clone(q),source:'override'})});out.push(...m.values())});return out}
function get(id){return all().find(q=>q.id===id)||null}
function upsert(q){if(!q||!q.id||!q.grade)throw Error('Question ID and grade are required.');const o=overrides();o[q.id]={...(get(q.id)||{}),...clone(q),updatedAt:new Date().toISOString(),_deleted:false};save(o);return get(q.id)}
function remove(id){const q=get(id);if(!q)return false;const o=overrides();o[id]={...q,_deleted:true,updatedAt:new Date().toISOString()};save(o);return true}
function bulk(ids,patch){ids.forEach(id=>{const q=get(id);if(q)upsert({...q,...clone(patch)})});return ids.length}
function bulkDelete(ids){ids.forEach(remove);return ids.length}
function filters(){const a=all();return{grades:[...new Set(a.map(q=>q.grade))].sort((a,b)=>a-b),skills:[...new Set(a.map(q=>q.skill).filter(Boolean))].sort(),questionTypes:[...new Set(a.map(q=>q.questionType).filter(Boolean))].sort()}}
window.MAIHOC_QUESTION_BANK={KEY,all,get,upsert,remove,bulk,bulkDelete,filters,overrides};
})();
