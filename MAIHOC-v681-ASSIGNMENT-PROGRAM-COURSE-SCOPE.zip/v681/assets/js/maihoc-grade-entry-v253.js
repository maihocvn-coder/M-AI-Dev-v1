(()=>{'use strict';
const qs=()=>new URLSearchParams(location.search);
const grade=()=>+(location.pathname.match(/grade(\d+)/i)?.[1]||0);
const isPlay=()=>/\/student\/my-school-english\/grade\d+\/engine\/play\.html$/i.test(location.pathname);
const explicitActivity=()=>{const p=qs();return ['knowledge','practice','play','test'].includes(p.get('mode'))||p.get('activity')||p.get('assignment_id')};
function go(level,mode){const p=qs();p.set('level',String(level||1));p.set('mode',mode);p.set('start','1');location.search='?'+p.toString()}
function install(){
 if(!isPlay()||explicitActivity())return;
 const g=grade(), level=Math.max(1,+(qs().get('level')||1));
 const interaction=document.getElementById('interaction'); if(!interaction)return;
 interaction.dataset.orientation='true';
 interaction.innerHTML=`<div class="question-head"><span class="pill">GRADE ${g}</span><span>CHỌN CÁCH BẮT ĐẦU</span></div>
 <h3>Em đang học Unit/Level nào ở trường?</h3>
 <div class="stimulus" style="display:block">Chọn Level ở <b>Bản đồ cấp độ</b> bên trái. Em có thể vào đúng Unit lớp đang học dù Level trước chưa hoàn thành. Sau khi chọn Level, hãy chọn một hoạt động bên dưới.</div>
 <div class="answers" id="mhEntryActivities">
  <button data-entry="knowledge">📖 Học kiến thức</button><button data-entry="practice">✍️ Luyện 10 câu</button>
  <button data-entry="play">🎮 Chơi Level</button><button data-entry="test">🎯 Bài luyện kiểm tra</button>
 </div><div class="under"><span>Level đang chọn: <b id="mhSelectedLevel">${String(level).padStart(2,'0')}</b></span></div>`;
 interaction.querySelectorAll('[data-entry]').forEach(b=>b.onclick=()=>go(level,b.dataset.entry));
 // Orientation replaces the interaction DOM, so the persistent left-rail activity buttons
 // must navigate to a fresh runtime URL instead of calling game.js against removed nodes.
 document.querySelectorAll('#modes [data-mode]').forEach(b=>{
   b.onclick=(ev)=>{ev.preventDefault();ev.stopImmediatePropagation();go(level,b.dataset.mode)};
 });
 const status=document.getElementById('sceneStatus'); if(status)status.textContent='Chọn Level bên trái, rồi chọn Học · Luyện · Chơi · Kiểm tra.';
 const prompt=document.getElementById('prompt'); if(prompt)prompt.textContent='';
 const skill=document.getElementById('questionSkill'); if(skill)skill.textContent='BẮT ĐẦU';
 const num=document.getElementById('questionNumber'); if(num)num.textContent='CHƯA CÓ CÂU HỎI';
 // Level Map is navigation-only while orientation is active: choose level, never auto-launch a question.
 document.querySelectorAll('#levelList .level,[data-level]').forEach((b,i)=>{b.onclick=(ev)=>{ev.preventDefault();const n=+(b.dataset.level||b.querySelector('.level-num')?.textContent||i+1);const p=qs();p.set('level',String(n));p.delete('mode');p.delete('start');location.search='?'+p.toString()}});
 // Sage must be visible on orientation and explain the flow, not pretend a question is active.
 const sage=document.getElementById('sageFloat'), body=document.getElementById('sageBody');
 if(sage){sage.dataset.collapsed='false';sage.dataset.orientation='true'}
 if(body)body.innerHTML=`<div class="sage-context">Sage · Bắt đầu học</div><div class="sage-card"><b>👋 Chọn đúng bài em đang học nhé</b><p>1. Chọn <b>Level/Unit</b> ở bản đồ bên trái.<br>2. Chọn <b>Học kiến thức</b>, <b>Luyện 10 câu</b>, <b>Chơi Level</b> hoặc <b>Bài luyện kiểm tra</b>.<br>Em không cần hoàn thành Level trước mới được vào Unit lớp đang học.</p></div>`;
 }
 addEventListener('DOMContentLoaded',()=>setTimeout(install,0));
 window.MAIHOC_GRADE_ENTRY={install,explicitActivity,go};
})();