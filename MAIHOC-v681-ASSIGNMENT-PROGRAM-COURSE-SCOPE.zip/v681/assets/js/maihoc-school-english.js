(()=>{'use strict';
/* M-AI School English canonical runtime — shared Grades 1–12.
   Owns route/mode normalization, common state persistence/UI state, bag toggle,
   responsive navigation, and access to Admin-selected engine/character/scene config.
   Curriculum, questions, Sage teaching content and engine-specific rendering remain data/adapters. */
const path=location.pathname;
const match=path.match(/\/student\/my-school-english\/grade(\d+)\/engine\/play\.html$/i);
if(!match)return;
const grade=Number(match[1]);
const band=grade<=5?'primary':'secondary';
const qs=()=>new URLSearchParams(location.search);
const validModes=new Set(['knowledge','practice','play','test']);
function normalizeEntry(){
  const p=qs();
  const level=Math.max(1,Number(p.get('level')||p.get('unit'))||1);
  const explicit=validModes.has(p.get('mode'));
  if(!explicit){p.set('level',String(level));p.set('mode','play');history.replaceState(null,'','?'+p.toString())}
  return {grade,band,level,mode:validModes.has(p.get('mode'))?p.get('mode'):'play'};
}
const entry=normalizeEntry();
function safeRead(key,fallback={}){try{return JSON.parse(localStorage.getItem(key)||JSON.stringify(fallback))}catch{return fallback}}
function safeWrite(key,value){try{localStorage.setItem(key,JSON.stringify(value));return true}catch{return false}}
function createState({bank,storageKey,defaultSkill,extra={}}={}){
  const saved=safeRead(storageKey,{}), p=qs(), max=Math.max(1,bank?.levels?.length||1);
  const unit=Math.max(1,Math.min(max,Number(p.get('level')||p.get('unit'))||saved.unit||1));
  const mode=validModes.has(p.get('mode'))?p.get('mode'):(validModes.has(saved.mode)?saved.mode:'play');
  const visited=safeRead(`maihoc.schoolEnglish.g${grade}.visited`,{});
  return {unit,mode,index:0,queue:[],tries:0,hint:0,done:false,testScore:0,mastery:saved.mastery||{},visited,topicFilter:null,coins:saved.coins||0,...(defaultSkill?{skill:saved.skill||defaultSkill}:{}),...extra};
}
function saveState(storageKey,state,{persistMode=true,persistSkill=true}={}){
  const out={unit:state.unit,mastery:state.mastery,coins:state.coins};
  if(persistMode)out.mode=state.mode;
  if(persistSkill&&'skill' in state)out.skill=state.skill;
  safeWrite(storageKey,out);
}
function syncModeUI(mode){
  document.body.classList.toggle('game-mode-play',mode==='play');
  document.body.classList.toggle('game-mode-content',mode!=='play');
  document.querySelectorAll('#modes [data-mode]').forEach(b=>b.classList.toggle('selected',b.dataset.mode===mode));
}
function setupBag(){
  const p=document.getElementById('adventurePouch'),pt=document.getElementById('pouchToggle');if(!p)return;
  if(!document.getElementById('pouchRecent')){const recent=document.createElement('div');recent.id='pouchRecent';recent.className='pouch-recent';recent.setAttribute('aria-label','5 vật phẩm gần nhất');const coin=p.querySelector('.pouch-coin-badge');p.insertBefore(recent,coin||p.querySelector('#pouchItems'));}
  p.classList.remove('pouch-corner-mini','pouch-free-drag','pouch-free','pouch-movable','dock-left','dock-right','dock-bottom');p.removeAttribute('style');p.classList.add('collapsed');
  if(!pt)return;pt.setAttribute('aria-expanded','false');pt.setAttribute('aria-label','Mở túi đồ');pt.style.cursor='pointer';
  pt.onclick=()=>{const collapsed=p.classList.toggle('collapsed');pt.setAttribute('aria-expanded',String(!collapsed));pt.setAttribute('aria-label',collapsed?'Mở túi đồ':'Thu gọn túi đồ');const ch=document.getElementById('pouchChevron');if(ch)ch.textContent=collapsed?'▸':'▾'};
}
function currentConfig(unit){
  const R=window.MAIHOC_GAME_REGISTRY;if(!R)return null;const c=R.get(grade,unit||entry.level);
  return {engineId:c.engineId||c.engine,characterId:c.characterId||c.character,sceneId:c.sceneId||c.scene||c.world,questionBanks:c.questionBanks||[]};
}
function installResponsiveNav(){
  const root=document.documentElement,aside=document.querySelector('.layout > aside');if(!aside)return;
  const removeToggle=()=>{document.querySelector('.mh-side-toggle')?.remove();document.querySelector('.mh-side-backdrop')?.remove();root.classList.remove('mh-side-open')};
  const isPublicPreview=()=>new URLSearchParams(location.search).get('preview')==='1'||document.body?.classList.contains('mh-public-game-preview');
  const apply=()=>{
    const compact=['phone','narrow'].includes(root.dataset.mhLayout);
    if(!compact){removeToggle();return}
    if(isPublicPreview()){removeToggle();return;}
    let btn=document.querySelector('.mh-side-toggle'),shade=document.querySelector('.mh-side-backdrop');
    if(btn)return;
    btn=document.createElement('button');btn.type='button';btn.className='mh-side-toggle';btn.setAttribute('aria-label','Mở điều hướng');btn.setAttribute('aria-expanded','false');btn.innerHTML='<span aria-hidden="true">☰</span>';btn.setAttribute('title','Học & Chơi');
    shade=document.createElement('div');shade.className='mh-side-backdrop';document.body.append(btn,shade);
    const close=()=>{root.classList.remove('mh-side-open');btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-label','Mở điều hướng')};
    btn.onclick=()=>{const open=!root.classList.contains('mh-side-open');root.classList.toggle('mh-side-open',open);btn.setAttribute('aria-expanded',String(open));btn.setAttribute('aria-label',open?'Đóng điều hướng':'Mở điều hướng')};
    shade.onclick=close;aside.addEventListener('click',e=>{if(e.target.closest('button.level,#modes button'))close()});
  };
  aside.querySelector('.mh-side-resizer')?.remove();apply();window.addEventListener('maihoc:responsive',apply);
}

function installLevelNavigation(){
  const list=document.getElementById('levelList');if(!list||list.dataset.mseSharedLevelNav==='1')return;
  list.dataset.mseSharedLevelNav='1';
  list.addEventListener('click',e=>{
    const button=e.target.closest('button.level');if(!button||!list.contains(button))return;
    const buttons=[...list.querySelectorAll('button.level')];
    const level=Number(button.dataset.level||button.querySelector('.level-num')?.textContent||buttons.indexOf(button)+1)||1;
    const nav=window.MAIHOC_NAVIGATE_UNIT;
    if(typeof nav!=='function')return;
    e.preventDefault();e.stopImmediatePropagation();
    nav(level);
  },true);
}
function rememberActivity(state){safeWrite('maihoc.student.lastSelfStudyActivity',{programId:'m-ai-school-english',grade,level:state.unit,mode:state.mode,updatedAt:new Date().toISOString()})}
function go(level,mode='play'){const p=qs();p.set('level',String(level||1));p.set('mode',validModes.has(mode)?mode:'play');p.set('start','1');location.search='?'+p.toString()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{installResponsiveNav();installLevelNavigation()},{once:true});else{installResponsiveNav();installLevelNavigation()}
setTimeout(installLevelNavigation,80);
document.documentElement.dataset.mseGrade=String(grade);document.documentElement.dataset.mseBand=band;

// Canonical School English reward-object service (G1-G12).
// Correct answers collect a visual object (image/emoji), never answer text.
const REWARD_ASSET_WORDS=new Set(["lucy","nick","wendy","apple","bag","ball","bananas","bell","bike","book","bus","cake","can","car","cat","chicken","chips","clocks","cup","desk","dog","door","duck","face","father","fish","foot","football","garden","gate","girl","goat","hair","hand","hat","head","horse","lake","leaf","lemons","locks","mango","milk","monkey","mops","mother","mouse","noodles","nuts","pen","pencil","pots","red","running","sun","teddy bear","tiger","top","truck","turtle","washing","water","window"]);
const REWARD_EMOJI={apple:'🍎',bag:'🎒',ball:'⚽',bell:'🔔',bike:'🚲',book:'📘',bus:'🚌',cake:'🎂',car:'🚗',cat:'🐱',chicken:'🐔',cup:'🥤',desk:'🪑',dog:'🐶',door:'🚪',duck:'🦆',fish:'🐟',football:'⚽',garden:'🌱',girl:'👧',goat:'🐐',hat:'🧢',horse:'🐴',lake:'💧',leaf:'🍃',milk:'🥛',monkey:'🐵',mouse:'🐭',pen:'🖊️',pencil:'✏️',sun:'☀️',tiger:'🐯',truck:'🚚',turtle:'🐢',water:'💧',window:'🪟',school:'🏫',home:'🏠',house:'🏠',room:'🚪',chair:'🪑',table:'🪑',phone:'📱',computer:'💻',music:'🎵',food:'🍽️',tree:'🌳',flower:'🌼',star:'⭐'};
// Shared semantic collectibles for abstract/social language. Ordered: specific phrases before broad words.
const REWARD_SEMANTIC_RULES=[
  {tests:[/\bnice to meet you\b/,/\bpleased to meet you\b/],label:'handshake',icon:'🤝'},
  {tests:[/\bgood morning\b/],label:'morning sun',icon:'☀️'},
  {tests:[/\bgood night\b/],label:'moon',icon:'🌙'},
  {tests:[/\bgood afternoon\b/],label:'afternoon sun',icon:'🌤️'},
  {tests:[/\bgood evening\b/],label:'evening sky',icon:'🌆'},
  {tests:[/\bthank you\b/,/\bthanks\b/],label:'thank-you flower',icon:'💐'},
  {tests:[/\bi(?:'|’)m sorry\b/,/\bsorry\b/],label:'kind heart',icon:'❤️'},
  {tests:[/\bplease\b/],label:'kindness flower',icon:'🌼'},
  {tests:[/\bhow are you\b/,/\bi(?:'|’)m fine\b/,/\bi am fine\b/],label:'happy face',icon:'🙂'},
  {tests:[/\bmy name is\b/,/\bi(?:'|’)m [a-z]+\b/,/\bi am [a-z]+\b/],label:'name badge',icon:'📛'},
  {tests:[/\bgoodbye\b/,/\bbye(?:-bye)?\b/,/\bsee you\b/],label:'goodbye wave',icon:'👋'},
  {tests:[/\bhello\b/,/\bhi\b/,/\bhey\b/],label:'hello wave',icon:'👋'},
  {tests:[/\byes\b/],label:'yes badge',icon:'✅'},
  {tests:[/\bno\b/],label:'no badge',icon:'⭕'}
];
const REWARD_GENERIC_FALLBACKS=[
  {label:'learning star',icon:'⭐'},
  {label:'achievement gem',icon:'💎'},
  {label:'achievement medal',icon:'🏅'},
  {label:'sparkle token',icon:'✨'},
  {label:'discovery badge',icon:'🏵️'}
];
function rewardSlug(v){return String(v||'').trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}
function rootUrl(path){try{return new URL(path,document.baseURI.replace(/student\/my-school-english\/grade\d+\/engine\/.*$/,'' )).href}catch{return path}}
function rewardAsset(v){const k=String(v||'').trim().toLowerCase();return REWARD_ASSET_WORDS.has(k)?rootUrl('assets/rewards/vocab/'+rewardSlug(k)+'.svg'):null}
function semanticReward(source){const low=String(source||'').toLowerCase();for(const rule of REWARD_SEMANTIC_RULES){if(rule.tests.some(rx=>rx.test(low)))return {label:rule.label,asset:null,icon:rule.icon}}return null}
function genericReward(index=0){const r=REWARD_GENERIC_FALLBACKS[Math.abs(Number(index)||0)%REWARD_GENERIC_FALLBACKS.length];return {...r,asset:null}}
function resolveRewardObject(q,{fallbackIndex=0}={}){
  if(q?.rewardObject&&typeof q.rewardObject==='object'){
    const label=String(q.rewardObject.label||q.rewardObject.id||q.rewardObject.name||'reward').trim();
    return {label,asset:q.rewardObject.asset||rewardAsset(label),icon:q.rewardObject.icon||REWARD_EMOJI[label.toLowerCase()]||genericReward(fallbackIndex).icon};
  }
  const explicit=typeof q?.rewardObject==='string'?q.rewardObject:'';
  const answer=String(q?.options?.[q.answer]||q?.correctEvidence||'').trim();
  const sources=[explicit,answer,String(q?.prompt||''),String(q?.stimulus||''),String(q?.context||'')].filter(Boolean);
  // 1) Explicit/concrete visual objects always win.
  for(const source of sources){
    const low=source.toLowerCase();
    const exact=rewardAsset(low);if(exact)return {label:low,asset:exact,icon:REWARD_EMOJI[low]||genericReward(fallbackIndex).icon};
    const words=low.replace(/[^a-z0-9'-]+/g,' ').split(/\s+/).filter(Boolean);
    for(const word of words){if(REWARD_ASSET_WORDS.has(word))return {label:word,asset:rewardAsset(word),icon:REWARD_EMOJI[word]||genericReward(fallbackIndex).icon};if(REWARD_EMOJI[word])return {label:word,asset:null,icon:REWARD_EMOJI[word]}}
  }
  // 2) Abstract/social language gets a meaningful collectible instead of a gift box.
  for(const source of sources){const semantic=semanticReward(source);if(semantic)return semantic}
  // 3) Last resort rotates neutral achievement objects; never repeat generic gift boxes.
  return genericReward(fallbackIndex);
}
function normalizeRewardItem(x,index=0){
  if(!x)return null;
  if(typeof x==='object'){
    const label=String(x.label||x.name||'reward object');
    if(label==='reward object'&&(!x.asset)&&(!x.icon||x.icon==='🎁'))return genericReward(index);
    return {label,asset:x.asset||rewardAsset(label),icon:x.icon||REWARD_EMOJI[label.toLowerCase()]||genericReward(index).icon};
  }
  const label=String(x).trim();if(!label||['⭐','✨','★','✦'].includes(label))return null;
  if(label==='reward object'||label==='🎁')return genericReward(index);
  return {label,asset:rewardAsset(label),icon:REWARD_EMOJI[label.toLowerCase()]||genericReward(index).icon};
}
function rewardNode(item,cls='pouch-icon'){item=normalizeRewardItem(item)||genericReward(0);const s=document.createElement('span');s.className=cls;s.title=item.label;s.setAttribute('aria-label',item.label);s.dataset.object=item.label;if(item.asset){const img=document.createElement('img');img.src=item.asset;img.alt=item.label;img.className='reward-object-image';s.append(img)}else{s.textContent=item.icon||genericReward(0).icon}return s}
function readRewardBag(key,withCoins=false){try{const raw=JSON.parse(localStorage.getItem(key)||(withCoins?'{"items":[],"coins":0}':'[]'));if(withCoins){return {items:(Array.isArray(raw)?raw:raw.items||[]).map((x,i)=>normalizeRewardItem(x,i)).filter(Boolean),coins:Number(raw?.coins)||0}}return (Array.isArray(raw)?raw:raw.items||[]).map((x,i)=>normalizeRewardItem(x,i)).filter(Boolean)}catch{return withCoins?{items:[],coins:0}:[]}}
function renderRewardBag({key,withCoins=false,emptyText='Trả lời đúng để nhặt đồ nhé!'}){const box=document.getElementById('pouchItems');if(!box)return;const d=readRewardBag(key,withCoins),items=withCoins?d.items:d;try{localStorage.setItem(key,JSON.stringify(withCoins?{items,coins:d.coins}:items))}catch{};const count=document.getElementById('pouchCount');if(count)count.textContent='';let recent=document.getElementById('pouchRecent');if(!recent){recent=document.createElement('div');recent.id='pouchRecent';recent.className='pouch-recent';recent.setAttribute('aria-label','5 vật phẩm gần nhất');const p=document.getElementById('adventurePouch'),coin=p?.querySelector('.pouch-coin-badge');p?.insertBefore(recent,coin||box)}recent.replaceChildren();items.slice(-5).forEach(x=>recent.append(rewardNode(x,'pouch-recent-object')));box.replaceChildren();if(!items.length){const e=document.createElement('span');e.textContent=emptyText;box.append(e)}else items.forEach(x=>box.append(rewardNode(x)));if(withCoins){const badge=document.getElementById('pouchCoins');if(badge)badge.textContent=String(d.coins||0)}}
function collectRewardObject(q,{key,withCoins=false,coinGain=0,emptyText,source}={}){if(!key)return null;const d=readRewardBag(key,withCoins),items=withCoins?d.items:d,item=resolveRewardObject(q,{fallbackIndex:items.length});items.push(item);if(items.length>40)items.splice(0,items.length-40);if(withCoins)d.coins=(d.coins||0)+(Number(coinGain)||0);try{localStorage.setItem(key,JSON.stringify(withCoins?d:items))}catch{};const p=document.getElementById('adventurePouch'),src=source||document.querySelector('#answers .correct')||document.getElementById('obstacle');if(src&&p){const a=src.getBoundingClientRect(),b=p.getBoundingClientRect(),fly=rewardNode(item,'loot-fly');fly.style.left=(a.left+a.width/2)+'px';fly.style.top=(a.top+a.height/2)+'px';fly.style.setProperty('--loot-x',(b.left+b.width/2-a.left-a.width/2)+'px');fly.style.setProperty('--loot-y',(b.top+b.height/2-a.top-a.height/2)+'px');document.body.append(fly);setTimeout(()=>fly.remove(),850)}setTimeout(()=>renderRewardBag({key,withCoins,emptyText}),500);p?.classList.add('got-item');setTimeout(()=>p?.classList.remove('got-item'),650);return item}

window.MAIHOC_SCHOOL_ENGLISH={grade,band,entry,validModes,safeRead,safeWrite,createState,saveState,syncModeUI,setupBag,currentConfig,rememberActivity,go,installResponsiveNav,installLevelNavigation,resolveRewardObject,rewardNode,readRewardBag,renderRewardBag,collectRewardObject};
})();
