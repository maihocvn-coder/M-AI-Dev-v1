(()=>{'use strict';
const KEY='maihoc.relationships.v177',LEGACY='maihoc.relationships.v130',PROFILE='maihoc.connection.profile.v177',LIMIT='maihoc.platform.limits.v130',COUP='maihoc.coupons.v130',REF='maihoc.referrals.v130',IMP='maihoc.impersonation.v130';
const defaults={maxClasses:10,maxTeachers:10,maxStudentsPerTeacher:20,maxFriends:10,referrals:'unlimited'};
const demoUsers=[
{id:'u-student',username:'minh6',email:'minh@example.test',name:'Minh Nguyễn',roles:['student'],connectionCode:'MINH-6A21'},
{id:'u-parent',username:'me.minh',email:'parent@example.test',name:'Hà Nguyễn',roles:['parent'],connectionCode:'HA-9P14'},
{id:'u-teacher',username:'mslan',email:'lan@example.test',name:'Ms. Lan',roles:['teacher','parent'],connectionCode:'LAN-4T28'},
{id:'u-admin',username:'sunshine.admin',email:'admin@sunshine.test',name:'Sample Organization Admin',roles:['admin','parent','student'],connectionCode:'SUN-7A30'}];
function read(k,f){try{return JSON.parse(localStorage.getItem(k)||JSON.stringify(f))}catch{return f}}
function write(k,v){localStorage.setItem(k,JSON.stringify(v));return v}
function limits(){return {...defaults,...read(LIMIT,{})}} function setLimits(v){return write(LIMIT,{...limits(),...v})}
function fresh(){return {links:[],invites:[],orgMembers:[],friends:[]}}
function state(){let s=read(KEY,null);if(!s){s=read(LEGACY,fresh());write(KEY,s)}return {...fresh(),...s}}
function save(v){return write(KEY,v)}
function profile(){let p=read(PROFILE,null);if(!p){p={id:'current',username:'my.account',email:'me@example.test',name:'My M-AI Học Account',connectionCode:'MAI-'+Math.random().toString(36).slice(2,8).toUpperCase()};write(PROFILE,p)}return p}
function connectionUrl(){const p=profile(),code=encodeURIComponent(p.connectionCode);try{const path=location.pathname||'';const i=path.indexOf('/account/');const base=i>=0?path.slice(0,i+1):'/';return new URL(base+'account/connections/home.html?connect='+code,location.origin).href}catch{return 'maihoc://connect/'+code}}
function connectionPayload(){return connectionUrl()}
function search(q){q=String(q||'').trim().toLowerCase();if(!q)return[];return demoUsers.filter(u=>[u.username,u.email,u.name,u.connectionCode].some(x=>String(x).toLowerCase().includes(q)))}
function findByCode(code){const q=String(code||'').replace(/^maihoc:\/\/connect\//i,'').trim();return demoUsers.find(u=>u.connectionCode.toLowerCase()===decodeURIComponent(q).toLowerCase())||null}
function invite({from='current',to='',channel='username',relationship='family',context='family',toName=''}){const s=state(),id='inv-'+Date.now()+'-'+Math.random().toString(36).slice(2,6);s.invites.unshift({id,from,to,toName,channel,relationship,context,status:'pending',createdAt:Date.now()});save(s);return id}
function respond(id,status){const s=state(),x=s.invites.find(v=>v.id===id);if(!x)return false;x.status=status;if(status==='accepted'&&!s.links.some(l=>l.inviteId===id))s.links.unshift({id:'link-'+Date.now(),inviteId:id,a:x.from,b:x.to,bName:x.toName,relationship:x.relationship,context:x.context,createdAt:Date.now()});save(s);if(status==='accepted'&&x.relationship==='family'&&window.MAIHOC_RELATIONS){const U=MAIHOC_RELATIONS.users(),a=U.find(u=>u.id===x.from),b=U.find(u=>u.id===x.to);if(a&&b){const parent=a.roles?.includes('parent')?a.id:b.roles?.includes('parent')?b.id:null,child=a.roles?.includes('student')?a.id:b.roles?.includes('student')?b.id:null;if(parent&&child)MAIHOC_RELATIONS.linkFamily(parent,child,{sourceInviteId:id})}}return true}
function removeLink(id){const s=state();s.links=s.links.filter(x=>x.id!==id);save(s);return true}
function addFriend(userId){const s=state(),lim=limits().maxFriends;if(s.friends.filter(x=>x.owner==='current').length>=lim)return{ok:false,reason:'limit'};if(!s.friends.some(x=>x.owner==='current'&&x.userId===userId))s.friends.push({owner:'current',userId});save(s);return{ok:true}}
function referralCode(){let c=localStorage.getItem(REF+'.code');if(!c){c='MAI-'+Math.random().toString(36).slice(2,8).toUpperCase();localStorage.setItem(REF+'.code',c)}return c}
function referralEvent(referrer,newUser,unitCompleted){const a=read(REF,[]);a.push({referrer,newUser,unitCompleted,eligible:!!unitCompleted,pointsStatus:unitCompleted?'earned':'pending',at:Date.now()});return write(REF,a)}
function coupons(){return read(COUP,[])} function createCoupon(c){const a=coupons();a.unshift({id:'cp-'+Date.now(),active:true,uses:0,...c});return write(COUP,a)} function redeemCoupon(code){const a=coupons(),c=a.find(x=>x.active&&x.code.toLowerCase()===String(code).trim().toLowerCase());if(!c)return{ok:false};c.uses++;write(COUP,a);return{ok:true,coupon:c}}
function impersonate(targetRole,targetId){if(!['student','parent'].includes(targetRole))return{ok:false,reason:'role'};const rec={targetRole,targetId,learningOnly:targetRole==='student',paymentMode:targetRole==='parent'?'view_and_guide_only':'blocked',startedAt:Date.now()};write(IMP,rec);return{ok:true,rec}} function stopImpersonation(){localStorage.removeItem(IMP)}
window.MAIHOC_REL={demoUsers,limits,setLimits,state,profile,connectionPayload,connectionUrl,search,findByCode,invite,respond,removeLink,addFriend,referralCode,referralEvent,coupons,createCoupon,redeemCoupon,impersonate,stopImpersonation};
})();