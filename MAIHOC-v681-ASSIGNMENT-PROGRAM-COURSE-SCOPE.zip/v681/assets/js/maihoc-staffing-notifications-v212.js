(()=>{'use strict';
const AV='maihoc.teacher.availability.v212',NO='maihoc.notifications.v212',AN='maihoc.announcements.v212';
const get=(k,d)=>{try{return JSON.parse(localStorage.getItem(k)||'null')||d}catch{return d}},put=(k,v)=>(localStorage.setItem(k,JSON.stringify(v)),v),id=p=>p+'-'+Date.now()+'-'+Math.random().toString(36).slice(2,7);
function availability(){return get(AV,[])} function notifications(){return get(NO,[])} function announcements(){return get(AN,[])}
function saveAvailability(v){let a=availability(),i=a.findIndex(x=>x.id===v.id),n={...v,id:v.id||id('av'),updatedAt:new Date().toISOString()};i<0?a.push(n):a[i]={...a[i],...n};put(AV,a);scanTeacher(n.teacherId);return n}
function removeAvailability(x){put(AV,availability().filter(v=>v.id!==x))}
function overlaps(a,b,c,d){return new Date(a)<new Date(d)&&new Date(c)<new Date(b)}
function blocksFor(uid,start,end){return availability().filter(x=>x.teacherId===uid&&x.status!=='available'&&overlaps(x.start,x.end,start,end))}
function sessionConflicts(uid,start,end,ignoreId){const cal=window.MAIHOC_CAL?.load?.()||{sessions:[]};return cal.sessions.filter(s=>s.id!==ignoreId&&s.status!=='cancelled'&&(s.teacherId===uid||(s.teachingStaff||[]).some(t=>t.userId===uid))&&overlaps(s.start,s.end,start,end))}
function checkTeacher(uid,start,end,ignoreId){const b=blocksFor(uid,start,end),s=sessionConflicts(uid,start,end,ignoreId);return{ok:!b.length&&!s.length,blocks:b,sessions:s,reason:b.length?'Teacher not available':s.length?'Teacher already assigned to another session':''}}
function notify(v){let a=notifications();const dedupe=v.dedupeKey&&a.find(x=>x.dedupeKey===v.dedupeKey&&!x.resolved);if(dedupe)return dedupe;const n={id:id('n'),createdAt:new Date().toISOString(),read:false,resolved:false,...v};a.unshift(n);put(NO,a);return n}
function forUser(uid,role,orgId){return notifications().filter(n=>(!n.userIds?.length||n.userIds.includes(uid))&&(!n.roles?.length||n.roles.includes(role))&&(!n.organizationId||n.organizationId===orgId))}
function markRead(nid){put(NO,notifications().map(n=>n.id===nid?{...n,read:true}:n))} function markAll(uid,role,org){forUser(uid,role,org).forEach(n=>markRead(n.id))}
function resolveByKey(k){put(NO,notifications().map(n=>n.dedupeKey===k?{...n,resolved:true,read:true}:n))}
function scanTeacher(uid){const cal=window.MAIHOC_CAL?.load?.()||{sessions:[]};cal.sessions.filter(s=>s.status!=='cancelled'&&(s.teacherId===uid||(s.teachingStaff||[]).some(t=>t.userId===uid))).forEach(s=>{const c=checkTeacher(uid,s.start,s.end,s.id);if(c.blocks.length)notify({type:'substitute_needed',title:'Cần giáo viên thay thế',message:`${s.teacher||'Giáo viên'} không thể dạy ${s.className} · ${new Date(s.start).toLocaleString()}`,roles:['admin'],organizationId:'org-sunshine',sessionId:s.id,teacherId:uid,dedupeKey:'sub:'+s.id+':'+uid,action:`classes/class.html?id=${s.classId}`})})}
function publishAnnouncement(v){let a=announcements(),n={id:id('ann'),createdAt:new Date().toISOString(),status:'published',...v};a.unshift(n);put(AN,a);notify({type:'announcement',title:n.title,message:n.body,organizationId:n.organizationId,roles:n.roles||[],userIds:n.userIds||[],announcementId:n.id,dedupeKey:'announcement:'+n.id});return n}
function visibleAnnouncements(uid,role,org){return announcements().filter(a=>(!a.organizationId||a.organizationId===org)&&(!a.roles?.length||a.roles.includes(role))&&(!a.userIds?.length||a.userIds.includes(uid)))}
function sessionChanged(oldS,newS){['teacherId','start','end','location','meetingUrl','status'].forEach(k=>{if(oldS&&oldS[k]!==newS[k])notify({type:'session_change',title:'Lịch học đã thay đổi',message:`${newS.className} · ${new Date(newS.start).toLocaleString()} · ${k} đã được cập nhật`,organizationId:'org-sunshine',roles:['teacher','student','parent'],sessionId:newS.id,dedupeKey:'chg:'+newS.id+':'+k+':'+String(newS[k])})})}
// v216 sample migration: every creatable staffing/communication area has a visible working example.
(function ensureSamples(){
 let av=availability();
 if(!av.some(x=>x.id==='av-sample-mai')) av.push({id:'av-sample-mai',teacherId:'u-teacher',status:'unavailable',start:'2026-10-08T13:00',end:'2026-10-08T17:00',note:'SAMPLE · Personal appointment'});
 if(!av.some(x=>x.id==='av-demo')) av.push({id:'av-demo',teacherId:'u-teacher2',status:'day_off',start:'2026-10-06T08:00',end:'2026-10-06T18:00',note:'SAMPLE · Day off'});
 put(AV,av);
 let an=announcements();
 if(!an.some(x=>x.id==='ann-sample-org')) an.push({id:'ann-sample-org',createdAt:'2026-09-25T09:00:00',status:'published',organizationId:'org-sunshine',title:'SAMPLE · Family Learning Day',body:'Sample Organization will hold Family Learning Day this Saturday. Students and parents are welcome to join.',roles:['teacher','teaching_assistant','student','parent'],userIds:[],createdBy:'u-admin',isSample:true});
 if(!an.some(x=>x.id==='ann-sample-teacher')) an.push({id:'ann-sample-teacher',createdAt:'2026-09-25T10:00:00',status:'published',organizationId:'org-sunshine',title:'SAMPLE · English 6A reminder',body:'Please bring your vocabulary notebook to our next English 6A class.',roles:['student','parent'],userIds:[],createdBy:'u-teacher',isSample:true});
 put(AN,an);
 let no=notifications();
 const samples=[
  {id:'n-sample-admin',createdAt:'2026-09-26T08:30:00',read:false,resolved:false,type:'substitute_needed',title:'SAMPLE · Cần giáo viên thay thế',message:'Sample Teacher đã đánh dấu không rảnh cho English 6A · Oct 8 · 4:00 PM.',organizationId:'org-sunshine',roles:['admin'],isSample:true},
  {id:'n-sample-teacher',createdAt:'2026-09-26T09:00:00',read:false,resolved:false,type:'session_change',title:'SAMPLE · Lịch dạy đã cập nhật',message:'English 6A · phòng học được đổi sang Room 205.',organizationId:'org-sunshine',roles:['teacher','teaching_assistant'],isSample:true},
  {id:'n-sample-family',createdAt:'2026-09-26T09:30:00',read:false,resolved:false,type:'announcement',title:'SAMPLE · Family Learning Day',message:'Có thông báo mới từ Sample Organization.',organizationId:'org-sunshine',roles:['student','parent'],isSample:true}
 ];
 for(const x of samples) if(!no.some(n=>n.id===x.id)) no.push(x);
 put(NO,no);
})();
window.MAIHOC_STAFF={AV,NO,AN,availability,notifications,announcements,saveAvailability,removeAvailability,blocksFor,sessionConflicts,checkTeacher,notify,forUser,markRead,markAll,resolveByKey,scanTeacher,publishAnnouncement,visibleAnnouncements,sessionChanged};
})();
