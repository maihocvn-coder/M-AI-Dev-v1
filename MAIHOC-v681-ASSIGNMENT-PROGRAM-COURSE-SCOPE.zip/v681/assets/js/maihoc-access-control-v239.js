(()=>{'use strict';
const K='maihoc.access.control.v239';
const PROTECTED=new Set(['script_publish']);
const ROLE_DEFAULTS={
 super_admin:{scope:'platform',pages:'all',functions:'all'},
 management_admin:{scope:'platform',pages:'all',functions:'all_except_protected'},
 curriculum_admin:{scope:'curriculum',pages:'curriculum_and_org',functions:'curriculum_and_lower'},
 curriculum_designer:{scope:'assigned_curriculum',pages:'content_work',functions:'assigned_content_work'},
 admin:{scope:'organization',pages:'role_default',functions:'role_default'},
 teacher:{scope:'assigned',pages:'role_default',functions:'role_default'},
 teaching_assistant:{scope:'assigned',pages:'role_default',functions:'role_default'},
 parent:{scope:'relationships',pages:'role_default',functions:'role_default'},
 student:{scope:'self',pages:'role_default',functions:'role_default'}
};
function norm(v){v=String(v||'').toLowerCase().replace(/[- ]+/g,'_');return ['organization_admin','org_admin'].includes(v)?'admin':v}
function session(){try{return JSON.parse(localStorage.getItem('maihoc.demo.session')||'null')||{}}catch{return{}}}
function impersonation(){try{return JSON.parse(sessionStorage.getItem('maihoc.impersonation.v207')||'null')}catch{return null}}
function effectiveSession(s=session()){const i=impersonation();return i?{...s,userId:i.targetUserId||s.userId,activeRole:i.targetRole||s.activeRole,organizationId:i.organizationId||s.organizationId,impersonating:true,actorUserId:i.actorUserId,actorRole:i.actorRole}:s}
function uid(s=session()){return String(s.userId||s.id||s.email||s.username||s.name||'').trim().toLowerCase()}
function read(){try{return JSON.parse(localStorage.getItem(K)||'null')||{users:{},roles:{}}}catch{return{users:{},roles:{}}}}
function write(x){localStorage.setItem(K,JSON.stringify(x))}
function userGrant(s=session()){const x=read(),keys=[uid(s),s.email,s.username].filter(Boolean).map(v=>String(v).toLowerCase());for(const k of keys)if(x.users?.[k])return x.users[k];return null}
function role(s=effectiveSession()){return norm(s.activeRole)}
function pageDecision(path,s=effectiveSession()){
 s=effectiveSession(s); const r=role(s),g=userGrant(s);if(r==='super_admin')return true;
 if(g?.pages&&Object.prototype.hasOwnProperty.call(g.pages,path))return !!g.pages[path];
 if(g?.pagePrefixes){let best=null;for(const [p,v] of Object.entries(g.pagePrefixes))if(path.startsWith(p)&&(!best||p.length>best[0].length))best=[p,v];if(best)return !!best[1]}
 return null;
}
function canFunction(id,s=effectiveSession()){
 s=effectiveSession(s); const r=role(s);if(r==='super_admin')return true;if(PROTECTED.has(id))return false;
 const g=userGrant(s);if(g?.functions&&Object.prototype.hasOwnProperty.call(g.functions,id))return !!g.functions[id];
 if(r==='management_admin')return true;if(r==='curriculum_admin'&&/^(content\.|review\.|curriculum\.|org\.)/.test(id))return true;if(r==='curriculum_designer'&&/^(content\.edit|review\.queue)$/.test(id))return true;return null;
}
function canPublishScript(s=effectiveSession()){s=effectiveSession(s);return role(s)==='super_admin'}
window.MAIHOC_ACL={K,PROTECTED,ROLE_DEFAULTS,norm,session,impersonation,effectiveSession,uid,read,write,userGrant,role,pageDecision,canFunction,canPublishScript};
})();
