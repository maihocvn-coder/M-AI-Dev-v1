/* M-AI Hoc v394 — centralized verified phoneme audio registry for all grades.
   Display contract: phoneme + exact source example words + ONE speaker.
   Hamburg records are copied from its published "All English phonemes" table.
   Curriculum aliases preserve Grade-6 IPA notation without changing LO targets.
*/
(function(){
 'use strict';
 const H='https://englishexplorations.check.uni-hamburg.de/wp-content/uploads/2019/07/';
 const records={
  'p':{url:H+'p.mp3',examples:['play','happen','cap'],sourceSymbol:'p',source:'hamburg'},
  'b':{url:H+'b.mp3',examples:['baby','double','tab'],sourceSymbol:'b',source:'hamburg'},
  't':{url:H+'t.mp3',examples:['tidy','flat','hint'],sourceSymbol:'t',source:'hamburg'},
  'd':{url:H+'d.mp3',examples:['dust','dad','cuddle','bed'],sourceSymbol:'d',source:'hamburg'},
  'k':{url:H+'k.mp3',examples:['cow','chemistry','queen','box'],sourceSymbol:'k',source:'hamburg'},
  'g':{url:H+'g.mp3',examples:['great','haggis','hug'],sourceSymbol:'g',source:'hamburg'},
  'f':{url:H+'f.mp3',examples:['fan','half','cough','often','calf'],sourceSymbol:'f',source:'hamburg'},
  'm':{url:H+'m.mp3',examples:['mother','jammer','ham','comb'],sourceSymbol:'m',source:'hamburg'},
  'n':{url:H+'n.mp3',examples:['night','know','hen'],sourceSymbol:'n',source:'hamburg'},
  'h':{url:H+'h.mp3',examples:['who','have','house'],sourceSymbol:'h',source:'hamburg'},
  'l':{url:H+'l.mp3',examples:['loud','hallway','hello','frugal'],sourceSymbol:'l',source:'hamburg'},
  'w':{url:H+'w.mp3',examples:['what','quick','choir'],sourceSymbol:'w',source:'hamburg'},
  's':{url:H+'s.mp3',examples:['speak','sun','hassle','mess'],sourceSymbol:'s',source:'hamburg'},
  'z':{url:H+'z.mp3',examples:['zebra','hazelnut','houses','tease'],sourceSymbol:'z',source:'hamburg'},
  'ʃ':{url:H+'sh.mp3',examples:['sure','chic','fisherman','harsh'],sourceSymbol:'ʃ',source:'hamburg'},
  'θ':{url:H+'thing.mp3',examples:['therapy','thing','tooth'],sourceSymbol:'θ',source:'hamburg'},
  'ð':{url:H+'there.mp3',examples:['there','feather','teething'],sourceSymbol:'ð',source:'hamburg'},
  'ɪ':{url:H+'sit.mp3',examples:['sit','in','fringe','gym','lid'],sourceSymbol:'ɪ',source:'hamburg'},
  'iː':{url:H+'i.mp3',examples:['eagle','perceive','sea','friendly'],sourceSymbol:'i',source:'hamburg',aliasReason:'Grade 6 curriculum uses /iː/; Hamburg front-vowel lesson labels the same row /i:/.'},
  'e':{url:H+'e.mp3',examples:['friend','left','bury','berry'],sourceSymbol:'ɛ',source:'hamburg',aliasReason:'Grade 6 curriculum uses /e/; Hamburg front-vowel lesson presents this row as /e/ while the master table uses /ɛ/.'},
  'æ':{url:H+'ae.mp3',examples:['mad','laugh','academic','vary'],sourceSymbol:'æ',source:'hamburg'},
  'ʌ':{url:H+'mud.mp3',examples:['utter','mud','double'],sourceSymbol:'ʌ',source:'hamburg'},
  'ɒ':{url:'https://ece.edu.vn/wp-content/uploads/2025/06/o-ngan-3.mp3',examples:['hot','dog','box'],sourceSymbol:'ɒ',source:'ece-ipa-guide',aliasReason:'University of Hamburg does not publish an audio file for its low-back /ɑ/ row; Grade 1 curriculum target /ɒ/ uses this exact-/ɒ/ verified fallback until M-AI-owned audio is uploaded.'},
  'əʊ':{url:H+'ou.mp3',examples:['open','goat','flow'],sourceSymbol:'oʊ',source:'hamburg',aliasReason:'Grade 6 curriculum uses British-style /əʊ/ notation; Hamburg American-English row is /oʊ/.'},
  'aʊ':{url:H+'au.mp3',examples:['ouch','shout','now'],sourceSymbol:'aʊ',source:'hamburg'},
  'ɑː':{url:'https://ece.edu.vn/wp-content/uploads/2025/06/a-dai.mp3',examples:['car','start','father'],sourceSymbol:'ɑː',source:'ece-ipa-guide',aliasReason:'Hamburg lists /ɑ/ examples but exposes no audio URL for that row; Grade 6 /ɑː/ therefore uses a source that explicitly publishes /ɑː/ audio and these examples.'}
 };
 const OVERRIDE_KEY='maihoc.phoneme.owned.overrides.v344'; // stable key: Super Admin replacements survive content releases
 function loadOverrides(){try{return JSON.parse(localStorage.getItem(OVERRIDE_KEY)||'{}')||{}}catch(e){return {}}}
 function effectiveRecord(k){
   const base=records[k]; if(!base)return null;
   const o=loadOverrides()[k];
   if(o&&o.status==='active'&&o.dataUrl)return {...base,url:o.dataUrl,source:'m-ai-owned',fileName:o.fileName||'',uploadedAt:o.uploadedAt||'',externalFallbackUrl:base.url};
   return base;
 }
 const norm=x=>String(x||'').trim().replace(/^\//,'').replace(/\/$/,'');
 let current=null,currentButton=null,currentKey='';
 function setButton(btn,state,key){
   if(!btn)return;btn.dataset.audioState=state;
   btn.textContent=state==='playing'?'⏸':'🔊';
   btn.setAttribute('aria-label',state==='playing'?'Dừng mẫu âm /'+key+'/':'Nghe mẫu âm /'+key+'/');
   btn.title=state==='playing'?'Dừng mẫu âm /'+key+'/':'Nghe mẫu âm /'+key+'/';
 }
 function stop(){if(current){try{current.pause();current.currentTime=0}catch(e){}current=null;}if(currentButton)setButton(currentButton,'idle',currentKey);currentButton=null;currentKey='';}
 function playRecording(k,url,btn){
   if(!url)return false;if(currentButton===btn&&btn?.dataset.audioState==='playing'){stop();return true;}stop();
   const a=new Audio();a.preload='auto';a.src=url;current=a;currentButton=btn;currentKey=k;setButton(btn,'loading',k);
   const fail=()=>{const detail={phoneme:k,url,source:records[k]?.source||'verified-source'};stop();if(btn){btn.dataset.audioState='error';btn.title='Không tải được mẫu âm /'+k+'/ — thử lại';}window.dispatchEvent(new CustomEvent('maihoc:phoneme-audio-error',{detail}));};
   a.onplaying=()=>setButton(btn,'playing',k);a.onended=stop;a.onerror=fail;const q=a.play();if(q?.catch)q.catch(fail);return true;
 }
 const api={
   policy:'v344-m-ai-owned-first-external-fallback',manifest:records,overrideStorageKey:OVERRIDE_KEY,
   known(p){return !!effectiveRecord(norm(p))?.url},has(p){return this.known(p)},url(p){return effectiveRecord(norm(p))?.url||'';},
   source(p){const k=norm(p),r=effectiveRecord(k);return r?{phoneme:k,language:'en',delivery:'source-recording',url:r.url,examples:[...r.examples],sourceSymbol:r.sourceSymbol,source:r.source,aliasReason:r.aliasReason||'',fileName:r.fileName||'',uploadedAt:r.uploadedAt||''}:{};},
   mount(button,p){const k=norm(p);if(!button||!this.known(k)){if(button)button.hidden=true;return false;}button.hidden=false;button.dataset.audioKind='phoneme';button.dataset.phoneme=k;button.onclick=e=>{e.preventDefault();e.stopPropagation();this.play(k,{button});};setButton(button,'idle',k);return true;},
   play(p,opts={}){const k=norm(p),r=effectiveRecord(k);return playRecording(k,r?.url||'',opts.button);},stop
 };
 window.MAIHOC_PHONEME_AUDIO=api;
})();
