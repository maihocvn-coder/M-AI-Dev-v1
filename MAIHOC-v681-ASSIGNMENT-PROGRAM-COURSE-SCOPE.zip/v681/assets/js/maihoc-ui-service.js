(()=>{
  let host;
  function ensure(){if(host)return host;host=document.createElement('div');host.id='mh-ui-host';document.body.appendChild(host);return host}
  function toast(message,type='info'){const h=ensure(),n=document.createElement('div');n.className='mh-global-toast '+type;n.textContent=message;h.appendChild(n);setTimeout(()=>n.classList.add('show'),10);setTimeout(()=>{n.classList.remove('show');setTimeout(()=>n.remove(),250)},3200)}
  function confirmBox(message,title='Confirm'){return new Promise(resolve=>{const d=document.createElement('dialog');d.className='mh-global-dialog';d.innerHTML=`<form method="dialog"><h3>${title}</h3><p></p><div class="mh-dialog-actions"><button value="cancel" class="mh-btn secondary">Cancel</button><button value="ok" class="mh-btn">Confirm</button></div></form>`;d.querySelector('p').textContent=message;document.body.appendChild(d);d.addEventListener('close',()=>{const ok=d.returnValue==='ok';d.remove();resolve(ok)},{once:true});d.showModal()})}
  function upgrade(feature){const names={assignment_create:'Create Assignments',assignment_assign:'Assign Assignments',student_file_upload:'Student File Upload',worksheet_import:'Worksheet Import'};toast(`${names[feature]||feature} requires an active subscription for this workspace.`,'warning')}
  window.MAIHOC_UI={toast,confirm:confirmBox,upgrade};
})();
