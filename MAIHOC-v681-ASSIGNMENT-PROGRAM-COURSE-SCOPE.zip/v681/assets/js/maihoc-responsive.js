(()=>{'use strict';
const root=document.documentElement;
let raf=0,mainObserver=null,observedMain=null;
const widthState=w=>w<=520?'phone':w<=760?'narrow':w<=1100?'medium':'wide';
const heightState=h=>h<=620?'short':h<=820?'medium':'tall';
// Game shell has no tablet/iPad profile. It has only two structural states:
// split = Journey + Game can coexist; single = Journey becomes a drawer and Game owns the row.
// Phone/narrow visual sizing is handled independently by the measured MainScreen.
const gameSurface=w=>w>1366?'split':'single';
function px(n){return `${Math.max(0,Math.round(n))}px`}
function measure(el){const r=el?.getBoundingClientRect?.();return r&&r.width+r.height?r:null}
function fitGame(el,w,h){
 if(!document.body?.classList.contains('mse-school-english')||document.body.dataset.mseMode!=='play')return false;
 const scene=el.querySelector('#scene'),q=scene?.querySelector('.mh-world-question'),lane=scene?.querySelector('#catchLane'),stack=scene?.querySelector('.mse-play-bottom-stack'),characterRow=stack?.querySelector('.mse-character-row'),controller=stack?.querySelector('.mse-controller-row'),cat=characterRow?.querySelector('#cat,#character,.game-character,[data-game-character]');
 if(!scene||!q||!lane||!stack)return false;
 const er=el.getBoundingClientRect(),qr=measure(q),lr=measure(lane),catr=measure(cat);
 if(characterRow&&catr)characterRow.style.setProperty('--mse-character-row-h',px(catr.height));
 const sr=measure(stack),cr=measure(controller);
 // Two independent anchors: learning content grows from the top; gameplay HUD grows
 // from the bottom. Width reflow is allowed to change answer height, but it can
 // only consume the flexible world band between those anchors.
 const questionTop=Math.max(0,(qr?.top??er.top)-er.top);
 const questionBottom=Math.max(questionTop,(qr?.bottom??er.top)-er.top);
 const answerTop=questionBottom;
 el.style.setProperty('--mse-answer-top',px(answerTop));
 // Bottom stack owns its natural/intrinsic height. Never derive its Y position
 // from answer height and never resize the character because width changed.
 const stackH=sr?.height||0;
 const answerBottom=answerTop+(lr?.height||0);
 // The bottom edge is a safety limit, not the character's target position.
 // Keep the world gap proportional to the live character artwork so narrowing
 // the viewport cannot turn newly available MainScreen height into empty sky.
 const visualGap=Math.max(0,(catr?.height||characterRow?.getBoundingClientRect?.().height||0)*0.5);
 const hudBottom=12;
 const latestStackTop=Math.max(0,h-stackH-hudBottom);
 const preferredStackTop=answerBottom+visualGap;
 // The gameplay stack is a bottom HUD at every width. Character and controller
 // travel together as one intrinsic stack: the controller hugs the safe bottom
 // edge and the character stands directly on the controller row. Width changes
 // may reflow the learning area above, but must never lift this HUD upward.
 // If the learning area grows too far, chrome compaction handles the collision;
 // the HUD itself keeps its bottom anchor.
 const stackTop=latestStackTop;
 el.dataset.mseVerticalAnchor='bottom-hud';
 el.style.setProperty('--mse-bottom-stack-top',px(stackTop));
 const flexTop=Math.min(h,answerBottom),flexBottom=Math.max(0,stackTop),flexSpace=Math.max(0,flexBottom-flexTop);
 el.style.setProperty('--mse-flex-top',px(flexTop));
 el.style.setProperty('--mse-flex-space',px(flexSpace));
 const overlaps=preferredStackTop>latestStackTop;
 el.dataset.mseFit=overlaps?'tight':'fit';
 document.body.classList.toggle('mh-game-fit-needs-chrome',overlaps);
 return overlaps;
}
function syncMain(){
 const el=document.querySelector('.mse-main-screen');
 if(!el)return false;
 const r=el.getBoundingClientRect(),w=Math.max(1,r.width),h=Math.max(1,r.height);
 el.style.setProperty('--mse-main-w',`${Math.round(w)}px`);el.style.setProperty('--mse-main-h',`${Math.round(h)}px`);
 el.dataset.mseLayout=w<=420?'phone':w<=600?'narrow':w<=900?'medium':'wide';
 const needsChrome=fitGame(el,w,h);
 if(el!==observedMain&&'ResizeObserver'in window){mainObserver?.disconnect();observedMain=el;mainObserver=new ResizeObserver(schedule);mainObserver.observe(el)}
 return needsChrome;
}
function sync(){
 raf=0;
 const w=Math.max(1,document.documentElement.clientWidth||innerWidth),h=Math.max(1,window.visualViewport?.height||innerHeight||document.documentElement.clientHeight);
 const layout=widthState(w),height=heightState(h),game=gameSurface(w);
 root.dataset.mhLayout=layout;root.dataset.mhHeight=height;
 if(document.body){
   document.body.dataset.mhLayout=layout;document.body.dataset.mhHeight=height;document.body.dataset.mhGameSurface=game;
   document.body.classList.toggle('mh-phone-layout',layout==='phone');
   document.body.classList.toggle('mh-tablet-layout',layout==='medium'||layout==='narrow');
 }
 // Measure the live game first. Chrome state is then decided atomically from
 // that actual fit result; there is no second JS authority translating classes.
 const fitNeedsChrome=syncMain();
 if(document.body){
   const gamePlay=document.body.classList.contains('mse-school-english')&&document.body.dataset.mseMode==='play';
   const compact=game==='single'||height==='short'||fitNeedsChrome;
   document.body.classList.toggle('mh-compact-site',compact);
   document.body.classList.toggle('mh-game-site-curtain-enabled',gamePlay&&compact);
   if(!(gamePlay&&compact))document.body.classList.remove('mh-game-site-curtain-open');
 }
 window.dispatchEvent(new CustomEvent('maihoc:responsive',{detail:{layout,height,gameSurface:game,width:w,viewportHeight:h}}));
}
function schedule(){if(!raf)raf=requestAnimationFrame(sync)}
addEventListener('resize',schedule,{passive:true});addEventListener('orientationchange',schedule,{passive:true});window.visualViewport?.addEventListener('resize',schedule,{passive:true});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',sync,{once:true});else sync();
new MutationObserver(schedule).observe(document.documentElement,{childList:true,subtree:true});
window.MAIHOC_RESPONSIVE={sync,schedule,get state(){return {layout:root.dataset.mhLayout,height:root.dataset.mhHeight}}};
})();
