(()=>{'use strict';
function getBank(){return window.MAIHOC_G6_BANK||window.MAIHOC_BANK||window.MAIHOC_BANK_DATA||null}
function titleOf(l){return l?.title||l?.name||('Level '+(l?.unit||''))}
function engineOf(l){return String(l?.engineName||l?.world||l?.engine||'Play').split(/\s+CHARACTER:/i)[0].trim()}
function selected(){const n=Number(new URLSearchParams(location.search).get('level'));return n>=1&&n<=12?n:1}
function render(){if(/\/student\/my-school-english\/grade1\/engine\/play\.html$/i.test(location.pathname))return false;const list=document.getElementById('levelList'),bank=getBank();if(!list||!bank||!Array.isArray(bank.levels)||!bank.levels.length)return false;const current=selected();list.replaceChildren();bank.levels.forEach((l,i)=>{const unit=Number(l.unit)||i+1,b=document.createElement('button');b.type='button';b.className='level'+(unit===current?' active':'');b.dataset.level=String(unit);b.innerHTML='<span class="level-num"></span><span><strong></strong><small></small></span><span class="pct">—</span>';b.querySelector('.level-num').textContent=String(unit).padStart(2,'0');b.querySelector('strong').textContent=titleOf(l);b.querySelector('small').textContent='🎮 '+engineOf(l);b.addEventListener('click',()=>{try{window.MAIHOC_STOP_ALL_AUDIO?.()}catch(e){}const u=new URL(location.href);u.searchParams.set('level',unit);u.searchParams.set('mode','play');location.href=u.href});list.append(b)});return true}
window.MAIHOC_LEVEL_MAP_BOOTSTRAP={render};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',render,{once:true});else render();
setTimeout(render,0);[50,120,250,500,1000,2000].forEach(ms=>setTimeout(()=>{const l=document.getElementById('levelList');if(l&&!l.children.length)render()},ms));window.addEventListener('maihoc:bank-ready',render);
})();
