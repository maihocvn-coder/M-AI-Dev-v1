(()=>{'use strict';
const K={programs:'maihoc.academic.programs',courses:'maihoc.demo.courses',assignments:'maihoc.demo.assignments',attempts:'maihoc.assignment.attempts'};
const read=(k,d=[])=>{try{const x=JSON.parse(localStorage.getItem(k)||'null');return x??d}catch{return d}},write=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const seedPrograms=()=>{let p=read(K.programs);if(!p.length){p=[{id:'program-school',name:'M-AI School English',access:'free'},{id:'program-cefr',name:'M-AI CEFR',access:'free'}];write(K.programs,p)}return p};
function normalizeCourse(c){return {...c,programId:(c.programId===undefined?(String(c.curriculum||'').startsWith('cefr')?'program-cefr':''):c.programId),startDate:c.startDate||'',endDate:c.endDate||'',classTime:c.classTime||'',teacher:c.teacher||'',tas:c.tas||[],students:c.students||[],modules:c.modules||[]}}
function courses(){const x=read(K.courses).map(normalizeCourse);return x}
function saveCourses(x){write(K.courses,x)}
function saveCourse(c){const xs=courses(),i=xs.findIndex(x=>x.id===c.id);i<0?xs.push(normalizeCourse(c)):xs[i]=normalizeCourse(c);saveCourses(xs);return c}
function addModule(courseId,name){const xs=courses(),c=xs.find(x=>x.id===courseId);if(!c)return null;const m={id:'module-'+Date.now(),name:name||'New Module',published:true};c.modules.push(m);saveCourses(xs);return m}
function assignments(){return read(K.assignments)}
function saveAssignments(x){write(K.assignments,x)}
function updateAssignment(id,patch={}){const xs=assignments(),i=xs.findIndex(x=>x.id===id);if(i<0)return null;xs[i]={...xs[i],...patch,updatedAt:new Date().toISOString()};saveAssignments(xs);return xs[i]}
function removeAssignment(id){const xs=assignments(),next=xs.filter(x=>x.id!==id);if(next.length===xs.length)return false;saveAssignments(next);return true}
function assign({material,courseId,moduleId='',recipients='all',studentNames=[],availableAt='',dueAt=''}){const c=courses().find(x=>x.id===courseId);if(!c)throw Error('Course not found');const xs=assignments();const a={id:'assignment-'+Date.now(),materialId:material.id,materialRevision:material.revision||1,title:material.title,type:material.type,programId:material.programId,courseId,course_id:courseId,moduleId,recipients,assign_all:recipients==='all',studentNames,student_names:studentNames,assigned_to:c.name,availableAt,dueAt,due_date:dueAt,status:'assigned',url:material.url||'',points:material.points||100,assignedAt:new Date().toISOString()};xs.push(a);saveAssignments(xs);return a}
function setExtension(assignmentId,{scope='student',studentName='',dueAt=''}){const xs=assignments(),a=xs.find(x=>x.id===assignmentId);if(!a)return null;a.extensions=a.extensions||[];a.extensions.push({id:'ext-'+Date.now(),scope,studentName,dueAt});saveAssignments(xs);return a}
function effectiveDue(a,student){const ex=a.extensions||[],personal=[...ex].reverse().find(x=>x.scope==='student'&&x.studentName===student),whole=[...ex].reverse().find(x=>x.scope==='course');return personal?.dueAt||whole?.dueAt||a.dueAt||a.due_date||''}
const materials=()=>{
 const ws=(window.MHTeacher?.worksheets?.()||[]).map(x=>({...x,programId:'program-school',access:'free',revision:1,type:'worksheet'}));
 const tests=(window.MHTeacher?.tests?.()||[]).map(x=>({...x,programId:'program-school',access:'free',revision:1,type:'test'}));
 const games=Array.from({length:12},(_,g)=>Array.from({length:12},(_,i)=>({id:`school-g${g+1}-u${i+1}-game`,title:`Grade ${g+1} · Unit ${i+1} Game`,type:'game',programId:'program-school',grade:g+1,unit:i+1,access:'free',revision:1,url:`../../student/my-school-english/grade${g+1}/engine/play.html?level=${i+1}&mode=play`}))).flat();
 const levels=['Pre-A1','A1','A2','B1','B2','C1','C2'];
 const cefrWs=window.MAIHOC_CEFR_WORKSHEETS?.worksheets||[];
 const cefrTests=window.MAICEFR_LEVEL_TESTS?.tests||[];
 const cefr=levels.flatMap(level=>{
   const ws=cefrWs.find(x=>x.cefrLevel===level),test=cefrTests.find(x=>x.cefrLevel===level);
   return [ws&&{...ws,programId:'program-cefr',access:'free',revision:1,viewerUrl:`material-viewer.html?kind=worksheet&id=${encodeURIComponent(ws.id)}`},test&&{...test,programId:'program-cefr',access:'free',revision:1,viewerUrl:`material-viewer.html?kind=test&id=${encodeURIComponent(test.id)}`}].filter(Boolean)
 });
 return [...games,...ws,...tests,...cefr]
};
function calendarEvents(){const out=[];courses().forEach(c=>{if(c.classTime)out.push({id:'meeting-'+c.id,type:'class-time',courseId:c.id,title:c.name+' · Class time',schedule:c.classTime,startDate:c.startDate,endDate:c.endDate});});assignments().forEach(a=>{if(a.dueAt||a.due_date)out.push({id:'due-'+a.id,type:'due',courseId:a.courseId||a.course_id,title:a.title+' · Due',date:a.dueAt||a.due_date})});return out}
seedPrograms();
window.MAIHOC_LEARNING_WORKFLOW=Object.freeze({programs:seedPrograms,courses,saveCourse,saveCourses,addModule,assignments,saveAssignments,updateAssignment,removeAssignment,assign,setExtension,effectiveDue,materials,calendarEvents});
})();
