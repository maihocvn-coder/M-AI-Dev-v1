(()=>{'use strict';
const K='maihoc.demo.session';
const routes={student:'student/home/home.html',teacher:'teacher/my-teaching/home.html',parent:'parent/my-family/home.html',admin:'admin/organization/home.html',super_admin:'admin/super-admin/home.html'};
function session(){try{return JSON.parse(localStorage.getItem(K)||'null')}catch{return null}}
function base(){const m=location.pathname.match(/^(.*?)(?:account|student|teacher|parent|admin)\//);return m?m[1]:''}
function canRole(s,role){return !!s&&(s.roles||[]).includes(role)}
function go(role){const s=session();if(!canRole(s,role))return false;s.activeRole=role;localStorage.setItem(K,JSON.stringify(s));location.href=base()+routes[role];return true}
window.MAIHOC_DEMO={session,go,routes,canRole};
})();