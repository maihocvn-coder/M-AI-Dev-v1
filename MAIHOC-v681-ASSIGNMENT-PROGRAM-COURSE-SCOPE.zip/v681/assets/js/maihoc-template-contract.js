(()=>{'use strict';
const CONTRACT='v191',doc=document.documentElement;
doc.dataset.maihocTemplate=CONTRACT;
function hasGlobalTheme(){return [...document.styleSheets].some(s=>{try{return String(s.href||'').includes('maihoc-universal-theme.css')}catch{return false}})}
function audit(){
 const violations=[];
 if(!hasGlobalTheme())violations.push('Missing maihoc-universal-theme.css');
 document.querySelectorAll('body>header:not(.mh-site-header)').forEach(x=>violations.push('Legacy page header: '+(x.className||x.tagName)));
 if(violations.length)console.warn('[M-AI Học Global Template]',violations);
 window.MAIHOC_TEMPLATE_AUDIT={version:CONTRACT,violations};
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',audit,{once:true});else audit();
})();