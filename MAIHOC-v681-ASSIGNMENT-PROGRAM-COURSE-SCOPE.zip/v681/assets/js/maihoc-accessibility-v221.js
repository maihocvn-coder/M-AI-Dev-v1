(function(){
'use strict';
function textOf(el){return (el.getAttribute('aria-label')||el.getAttribute('title')||el.textContent||'').trim();}
function labelFor(el){
  if(el.id && document.querySelector('label[for="'+CSS.escape(el.id)+'"]')) return true;
  if(el.closest('label')) return true;
  if(el.getAttribute('aria-label')||el.getAttribute('aria-labelledby')) return true;
  return false;
}
function inferLabel(el){
  var v=el.getAttribute('placeholder')||el.getAttribute('name')||el.getAttribute('id')||el.getAttribute('type')||'Field';
  return String(v).replace(/[-_]+/g,' ').replace(/\b\w/g,function(c){return c.toUpperCase();});
}
function enhance(root){
  root=root||document;
  root.querySelectorAll('img:not([alt])').forEach(function(img){img.alt=img.getAttribute('data-alt')||'';});
  root.querySelectorAll('input,select,textarea').forEach(function(el){
    if(el.type==='hidden') return;
    if(!labelFor(el)) el.setAttribute('aria-label',inferLabel(el));
  });
  root.querySelectorAll('button,a[href],[role="button"]').forEach(function(el){
    if(!textOf(el)) el.setAttribute('aria-label',el.getAttribute('data-label')||'Action');
  });
  root.querySelectorAll('[role="dialog"],.modal,.dialog').forEach(function(el){
    if(!el.hasAttribute('role')) el.setAttribute('role','dialog');
    el.setAttribute('aria-modal','true');
    if(!el.hasAttribute('aria-label')&&!el.hasAttribute('aria-labelledby')){
      var h=el.querySelector('h1,h2,h3,[data-modal-title]');
      if(h){if(!h.id) h.id='mh-dialog-title-'+Math.random().toString(36).slice(2,8);el.setAttribute('aria-labelledby',h.id);}
      else el.setAttribute('aria-label','Dialog');
    }
  });
  root.querySelectorAll('table').forEach(function(t){if(!t.querySelector('caption')&&!t.getAttribute('aria-label')) t.setAttribute('aria-label','Data table');});
  root.querySelectorAll('[onclick]:not(button):not(a):not(input):not(select):not(textarea)').forEach(function(el){
    if(!el.hasAttribute('role')) el.setAttribute('role','button');
    if(!el.hasAttribute('tabindex')) el.tabIndex=0;
    if(!el.dataset.mhKeybound){el.dataset.mhKeybound='1';el.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();el.click();}});}
  });
}
function installSkip(){
 if(document.querySelector('.mh-skip-link')) return;
 var main=document.querySelector('main,[role="main"],#main,.main'); if(!main) return;
 if(!main.id) main.id='mh-main-content';
 var a=document.createElement('a');a.className='mh-skip-link';a.href='#'+main.id;a.textContent='Bỏ qua điều hướng';document.body.insertBefore(a,document.body.firstChild);
}
function boot(){installSkip();enhance(document);var mo=new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType===1) enhance(n);});});});mo.observe(document.body,{childList:true,subtree:true});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
