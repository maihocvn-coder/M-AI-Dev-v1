(()=>{
 const ACTIONS={
  'assignment.create':{feature:'assignment_create',roles:['teacher','admin','management_admin','super_admin']},
  'assignment.edit':{feature:'assignment_create',roles:['teacher','admin','management_admin','super_admin']},
  'assignment.assign':{feature:'assignment_assign',roles:['teacher','admin','management_admin','super_admin']},
  'assignment.remove':{feature:'assignment_create',roles:['teacher','admin','management_admin','super_admin']},
  'submission.upload':{feature:'student_file_upload',roles:['student']},
  'worksheet.import':{feature:'worksheet_import',roles:['teacher','admin','management_admin','super_admin']}
 };
 function role(){return window.MAIHOC_SUBSCRIPTION?.role?.()||localStorage.getItem('maihoc_active_role')||'admin'}
 function check(action,ctx={}){const def=ACTIONS[action];if(!def)return {allowed:false,reason:'unknown_action'};const r=role();if(!def.roles.includes(r))return {allowed:false,reason:'role_denied',action};if(window.MAIHOC_ACL?.canFunction){const acl=window.MAIHOC_ACL.canFunction(action);if(acl===false)return {allowed:false,reason:'permission_denied',action};}const ent=window.MAIHOC_SUBSCRIPTION?.check?.(def.feature,ctx)||{allowed:true,reason:'no_subscription_engine'};return {...ent,action,feature:def.feature}}
 function require(action,ctx={}){const x=check(action,ctx);if(x.allowed)return true;if(x.reason==='subscription_required')window.MAIHOC_UI?.upgrade?.(x.feature);else window.MAIHOC_UI?.toast?.(x.reason==='disabled'?'This feature is currently disabled.':'You do not have permission for this action.','warning');return false}
 window.MAIHOC_ACTIONS={ACTIONS,check,require};
})();
