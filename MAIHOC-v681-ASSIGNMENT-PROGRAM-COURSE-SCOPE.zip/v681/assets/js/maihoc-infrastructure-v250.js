(()=>{'use strict';let provider=null;const unavailable={name:'unconfigured',async status(){return{configured:false,status:'unavailable'}},async requestBackup(){throw Object.assign(new Error('Infrastructure backup provider not configured'),{code:'MAIHOC_BACKUP_UNAVAILABLE'})},async requestRestoreDrill(){throw Object.assign(new Error('Infrastructure recovery provider not configured'),{code:'MAIHOC_BACKUP_UNAVAILABLE'})}};
function setProvider(p){if(!p||typeof p.status!=='function'||typeof p.requestBackup!=='function'||typeof p.requestRestoreDrill!=='function')throw new Error('Invalid infrastructure provider');provider=p}
function P(){return provider||unavailable}
async function status(){return P().status()}
async function requestBackup(opts={}){const auth=window.MAIHOC_AUTH;if(auth)await auth.requireRole('super_admin');return P().requestBackup({...opts,requestedAt:new Date().toISOString()})}
async function requestRestoreDrill(opts={}){const auth=window.MAIHOC_AUTH;if(auth)await auth.requireRole('super_admin');return P().requestRestoreDrill({...opts,requestedAt:new Date().toISOString()})}
window.MAIHOC_INFRA={setProvider,status,requestBackup,requestRestoreDrill};
})();
