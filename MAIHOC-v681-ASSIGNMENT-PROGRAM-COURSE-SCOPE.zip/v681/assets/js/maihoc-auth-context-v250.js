(()=>{'use strict';
const cfg=()=>window.MAIHOC_CONFIG||{};let provider=null;
const local={name:'local-demo',async get(){let sess=null;try{sess=JSON.parse(localStorage.getItem('maihoc.demo.session')||'null')}catch{};const role=localStorage.getItem('maihoc_active_role')||localStorage.getItem('maihoc.activeRole')||sess?.role||'student';return{verified:false,mode:'demo',userId:sess?.userId||sess?.id||null,roles:[role],scopes:[],source:'browser-demo'}}};
const server={name:'server',async get(){const base=cfg().rest||'/wp-json/maihoc/v1/';const headers=cfg().nonce?{'X-WP-Nonce':cfg().nonce}:{};const r=await fetch(base+'me',{credentials:'same-origin',headers});if(!r.ok)throw Object.assign(new Error('Server authentication required'),{code:'MAIHOC_AUTH_REQUIRED'});const me=await r.json();return{verified:true,mode:'production',userId:me.id||me.user_id,roles:me.roles||[],scopes:me.scopes||[],organizationIds:me.organization_ids||[],source:'server'}}};
function mode(){return cfg().environment==='production'||cfg().production===true?'production':'demo'}
function setProvider(p){if(!p||typeof p.get!=='function')throw new Error('Invalid auth provider');provider=p}
async function context(){const p=provider||(mode()==='production'?server:local),c=await p.get();if(mode()==='production'&&!c?.verified)throw Object.assign(new Error('Unverified client identity rejected'),{code:'MAIHOC_AUTH_UNVERIFIED'});return c}
async function requireRole(...roles){const c=await context();if(!roles.some(r=>(c.roles||[]).includes(r)))throw Object.assign(new Error('Forbidden'),{code:'MAIHOC_FORBIDDEN'});return c}
window.MAIHOC_AUTH={mode,context,requireRole,setProvider,providers:{local,server}};
})();
