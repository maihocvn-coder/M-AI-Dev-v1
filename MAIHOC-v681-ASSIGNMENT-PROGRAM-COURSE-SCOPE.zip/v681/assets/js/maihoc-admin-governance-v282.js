(()=>{'use strict';
const VERSION='v282';
const K={content:'maihoc.content.governance.v282',staff:'maihoc.staff.management.v282',roles:'maihoc.custom.roles.v282',time:'maihoc.work.time.v282'};
const AUTHORITY={student:10,parent:20,teacher:30,admin:40,curriculum_designer:45,curriculum_admin:50,management_admin:70,super_admin:100};
const ROLE_LABELS={student:'Student',parent:'Parent',teacher:'Teacher',teaching_assistant:'Teaching Assistant',admin:'Organizational Admin',curriculum_designer:'Curriculum Designer',curriculum_admin:'Curriculum Admin',management_admin:'Management Admin',super_admin:'Super Admin'};
const SECTION_ORDER=['super','management','curriculum','organization'];
const SECTIONS={
 super:{label:'SUPER ADMINISTRATION',min:100},
 management:{label:'MANAGEMENT ADMINISTRATION',min:70},
 curriculum:{label:'CURRICULUM ADMINISTRATION',min:50},
 organization:{label:'ORGANIZATION ADMINISTRATION',min:40}
};
const FUNCTIONS=[
 {id:'system.control',section:'super',label:'System Control',icon:'⚙',href:'../features/home.html',desc:'Global platform settings and feature controls.'},
 {id:'admin.control',section:'super',label:'Admin Control',icon:'👥',href:'../admin-control/home.html',desc:'Manage platform administrators and sensitive access.'},
 {id:'system.restore',section:'super',label:'Restore Center',icon:'↩',href:'../recovery-center/home.html',desc:'Restore revisions and selected records from history.'},
 {id:'subscription.manage',section:'super',label:'Subscription & Pricing',icon:'💳',href:'../subscription/home.html',desc:'Global subscription switches, plans and pricing.'},
 {id:'people.manage',section:'management',label:'People & Teams',icon:'👥',href:'../platform-people/home.html',desc:'Departments, teams, managers, staff assignments and scope.'},
 {id:'roles.manage',section:'management',label:'Roles & Permissions',icon:'🔐',href:'../role-feature-access/home.html',desc:'Create staff roles and assign permissions and scope.'},
 {id:'analytics.management',section:'management',label:'Management Analytics',icon:'📊',href:'../analytics/home.html',desc:'Analyze work by department, role, group or individual.'},
 {id:'payroll.manage',section:'management',label:'Payroll & Rates',icon:'💵',href:'../management-payroll/home.html',desc:'Rates, time, compensation and payroll approval.'},
 {id:'work.manage',section:'management',label:'Time & Work',icon:'⏱',href:'../management-admin/work.html',desc:'Assignments, active work time and completion history.'},
 {id:'content.release',section:'management',label:'Content Release',icon:'🚀',href:'../content-release/home.html',desc:'Release approved content and choose audience/entitlement.'},
 {id:'organizations.manage',section:'management',label:'Organizations Browser',icon:'🏢',href:'../organizations/home.html',desc:'Browse and search organizations, then open the selected organization context. Sample Organization remains available as a sample organization.'},
 {id:'operations.manage',section:'management',label:'Operations',icon:'🧭',href:'../management-admin/operations.html',desc:'Sales, support, IT and operational work queues.'},
 {id:'guide.manage',section:'management',label:'Guide Manager',icon:'🧭',href:'../../account/guide/home.html?manage=1',desc:'Maintain role guides, onboarding steps and contextual help.'},
 {id:'content.audit',section:'curriculum',label:'Content Audit',icon:'✓',href:'../content-audit/home.html',desc:'Human review, additional review, approval and history.'},
 {id:'content.edit',section:'curriculum',label:'Content Studio (Pages)',icon:'✎',href:'../content-studio/home.html',desc:'Create and edit canonical content. New content begins as Draft.'},
 {id:'learning.resources',section:'curriculum',label:'Learning Resources',icon:'📚',href:'../learning-resources/home.html',desc:'Question banks, worksheets, tests, slide decks, games and custom learning materials.'},
 {id:'game.design',section:'curriculum',label:'School English Game & Coin Rules',icon:'🎮',href:'../game-design/home.html',desc:'Configure game rewards and coin rules by grade without editing curriculum content.'},
 {id:'review.queue',section:'curriculum',label:'Review Queue',icon:'📋',href:'../content-audit/home.html?status=in_review',desc:'Assigned reviews, additional review and changes requested.'},
 {id:'curriculum.team',section:'curriculum',label:'Curriculum Team',icon:'👥',href:'../curriculum-team/home.html',desc:'Manage curriculum designers, assignments and review workload.'},
 {id:'curriculum.truth',section:'curriculum',label:'Curriculum Truth',icon:'📚',href:'../learning-objectives/home.html',desc:'Curriculum maps, learning objectives and content targets.'},
 {id:'content.analytics',section:'curriculum',label:'Content Analytics',icon:'📈',href:'../content-analytics/home.html',desc:'Review throughput, time, findings and content history.'},
 {id:'org.people',section:'organization',label:'People',icon:'👥',href:'../people/home.html',desc:'Manage teachers, students, parents and organization staff.'},
 {id:'org.teachers',section:'organization',label:'Teachers',icon:'🧑‍🏫',href:'../people/home.html?view=teachers',desc:'Start with a teacher, then manage that teacher’s courses, classes, students and activity.'},
 {id:'org.courses',section:'organization',label:'Courses & Classes',icon:'🏫',href:'../courses/home.html',desc:'Manage organization courses and classes without switching into Teacher role.'},
 {id:'org.assignments',section:'organization',label:'Assignments & Gradebook',icon:'📝',href:'../courses/home.html?view=assignments',desc:'Organization-level oversight of assignments, gradebook and academic activity.'},
 {id:'org.attendance',section:'organization',label:'Attendance',icon:'✓',href:'../reports/attendance.html',desc:'Review organization attendance and session records.'},
 {id:'org.analytics',section:'organization',label:'Organization Analytics',icon:'📊',href:'../organization-analytics/home.html',desc:'Organization-scoped academic and workforce analytics.'},
 {id:'org.website',section:'organization',label:'Organization Website',icon:'🌐',href:'../organization-website/home.html',desc:'Edit and publish this organization’s public website.'},
 {id:'org.settings',section:'organization',label:'Organization Settings',icon:'⚙️',href:'../settings/home.html',desc:'Configure this organization’s workspace and defaults.'},
 {id:'org.payroll',section:'organization',label:'Organization Payroll',icon:'💵',href:'../payroll/home.html',desc:'Organization staff rates and payroll where permitted.'}
];
function norm(v){v=String(v||'').toLowerCase().replace(/[- ]+/g,'_');return ['organization_admin','org_admin'].includes(v)?'admin':v}
function session(){try{return JSON.parse(localStorage.getItem('maihoc.demo.session')||'null')||{}}catch{return{}}}
function impersonation(){try{return JSON.parse(sessionStorage.getItem('maihoc.impersonation.v207')||'null')}catch{return null}}
function effectiveSession(){const s=session(),i=impersonation();return i?{...s,userId:i.targetUserId||s.userId,activeRole:i.targetRole||s.activeRole,organizationId:i.organizationId||s.organizationId,impersonating:true,actorUserId:i.actorUserId,actorRole:i.actorRole}:s}
function role(){return norm(effectiveSession().activeRole||'student')}
function level(r=role()){return AUTHORITY[norm(r)]||0}
function can(id,r=role()){
 const lv=level(r),f=FUNCTIONS.find(x=>x.id===id);if(!f)return false;
 if(r==='super_admin')return true;
 if(r==='curriculum_designer')return ['content.edit','review.queue'].includes(id);
 const min=SECTIONS[f.section]?.min||999;if(r==='curriculum_designer'&&f.section==='curriculum'){return ['content.edit','review.queue'].includes(id)}if(lv<min)return false;
 const acl=window.MAIHOC_ACL?.canFunction?.(id,effectiveSession());return acl===false?false:true;
}
function visibleSections(r=role()){return SECTION_ORDER.filter(s=>level(r)>=(SECTIONS[s]?.min||999)||(r==='curriculum_designer'&&s==='curriculum')).map(s=>({...SECTIONS[s],id:s,functions:FUNCTIONS.filter(f=>f.section===s&&can(f.id,r))})).filter(s=>s.functions.length)}
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key)||'null')??fallback}catch{return fallback}}
function write(key,v){localStorage.setItem(key,JSON.stringify(v));return v}
function now(){return new Date().toISOString()}
function actor(){const s=effectiveSession();return {userId:s.userId||s.id||'demo',name:s.name||s.user||'Demo User',role:role(),impersonating:!!s.impersonating,actorUserId:s.actorUserId||null}}
function contentStore(){let x=read(K.content,null);if(x)return x;const samples=[];for(let g=1;g<=12;g++){for(let i=1;i<=3;i++)samples.push({itemId:`G${g}U01-DEMO-Q00${i}`,revisionId:'r1',grade:g,unit:1,type:'question',skill:i===1?'Vocabulary':i===2?'Pronunciation':'Sentence/Grammar',prompt:`Grade ${g} sample review item ${i}`,status:'legacy_published',legacy:true,approved:false,seal:false,createdBy:'Existing content baseline',createdAt:'2026-09-29T00:00:00Z',updatedAt:'2026-09-29T00:00:00Z',history:[{at:'2026-09-29T00:00:00Z',action:'MIGRATED_LEGACY',actor:'System',role:'system'}]})}return write(K.content,{items:samples,version:VERSION})}
function log(item,action,note,extra={}){item.history=item.history||[];const a=actor();item.history.push({at:now(),action,note:note||'',actor:a.name,userId:a.userId,role:a.role,...extra});item.updatedAt=now();return item}
function transition(itemId,action,note=''){const s=contentStore(),it=s.items.find(x=>x.itemId===itemId);if(!it)throw Error('Content item not found');const r=role();
 const map={submit:'in_review',additional_review:'needs_additional_review',changes:'changes_requested',approve:'approved',remove:'removed',publish:'published',hold:'release_review'};
 if(action==='approve'&&!['curriculum_admin','management_admin','super_admin'].includes(r))throw Error('Final approval requires Curriculum Admin or higher.');
 if(action==='publish'&&!['management_admin','super_admin'].includes(r))throw Error('Publishing requires Management Admin or Super Admin.');
 if(action==='edit'){const n=Number(String(it.revisionId||'r1').replace(/\D/g,''))||1;it.revisionId='r'+(n+1);it.status='draft';it.approved=false;it.seal=false;it.approvedBy=null;it.approvedAt=null;log(it,'EDIT_NEW_REVISION',note,{sourceRevision:'r'+n});write(K.content,s);return it}
 it.status=map[action]||it.status;if(action==='approve'){it.approved=true;it.seal=true;it.approvedBy=actor();it.approvedAt=now()}if(action==='remove')it.active=false;if(action==='publish'){it.publishedAt=now();it.releasePolicy=it.releasePolicy||{audience:['free','subscribed'],organizations:'all'}}log(it,action.toUpperCase(),note);write(K.content,s);return it}
function createDraft(data={}){const s=contentStore(),a=actor(),id=data.itemId||`DRAFT-${Date.now()}`;const it={itemId:id,revisionId:'r1',type:data.type||'question',grade:data.grade||'',unit:data.unit||'',skill:data.skill||'',prompt:data.prompt||'New draft',status:'draft',legacy:false,approved:false,seal:false,createdBy:a.name,createdAt:now(),updatedAt:now(),history:[]};log(it,'CREATED_DRAFT','New content is draft by policy');s.items.unshift(it);write(K.content,s);return it}
function bulk(ids,action,note=''){return ids.map(id=>transition(id,action,note))}
function metrics(){const s=contentStore().items;const counts={};s.forEach(x=>counts[x.status]=(counts[x.status]||0)+1);return {total:s.length,counts}}
window.MAIHOC_GOV={VERSION,K,AUTHORITY,ROLE_LABELS,SECTIONS,FUNCTIONS,norm,session,impersonation,effectiveSession,role,level,can,visibleSections,contentStore,transition,createDraft,bulk,metrics,actor};
})();