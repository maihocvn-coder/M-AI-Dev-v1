(()=>{'use strict';
const now=()=>new Date().toISOString();
// Session make-up invariant API.
function eligibleSources(session){const C=window.MAIHOC_CAL;if(!C)return[];return C.load().sessions.filter(s=>s.id!==session?.id&&s.classId===session?.classId&&['cancelled','cancelled_today','missed'].includes(s.status)&&!C.load().sessions.some(m=>m.status==='makeup'&&m.makeupForSessionId===s.id&&m.id!==session?.id));}
function validateMakeup(session){if(session?.status!=='makeup')return{ok:true};if(!session.makeupForSessionId)return{ok:false,error:'Choose the cancelled/missed session this make-up replaces.'};const src=window.MAIHOC_CAL?.load().sessions.find(s=>s.id===session.makeupForSessionId);if(!src)return{ok:false,error:'The source session no longer exists.'};if(src.id===session.id||src.classId!==session.classId)return{ok:false,error:'A make-up must replace a different session in the same class.'};if(!['cancelled','cancelled_today','missed'].includes(src.status))return{ok:false,error:'Make-up source must be cancelled or missed.'};return{ok:true,source:src};}
function saveSession(session){const v=validateMakeup(session);if(!v.ok)throw Object.assign(new Error(v.error),{code:'MAIHOC_INVALID_MAKEUP'});return window.MAIHOC_CAL.upsertSession({...session,makeupForSessionId:session.status==='makeup'?session.makeupForSessionId:null,updatedAt:now()});}
window.MAIHOC_SESSION_FLOW={eligibleSources,validateMakeup,saveSession,STATUSES:['scheduled','in_progress','completed','cancelled_today','makeup']};
// Universal action audit registry. Pages can register state verifiers; unregistered visible actions are reported.
const registry=new Map();function register(id,contract){registry.set(id,contract)}
async function run(root=document){const rows=[];for(const el of root.querySelectorAll('button,[role=button],input[type=submit]')){if(el.disabled||el.hidden)continue;const id=el.id||el.dataset.action||el.textContent.trim().slice(0,60);const c=registry.get(id);rows.push({id,bound:!!(el.onclick||c||el.dataset.actionBound==='true'),contract:!!c,kind:c?.kind||'ui'});}return rows}
window.MAIHOC_ACTION_AUDIT={register,run,registry};
})();
