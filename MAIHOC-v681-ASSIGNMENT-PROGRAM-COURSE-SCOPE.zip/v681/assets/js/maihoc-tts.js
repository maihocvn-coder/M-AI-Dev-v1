(()=>{'use strict';
const KEY='maihoc.tts.config.v1';
const DEFAULT={lang:'en-GB',voiceName:'',voiceURI:'',rate:.85,pitch:1,genderPreference:'female'};
let serverLoaded=false;
function localConfig(){try{return {...DEFAULT,...JSON.parse(localStorage.getItem(KEY)||'{}'),lang:'en-GB'}}catch{return {...DEFAULT}}}
function saveLocal(c){const clean={...DEFAULT,...c,lang:'en-GB'};try{localStorage.setItem(KEY,JSON.stringify(clean))}catch{};window.dispatchEvent(new CustomEvent('maihoc:tts-config',{detail:clean}));return clean}
function voices(){return ('speechSynthesis'in window)?speechSynthesis.getVoices():[]}
function britishVoices(){return voices().filter(v=>String(v.lang||'').toLowerCase().startsWith('en-gb'))}
function resolveVoice(c=localConfig()){
 const vs=britishVoices(); if(!vs.length)return null;
 return vs.find(v=>c.voiceURI&&v.voiceURI===c.voiceURI)||vs.find(v=>c.voiceName&&v.name===c.voiceName)||vs.find(v=>/serena|kate|susan|stephanie|martha|female|samantha|victoria/i.test(v.name))||vs.find(v=>/daniel|oliver|arthur/i.test(v.name))||vs.find(v=>v.default)||vs[0];
}
function speak(text,opts={}){if(!text||!('speechSynthesis'in window))return false;const c={...localConfig(),...opts,lang:'en-GB'};const u=new SpeechSynthesisUtterance(String(text));u.lang='en-GB';u.rate=Number(c.rate)||.85;u.pitch=Number(c.pitch)||1;const v=resolveVoice(c);if(v)u.voice=v;if(typeof opts.onend==='function')u.onend=opts.onend;if(typeof opts.onerror==='function')u.onerror=opts.onerror;speechSynthesis.cancel();speechSynthesis.speak(u);return true}
async function loadServer(){if(serverLoaded)return localConfig();serverLoaded=true;try{const base=window.MAIHOC_CONFIG?.rest||'/wp-json/maihoc/v1/';const r=await fetch(base+'appearance',{credentials:'same-origin'});if(r.ok){const d=await r.json();if(d?.tts){return saveLocal(d.tts)}}}catch{}return localConfig()}
window.MAIHOC_TTS={KEY,DEFAULT,getConfig:localConfig,saveLocal,voices,britishVoices,resolveVoice,speak,loadServer};
if('speechSynthesis'in window&&speechSynthesis.onvoiceschanged!==undefined)speechSynthesis.addEventListener('voiceschanged',()=>window.dispatchEvent(new Event('maihoc:tts-voices')));
loadServer();
})();