(()=>{'use strict';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const isPron=q=>/^(pronunciation|phonics)$/i.test(String(q?.skill||''));
const target=q=>{if(!isPron(q))return '';if(q?.targetPhoneme)return q.targetPhoneme;const text=[q?.targetPhoneme,q?.phonicsTarget,q?.prompt,q?.stimulus].filter(Boolean).join(' ');return text.match(/\/([^/]{1,6})\//)?.[1]||''};
function playPhoneme(p){return !!window.MAIHOC_PHONEME_AUDIO?.play(p)}
function playWord(w){return !!window.MAIHOC_TTS?.speak(String(w||''),{lang:'en-GB'})}
function audioButton(label,kind,value){const b=document.createElement('button');b.type='button';b.className='mh-pron-audio';b.textContent='🔊 '+label;b.dataset.audioKind=kind;b.onclick=e=>{e.preventDefault();e.stopPropagation();kind==='phoneme'?playPhoneme(value):playWord(value)};return b}
function decorateQuestion(q){if(!window.MAIHOC_IS_QUESTION_ACTIVE?.())return;if(!isPron(q))return;const p=target(q);if(!p)return;const stim=document.getElementById('stimulus');if(stim&&!stim.querySelector('[data-audio-kind="phoneme"]')){stim.hidden=false;stim.append(audioButton('Nghe âm /'+p+'/','phoneme',p))}
 // Word audio is a separate pipeline. Never send /IPA/ to word TTS.
 document.querySelectorAll('#answers .answer-row').forEach((row,i)=>{if(row.querySelector('.option-audio'))return;const word=q.options?.[i];if(!word)return;row.append(audioButton('','word',word))});
}
function installStyles(){if(document.getElementById('mhPronV254Style'))return;const s=document.createElement('style');s.id='mhPronV254Style';s.textContent=`.mh-pron-audio{margin-left:10px;border:1px solid #b9def5;background:#fff;border-radius:14px;padding:9px 12px;font-weight:800;color:#173b5c;cursor:pointer}.sage-audio-row{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.sage-quiz .sage-word-choice{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;margin:8px 0}.sage-quiz .sage-word-choice>button:first-child{width:100%}`;document.head.append(s)}
addEventListener('DOMContentLoaded',()=>{installStyles();const q=window.MAIHOC_CURRENT_QUESTION?.();if(q&&window.MAIHOC_IS_QUESTION_ACTIVE?.())decorateQuestion(q)});
addEventListener('maihoc:questionchange',e=>setTimeout(()=>decorateQuestion(e.detail?.question||window.MAIHOC_CURRENT_QUESTION?.()),0));
window.MAIHOC_PRONUNCIATION={target,isPron,playPhoneme,playWord,audioButton,decorateQuestion};
})();
/* v255: never substitute a wrong consonant model or TTS for missing IPA audio. */
window.addEventListener('maihoc:phoneme-audio-unavailable',e=>{
 const p=e.detail?.phoneme||'';
 document.querySelectorAll('[data-audio-kind="phoneme"], [data-sage-phoneme]').forEach(b=>{
   const v=b.dataset.sagePhoneme||'';
   if(!v || String(v).replace(/^\//,'').replace(/\/$/,'')===p){b.title='Âm /'+p+'/ đang chờ audio mẫu đã được kiểm duyệt';}
 });
});
