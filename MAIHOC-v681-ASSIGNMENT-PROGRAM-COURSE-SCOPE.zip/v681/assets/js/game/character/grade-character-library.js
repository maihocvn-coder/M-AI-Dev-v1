(()=>{'use strict';
/* M-AI mascot library v653 — CUTE + DISTINCT.
   Character artwork only. Movement/contact/emotion authorities are untouched.
   Design contract: recognizable silhouette at thumbnail size, rounded professional
   storybook shapes, expressive face, species-specific anatomy, no shared bean body. */
const O='#6b3f25',INK='#173a58',HI='#fffdf7',CREAM='#fff0d2',PINK='#f5a7ad';
const gradeMascot={1:'cat',2:'bunny',3:'duck',4:'frog',5:'poodle',6:'shiba',7:'tiger',8:'raccoon',9:'red-panda',10:'penguin',11:'koala',12:'snow-leopard'};
const meta={
 cat:{name:'Cat',feature:'triangle ears · whiskers · curled tail'},
 bunny:{name:'Bunny',feature:'long ears · big hind feet · cotton tail'},
 duck:{name:'Duckling',feature:'wide bill · wings · webbed feet'},
 frog:{name:'Frog',feature:'eye bumps · wide smile · webbed feet'},
 poodle:{name:'Fancy Poodle',feature:'slim body · sculpted fluffy ears · bracelets · pom tail'},
 shiba:{name:'City Shiba',feature:'round fox-like face · small triangle ears · cream cheeks · curled tail · blue explorer scarf'},
 tiger:{name:'Tiger',feature:'cheek fluff · tiger stripes · strong paws'},
 raccoon:{name:'Raccoon',feature:'face mask · pointed muzzle · huge ring tail'},
 'red-panda':{name:'Red Panda',feature:'round face · cream cheeks · tiny paws · giant striped tail'},
 penguin:{name:'Penguin',feature:'round tuxedo body · flipper arms · orange feet'},
 koala:{name:'Koala',feature:'giant fluffy ears · round nose · cuddly belly'},
 'snow-leopard':{name:'Snow Leopard',feature:'round ears · rosettes · enormous cloud tail'}
};
const svg=(label,body)=>`<svg viewBox="0 0 140 150" role="img" aria-label="${label}" preserveAspectRatio="xMidYMid meet"><g class="mh-mascot-art" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
const eye=(x,y,r=4.4)=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r+1}" fill="${INK}"/><circle cx="${x-1.4}" cy="${y-1.8}" r="1.35" fill="#fff"/>`;
const blush=(x,y)=>`<ellipse cx="${x}" cy="${y}" rx="5" ry="2.7" fill="${PINK}" opacity=".48"/>`;
const smile=(x,y,w=12)=>`<path d="M${x-w/2} ${y}Q${x} ${y+8} ${x+w/2} ${y}" fill="none" stroke="${O}" stroke-width="3"/>`;
function cat(){return svg('Cat',`
 <path d="M101 96C126 92 127 68 116 61" fill="none" stroke="#f39a3f" stroke-width="12"/><path d="M101 96C126 92 127 68 116 61" fill="none" stroke="${O}" stroke-width="4"/>
 <path d="M36 48L28 18 55 35M104 48l8-30-27 17" fill="#f6a23f" stroke="${O}" stroke-width="5"/>
 <ellipse cx="70" cy="83" rx="40" ry="48" fill="#f6a23f" stroke="${O}" stroke-width="5"/>
 <path d="M39 46l-5-18 15 12m52 6 5-18-15 12" fill="#f8bd73"/>
 ${eye(56,65)}${eye(84,65)}<path d="M66 77h8l-4 6Z" fill="#8a5435"/>${smile(70,83,15)}${blush(48,80)}${blush(92,80)}
 <g stroke="${O}" stroke-width="2.4"><path d="M52 80 29 76M52 86 28 91M88 80l23-4M88 86l24 5"/></g>
 <path d="M48 119q-2 16 8 18m36-18q2 16-8 18" fill="none" stroke="${O}" stroke-width="7"/>`)}
function bunny(){return svg('Bunny',`
 <circle cx="112" cy="107" r="13" fill="#fff8ef" stroke="${O}" stroke-width="5"/>
 <path d="M50 49C36 34 34 5 47 5c12 0 15 29 16 44M77 49C78 23 82 4 94 8c13 5 4 31-5 46" fill="#fff8ef" stroke="${O}" stroke-width="5"/>
 <path d="M48 39C44 24 44 14 48 13c5 1 7 14 8 27m29 1c2-14 5-25 9-25 4 2 2 14-3 27" fill="none" stroke="#f5b6bb" stroke-width="5"/>
 <ellipse cx="70" cy="87" rx="39" ry="43" fill="#fff8ef" stroke="${O}" stroke-width="5"/>
 ${eye(56,70)}${eye(84,70)}<path d="M66 82q4-5 8 0-4 6-8 0" fill="#e68f98"/><path d="M70 87v5" stroke="${O}" stroke-width="2.5"/>${smile(70,91,15)}${blush(48,87)}${blush(92,87)}
 <ellipse cx="43" cy="128" rx="17" ry="9" fill="#fff8ef" stroke="${O}" stroke-width="5"/><ellipse cx="97" cy="128" rx="17" ry="9" fill="#fff8ef" stroke="${O}" stroke-width="5"/>`)}
function duck(){return svg('Duckling',`
 <path d="M36 71Q18 76 24 103q7 14 22 8M104 71q18 5 12 32-7 14-22 8" fill="#ffd75e" stroke="${O}" stroke-width="5"/>
 <ellipse cx="70" cy="88" rx="39" ry="46" fill="#ffd75e" stroke="${O}" stroke-width="5"/><path d="M45 54Q53 34 70 38q17-4 25 16" fill="#ffe58b"/>
 ${eye(56,65)}${eye(84,65)}<path d="M49 78Q70 65 91 78 70 94 49 78Z" fill="#f49a3f" stroke="${O}" stroke-width="4"/><path d="M55 79h30" stroke="#d97828" stroke-width="2"/>
 ${blush(43,82)}${blush(97,82)}
 <path d="M51 127v8m-10 4 10-4 10 4m28-12v8m-10 4 10-4 10 4" stroke="#e88a31" stroke-width="5" fill="none"/>`)}
function frog(){return svg('Frog',`
 <path d="M30 91Q16 104 18 127l25-10M110 91q14 13 12 36l-25-10" fill="#79d47b" stroke="${O}" stroke-width="6"/>
 <ellipse cx="70" cy="91" rx="43" ry="38" fill="#79d47b" stroke="${O}" stroke-width="5"/>
 <circle cx="48" cy="52" r="17" fill="#79d47b" stroke="${O}" stroke-width="5"/><circle cx="92" cy="52" r="17" fill="#79d47b" stroke="${O}" stroke-width="5"/>
 ${eye(48,51,4.8)}${eye(92,51,4.8)}<ellipse cx="70" cy="99" rx="25" ry="20" fill="#cdef9f"/>
 <path d="M47 76Q70 96 93 76" fill="none" stroke="${O}" stroke-width="4"/>${blush(39,73)}${blush(101,73)}
 <path d="M20 127l-8 7m8-7 2 10m98-10 8 7m-8-7-2 10" stroke="${O}" stroke-width="4"/>`)}
function poodle(){return svg('Fancy Poodle',`
 <!-- iconic pom tail --> <path d="M98 92q23-7 22 14" fill="none" stroke="${O}" stroke-width="4"/><circle cx="121" cy="106" r="13" fill="#f4dfcb" stroke="${O}" stroke-width="4"/>
 <!-- slim clipped torso --> <path d="M55 80Q48 96 52 116L58 127H82l6-11q4-20-3-36Z" fill="#fffaf2" stroke="${O}" stroke-width="5"/>
 <!-- long legs --> <path d="M58 112v23m24-23v23" stroke="#fffaf2" stroke-width="10"/><path d="M58 112v23m24-23v23" stroke="${O}" stroke-width="3" fill="none"/>
 <!-- ankle bracelets --> <circle cx="58" cy="128" r="10" fill="#f4dfcb" stroke="${O}" stroke-width="4"/><circle cx="82" cy="128" r="10" fill="#f4dfcb" stroke="${O}" stroke-width="4"/><path d="M58 136v5m24-5v5" stroke="${O}" stroke-width="5"/>
 <!-- long fluffy sculpted ears --> <path d="M48 46Q25 43 27 68q0 20 19 22l8-17Z" fill="#dcae86" stroke="${O}" stroke-width="5"/><path d="M92 46q23-3 21 22 0 20-19 22l-8-17Z" fill="#dcae86" stroke="${O}" stroke-width="5"/>
 <!-- face --> <ellipse cx="70" cy="59" rx="27" ry="26" fill="#fffaf2" stroke="${O}" stroke-width="5"/>
 <!-- cloud topknot --> <path d="M50 38q-5-13 8-17 5-12 16-5 12-5 17 6 12 6 3 17Z" fill="#f4dfcb" stroke="${O}" stroke-width="4"/>
 ${eye(59,57,4)}${eye(81,57,4)}<ellipse cx="70" cy="69" rx="6" ry="4.5" fill="${O}"/>${smile(70,75,13)}${blush(51,71)}${blush(89,71)}
 <!-- poodle chest puff --> <path d="M54 84q16-12 32 0-2 13-16 13T54 84Z" fill="#f4dfcb" stroke="${O}" stroke-width="3"/>`)}
function shiba(){return svg('City Shiba',`
 <!-- fluffy curled Shiba tail: unmistakable silhouette -->
 <path d="M101 100q28-9 27 15-1 17-20 14-11-2-9-13 2-8 11-2" fill="#f0a04a" stroke="${O}" stroke-width="5"/>
 <!-- compact pear-shaped body, separate from head -->
 <ellipse cx="70" cy="103" rx="31" ry="34" fill="#efa14b" stroke="${O}" stroke-width="5"/>
 <ellipse cx="70" cy="111" rx="20" ry="23" fill="#fff2d6"/>
 <!-- small triangular ears, not giant corgi ears -->
 <path d="M43 47 39 21 58 38M97 47l4-26-19 17" fill="#efa14b" stroke="${O}" stroke-width="5"/>
 <path d="M46 39 44 29l9 9m41 1 2-10-9 9" fill="#f6c98b"/>
 <!-- round Shiba head + cream cheek mask -->
 <circle cx="70" cy="65" r="31" fill="#efa14b" stroke="${O}" stroke-width="5"/>
 <path d="M45 65q7-18 25-9 18-9 25 9-4 18-25 23-21-5-25-23Z" fill="#fff2d6"/>
 ${eye(57,61,4.2)}${eye(83,61,4.2)}
 <ellipse cx="70" cy="71" rx="6" ry="4.5" fill="#5b3927"/>
 <path d="M62 78q8 8 16 0" fill="none" stroke="${O}" stroke-width="3"/>
 ${blush(47,75)}${blush(93,75)}
 <!-- explorer scarf -->
 <path d="M45 86q25 10 50 0l-5 12q-20 7-40 0Z" fill="#43a9d8" stroke="${O}" stroke-width="3"/>
 <path d="M91 94l13 8-12 7-7-11Z" fill="#43a9d8" stroke="${O}" stroke-width="3"/>
 <!-- tiny sturdy paws -->
 <ellipse cx="52" cy="133" rx="13" ry="7" fill="#fff2d6" stroke="${O}" stroke-width="4"/>
 <ellipse cx="88" cy="133" rx="13" ry="7" fill="#fff2d6" stroke="${O}" stroke-width="4"/>
 `)}
function tiger(){return svg('Tiger',`
 <path d="M103 97q27 4 22 34" fill="none" stroke="#f39a38" stroke-width="12"/><path d="M111 104l10 4m-11 10 12 5" stroke="${O}" stroke-width="3"/>
 <path d="M34 50 27 20l27 17M106 50l7-30-27 17" fill="#f39a38" stroke="${O}" stroke-width="5"/>
 <path d="M31 64Q25 39 48 35q22-12 44 0 23 4 17 29v45q0 28-39 28t-39-28Z" fill="#f39a38" stroke="${O}" stroke-width="5"/>
 <path d="M34 62 21 70l13 8m72-16 13 8-13 8" fill="#f39a38" stroke="${O}" stroke-width="4"/>
 <path d="M70 38v15M45 47l12 11m38-11L83 58" stroke="${O}" stroke-width="4"/>${eye(55,67)}${eye(85,67)}
 <ellipse cx="70" cy="86" rx="21" ry="16" fill="${CREAM}"/><path d="M65 80h10l-5 6Z" fill="${O}"/>${smile(70,88,15)}${blush(44,84)}${blush(96,84)}
 <ellipse cx="48" cy="131" rx="12" ry="7" fill="#e98931" stroke="${O}" stroke-width="4"/><ellipse cx="92" cy="131" rx="12" ry="7" fill="#e98931" stroke="${O}" stroke-width="4"/>`)}
function raccoon(){return svg('Raccoon',`
 <!-- huge striped tail is the silhouette --> <path d="M96 91q34-3 36 28-6 23-34 13" fill="#aab3b7" stroke="${O}" stroke-width="8"/><path d="M108 94q9 2 15 8m-18 5q13 3 21 10m-23 3q11 2 18 9" stroke="#566168" stroke-width="6"/>
 <path d="M36 52 29 26l25 14M104 52l7-26-25 14" fill="#aab3b7" stroke="${O}" stroke-width="5"/>
 <ellipse cx="70" cy="88" rx="39" ry="48" fill="#aab3b7" stroke="${O}" stroke-width="5"/>
 <path d="M38 60Q70 42 102 60L91 83Q70 73 49 83Z" fill="#505c64"/>
 ${eye(55,66,4)}${eye(85,66,4)}<path d="M52 79Q70 66 88 79L70 96Z" fill="${CREAM}"/><ellipse cx="70" cy="80" rx="6" ry="4" fill="${O}"/>${smile(70,88,13)}
 <path d="M48 124v10m44-10v10" stroke="${O}" stroke-width="7"/>`)}
function redPanda(){return svg('Red Panda',`
 <path d="M96 91q36-8 39 24 1 24-32 28" fill="none" stroke="#d96f3f" stroke-width="19"/><path d="M96 91q36-8 39 24 1 24-32 28" fill="none" stroke="${O}" stroke-width="4"/><path d="M113 91l-5 16m22-4-19 8m22 9-20 1m14 13-18-5" stroke="#8c4d36" stroke-width="6"/>
 <path d="M37 52 31 27l24 13M103 52l6-25-24 13" fill="#d96f3f" stroke="${O}" stroke-width="5"/><ellipse cx="70" cy="87" rx="39" ry="47" fill="#d96f3f" stroke="${O}" stroke-width="5"/>
 <path d="M43 56q12-14 27-8 15-6 27 8L89 78q-9-8-19-4-10-4-19 4Z" fill="#fff0d2"/>${eye(55,64,4.4)}${eye(85,64,4.4)}<ellipse cx="70" cy="79" rx="17" ry="13" fill="#fff0d2"/><ellipse cx="70" cy="76" rx="6" ry="4" fill="${O}"/>${smile(70,83,12)}${blush(45,82)}${blush(95,82)}
 <path d="M49 121v13m42-13v13" stroke="#4b382f" stroke-width="8"/><ellipse cx="49" cy="136" rx="11" ry="5" fill="#4b382f"/><ellipse cx="91" cy="136" rx="11" ry="5" fill="#4b382f"/>`)}
function penguin(){return svg('Penguin',`
 <path d="M42 72Q19 83 24 111l22-9M98 72q23 11 18 39l-22-9" fill="#263d4f" stroke="${O}" stroke-width="5"/><path d="M40 58Q44 30 70 29q26 1 30 29l8 51q2 29-38 29t-38-29Z" fill="#263d4f" stroke="${O}" stroke-width="5"/>
 <path d="M50 56q20-18 40 0l5 54q0 20-25 20t-25-20Z" fill="#fff8ea"/>${eye(57,58,4)}${eye(83,58,4)}<path d="M60 72 70 65l10 7-10 8Z" fill="#f3a33b" stroke="${O}" stroke-width="3"/>${blush(48,76)}${blush(92,76)}
 <path d="M55 130q-17 2-20 10h28Zm30 0q17 2 20 10H77Z" fill="#f3a33b" stroke="${O}" stroke-width="4"/><path d="M58 88 70 94 82 88v18l-12-6-12 6Z" fill="#55b8b1" stroke="${O}" stroke-width="3"/>`)}
function koala(){return svg('Koala',`
 <circle cx="39" cy="56" r="23" fill="#aeb8bd" stroke="${O}" stroke-width="5"/><circle cx="101" cy="56" r="23" fill="#aeb8bd" stroke="${O}" stroke-width="5"/><circle cx="39" cy="56" r="13" fill="#e7d9cf"/><circle cx="101" cy="56" r="13" fill="#e7d9cf"/>
 <path d="M35 70q4-31 35-31t35 31v39q0 29-35 29t-35-29Z" fill="#aeb8bd" stroke="${O}" stroke-width="5"/><ellipse cx="70" cy="102" rx="25" ry="27" fill="#dce2df"/>
 ${eye(55,69,4.6)}${eye(85,69,4.6)}<ellipse cx="70" cy="82" rx="10" ry="8" fill="#3f4b50"/>${smile(70,91,13)}${blush(45,88)}${blush(95,88)}<ellipse cx="48" cy="106" rx="11" ry="9" fill="#9da9ae" stroke="${O}" stroke-width="4"/><ellipse cx="92" cy="106" rx="11" ry="9" fill="#9da9ae" stroke="${O}" stroke-width="4"/>
 <ellipse cx="51" cy="135" rx="12" ry="6" fill="#9da9ae" stroke="${O}" stroke-width="4"/><ellipse cx="89" cy="135" rx="12" ry="6" fill="#9da9ae" stroke="${O}" stroke-width="4"/>`)}
function snowLeopard(){return svg('Snow Leopard',`
 <!-- huge cloud tail --> <path d="M98 96q35-3 33 30-2 22-30 17-14-2-14-13" fill="none" stroke="#dce8ed" stroke-width="17"/><path d="M98 96q35-3 33 30-2 22-30 17-14-2-14-13" fill="none" stroke="${O}" stroke-width="4"/>
 <circle cx="43" cy="48" r="11" fill="#dce8ed" stroke="${O}" stroke-width="5"/><circle cx="97" cy="48" r="11" fill="#dce8ed" stroke="${O}" stroke-width="5"/>
 <path d="M31 63q6-25 39-25t39 25v47q0 28-39 28t-39-28Z" fill="#e5eef1" stroke="${O}" stroke-width="5"/>
 ${eye(55,66)}${eye(85,66)}<ellipse cx="70" cy="86" rx="21" ry="16" fill="${CREAM}"/><path d="M65 80h10l-5 6Z" fill="${O}"/>${smile(70,89,14)}${blush(44,84)}${blush(96,84)}
 <!-- soft rosettes, not disease-like outlined circles --> <g fill="#98a8ae"><path d="M42 54q6-5 11 1-6 5-11-1Z"/><path d="M87 54q6-5 11 1-6 5-11-1Z"/><path d="M39 101q6-5 11 1-6 5-11-1Z"/><path d="M90 102q6-5 11 1-6 5-11-1Z"/><path d="M55 116q5-4 10 1-5 4-10-1Z"/></g>
 <ellipse cx="49" cy="133" rx="12" ry="6" fill="#d6e3e8" stroke="${O}" stroke-width="4"/><ellipse cx="91" cy="133" rx="12" ry="6" fill="#d6e3e8" stroke="${O}" stroke-width="4"/>`)}
const builtins={cat,bunny,duck,frog,poodle,shiba,tiger,raccoon,'red-panda':redPanda,penguin,koala,'snow-leopard':snowLeopard};
function selectedMascot(g){g=Number(g)||1;try{const R=window.MAIHOC_GAME_REGISTRY;if(R&&R.get)return R.get(g,1).character||gradeMascot[g]||'cat'}catch(e){}return gradeMascot[g]||'cat'}
function renderMascot(id){if(builtins[id])return builtins[id]();try{const R=window.MAIHOC_GAME_REGISTRY,m=R&&R.mascots&&R.mascots.find(x=>x.id===id);if(m&&m.image)return `<img src="${String(m.image).replace(/"/g,'&quot;')}" alt="${String(m.name||'Game character').replace(/"/g,'&quot;')}" style="width:100%;height:100%;object-fit:contain;display:block">`;}catch(e){}return cat()}
function render(g){return renderMascot(selectedMascot(g))}
function refresh(root=document){root.querySelectorAll('.grade-character[data-grade]').forEach(el=>el.innerHTML=render(el.dataset.grade))}
window.MAIHOC_GRADE_CHARACTER={mascot:selectedMascot,render,renderMascot,refresh,defaults:Object.freeze({...gradeMascot}),meta:Object.freeze(meta)};
window.addEventListener('maihoc-game-setup-change',()=>refresh());
window.addEventListener('storage',e=>{if(e.key==='maihoc.schoolEnglish.gameSetup.v45'||e.key==='maihoc.schoolEnglish.customAssets.v1')refresh()});
})();
