/* M-AI Học — canonical Character Emotion Attachment Runtime.
   Presentation only. Semantic events choose emotions; this file never owns locomotion,
   jump/contact geometry, answer submission, carrier lifecycle, landing, or progression. */
(()=>{'use strict';
let timer=0, token=0;
const recipes=Object.freeze({
  happy:{id:'happy',duration:1450,fx:['glow','sparkles','hearts'],motion:'happy'},
  excited:{id:'excited',duration:1650,fx:['glow','sparkles','hearts','rays'],motion:'excited'},
  sad:{id:'sad',duration:2200,fx:['cool-tint','tears'],motion:'sad'},
  cry:{id:'cry',duration:3000,fx:['cool-tint','tear-stream','tear-splash','sob-cloud'],motion:'cry'},
  surprised:{id:'surprised',duration:1550,fx:['sweat','surprise'],motion:'surprised'},
  confused:{id:'confused',duration:2300,fx:['question-marks','thought-cloud'],motion:'confused'},
  dizzy:{id:'dizzy',duration:2200,fx:['impact','dizzy-stars'],motion:'dizzy'},
  celebrate:{id:'celebrate',duration:3000,fx:['confetti','sparkles','rays'],motion:'celebrate'},
  superCelebrate:{id:'super-celebrate',duration:3800,fx:['confetti','sparkles','rays','crown','hearts'],motion:'celebrate'}
});
const motionClasses=['happy','excited','sad','cry','surprised','confused','dizzy','celebrate'].map(x=>'mh-emotion-'+x);
function character(){return document.querySelector('[data-character-root]')||document.querySelector('.mse-character-root')||document.getElementById('cat')}
function layer(host){let el=host.querySelector(':scope > .mh-emotion-layer');if(!el){el=document.createElement('span');el.className='mh-emotion-layer';el.setAttribute('aria-hidden','true');host.appendChild(el)}return el}
function clear(host=character()){clearTimeout(timer);if(!host)return;host.classList.remove('mh-emotion-active',...motionClasses);delete host.dataset.emotion;delete host.dataset.emotionRecipe;const l=host.querySelector(':scope > .mh-emotion-layer');if(l)l.replaceChildren()}
function addFx(l,name){const el=document.createElement('span');el.className='mh-emotion-fx mh-emotion-fx-'+name;el.dataset.fx=name;
  const counts={'tears':4,'tear-stream':8,'tear-splash':5,'sparkles':7,'hearts':5,'dizzy-stars':5,'confetti':12,'rays':1,'sweat':1,'surprise':1,'impact':1,'sob-cloud':1,'crown':1,'glow':1,'cool-tint':1,'question-marks':3,'thought-cloud':1};
  const n=counts[name]||1;for(let i=0;i<n;i++){const b=document.createElement('i');b.style.setProperty('--i',i);b.style.setProperty('--n',n);el.appendChild(b)}l.appendChild(el)}
function react(emotion,detail={}){const host=character(),recipe=recipes[emotion];if(!host||!recipe)return;clear(host);const my=++token,l=layer(host);host.dataset.emotion=emotion;host.dataset.emotionRecipe=recipe.id;host.classList.add('mh-emotion-active','mh-emotion-'+recipe.motion);recipe.fx.forEach(x=>addFx(l,x));window.dispatchEvent(new CustomEvent('maihoc:characteremotion',{detail:{emotion,recipe:recipe.id,duration:recipe.duration,...detail}}));timer=setTimeout(()=>{if(my===token)clear(host)},recipe.duration)}
function onCorrect(detail={}){react(Number(detail.tries||1)===1?'excited':'happy',detail)}
function onWrong(detail={}){const tries=Number(detail.tries||1);react(tries>=2?'confused':(tries===1?'sad':'cry'),detail)}
window.addEventListener('maihoc:answercorrect',e=>onCorrect(e.detail||{}));
window.addEventListener('maihoc:answerwrong',e=>onWrong(e.detail||{}));
window.addEventListener('maihoc:charactermiss',e=>react('surprised',e.detail||{}));
window.addEventListener('maihoc:characterbump',e=>react('dizzy',e.detail||{}));
window.addEventListener('maihoc:levelcomplete',e=>react(e.detail?.perfect?'superCelebrate':'celebrate',e.detail||{}));
window.MAIHOC_CHARACTER_EMOTIONS=Object.freeze({react,clear,recipes,version:'642'});
})();
