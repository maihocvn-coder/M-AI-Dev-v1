(()=>{'use strict';
function create({scene,hero,grade,unit,sceneId,title}){
  const def=window.MAIHOC_WORLD_REGISTRY.get(sceneId,title,{grade,unit});
  const state=window.MAIHOC_GAME_STATE?.get(grade,unit)||{zoneIndex:0,stationIndex:0,progress:0};
  let progress=Math.max(0,Number(state.progress)||0);
  // Single visual authority: WORLD_TRANSITION owns all world rendering from the first frame.
  window.MAIHOC_WORLD_TRANSITION?.initialize?.(scene,progress,def);
  scene.dataset.worldId=def.id;
  scene.dataset.worldAuthority=def.id;
  function persist(){window.MAIHOC_GAME_STATE?.set(grade,unit,{zoneIndex:0,stationIndex:0,progress})}
  async function advance(){progress++;persist();return{progress}}
  function station(){return{x:34,y:78,zoneIndex:0,stationIndex:progress,progress}}
  async function goToStation(){return station()}
  function targetPoint(el){if(!el)return station();const sr=scene.getBoundingClientRect(),r=el.getBoundingClientRect();return{x:((r.left+r.width/2-sr.left)/Math.max(1,sr.width))*100,y:((r.top+r.height/2-sr.top)/Math.max(1,sr.height))*100}}
  const character={moveTo:async()=>station(),setPosition:()=>station(),getPosition:()=>station()};
  return{definition:def,character,station,goToStation,advance,targetPoint,persist,get zoneIndex(){return 0},get stationIndex(){return progress}}
}
window.MAIHOC_WORLD_RUNTIME={create};})();
