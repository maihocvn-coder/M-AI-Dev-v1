(()=>{'use strict';
/* v652 Unit-place authority. No curriculum keyword guessing: the approved Unit World Composition matrix is authoritative. */
const P=window.MAIHOC_WORLD_PROFILES,C=window.MAIHOC_UNIT_WORLD_COMPOSITION;
function hash(s){let h=2166136261;for(const c of String(s||'')){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function mix(a,b,t){const A=(a||'#88aabb').match(/\w\w/g).map(x=>parseInt(x,16)),B=(b||'#ffffff').match(/\w\w/g).map(x=>parseInt(x,16));return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('')}
function placeTheme(setting=''){
 const s=setting.toLowerCase();
 if(/classroom|school|learning/.test(s))return'campus'; if(/bedroom|home|dining room/.test(s))return'home'; if(/shop|store|market|café|food|kitchen|canteen/.test(s))return'market';
 if(/zoo|wildlife|pet/.test(s))return'wildlife'; if(/lake|seaside|water/.test(s))return'waterfront'; if(/farm|country|village/.test(s))return'countryside'; if(/garden|park|playground/.test(s))return'park';
 if(/campsite|summer camp|adventure camp/.test(s))return'camp'; if(/sport|stadium|football/.test(s))return'wellness'; if(/technology|future|space/.test(s))return /space/.test(s)?'space':/future/.test(s)?'future':'tech';
 if(/media/.test(s))return'media'; if(/arts/.test(s))return'arts'; if(/career/.test(s))return'career'; if(/culture|heritage|global/.test(s))return'culture'; if(/city|community|social/.test(s))return'city';
 if(/eco|nature|weather|disaster/.test(s))return'nature'; if(/transport|travel/.test(s))return'travel'; if(/wellness|health|body/.test(s))return'wellness'; return'social';
}
const propRules=[
 [/door|gate|entrance|welcome|shopfront|front door/,'gate'],[/cubb|locker|wardrobe|shelf|pantry|sideboard|display/,'shelves'],[/\b(desk|desks|table|tables)\b|dining|breakfast bar/,'desk'],[/board|teacher|learning wall|planner|timetable|forecast/,'board'],[/reading|library|books/,'bookshelf'],[/bed|bedtime/,'bed'],[/toy|plush|blocks|game|puzzle/,'toys'],[/window|mirror|photo|portrait/,'window'],[/counter|checkout|pickup|serving|order/,'counter'],[/kitchen|prep|cooking|stove|sink|fridge/,'kitchen'],[/fruit|vegetable|produce|ingredients|market|stall|bakery|flower/,'stall'],[/café|snack|dessert|drinks|food/,'cafe'],[/swing/,'swing'],[/slide|climbing|play corner|play zone/,'play'],[/sandbox/,'sandbox'],[/bench|waiting/,'bench'],[/pond|lake|river|water|wetland|rock pool/,'water'],[/bridge|pier|jetty|dock/,'pier'],[/tree|forest|orchard|garden|meadow|lawn|field|flowers|herb/,'garden'],[/greenhouse|dome/,'dome'],[/barn|farmhouse/,'barn'],[/animal|bird|mammal|big cat|reptile|savanna|habitat/,'habitat'],[/bus|station|platform|transit|interchange|boarding/,'station'],[/crossing|road|street|lane|route|trail|path/,'sign'],[/tent|campsite|campfire/,'tent'],[/fire/,'fire'],[/stage|performance|dance|rehearsal|audience/,'stage'],[/studio|recording|creative/,'studio'],[/gallery|museum|exhibit|heritage/,'gallery'],[/music/,'music'],[/camera|broadcast|screen|edit|control room|data/,'screen'],[/lab|science|innovation|prototype|test zone/,'lab'],[/robot/,'robot'],[/solar|clean-energy|renewable/,'solar'],[/wind|turbine/,'turbine'],[/office|interview|workplace|career/,'office'],[/clinic|vet|support centre/,'clinic'],[/track|warm-up|finish line|activity trail|sports/,'track'],[/plaza|square|atrium|courtyard|hub/,'plaza'],[/tower|skyline|high-rise|building/,'buildings'],[/planet|crater|star/,'planet'],[/antenna/,'antenna'],[/craft|art|colour|paint/,'gallery'],[/home|living room|family/,'house'],[/sign|menu|route|warning|choice|future board/,'sign']
];
function propFor(label,setting){const text=String(label||'').toLowerCase();for(const [r,p] of propRules)if(r.test(text))return p;const theme=placeTheme(setting);return theme==='campus'?'school':theme==='market'?'shop':theme==='home'?'house':theme==='tech'?'lab':theme==='arts'?'stage':theme==='career'?'office':theme==='city'?'buildings':theme==='waterfront'?'water':theme==='wildlife'?'habitat':theme==='countryside'?'garden':theme==='space'?'planet':'tree'}
function palette(gt,comp,seed){const indoor=comp.environment==='indoor';return{sky:indoor?mix(gt.sky,'#fff8e8',.48):gt.sky,horizon:indoor?mix(gt.horizon,'#ead9bd',.42):gt.horizon,ground:indoor?mix(gt.path,'#d9b98f',.28):gt.ground,path:indoor?mix(gt.path,'#f5e5c8',.18):gt.path,far:indoor?mix(gt.far,'#b78c6c',.32):gt.far,accent:gt.accent}}
function make(sceneId,title,context={}){
 let comp=null;
 if(/^world\.g\d+\.u\d+$/.test(sceneId||'')){const m=sceneId.match(/g(\d+)\.u(\d+)/);comp=C?.get?.(+m[1],+m[2])||null}
 const asset=P?.world?.(sceneId)||null;if(!comp&&asset?.grade)comp=C?.get?.(asset.grade,asset.unit)||null;
 if(!comp)comp=C?.get?.(context.grade,context.unit)||null;
 const grade=comp?.grade||context.grade||asset?.grade||1,unit=comp?.unit||context.unit||asset?.unit||1,gt=P?.gradeTheme?.(grade),seed=hash(`${grade}.${unit}.${comp?.sourceTitle||title||''}`),theme=placeTheme(comp?.setting||'');
 const journey=comp?.journey||Array(8).fill(comp?.setting||'world');const marks=comp?.landmarks||[];
 return{id:comp?.id||sceneId||P?.unitWorldId?.(grade,unit),name:comp?.worldName||title||'Unit World',title:comp?.title||title||'',sourceTitle:comp?.sourceTitle||'',setting:comp?.setting||'',environment:comp?.environment||'outdoor',landmarks:marks,grade,unit,gradeThemeId:gt.id,gradeTheme:gt,theme,visual:palette(gt,comp||{},seed),seed,tiles:journey.map((label,i)=>({id:`${comp?.id||sceneId}.tile-${i+1}`,index:i,label,props:[propFor(label,comp?.setting),propFor(marks[i%Math.max(1,marks.length)]||label,comp?.setting),propFor(marks[(i+2)%Math.max(1,marks.length)]||label,comp?.setting)],motif:(seed+i)%6,landmark:label}))}
}
function get(sceneId,title,context){return make(sceneId,title,context)}
window.MAIHOC_WORLD_REGISTRY={get,make,worlds:P?.worlds||[],gradeThemes:P?.gradeThemes||{},composition:C};
})();
