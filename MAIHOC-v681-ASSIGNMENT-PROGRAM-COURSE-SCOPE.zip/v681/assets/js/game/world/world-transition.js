(()=>{'use strict';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const $=(s,r=document)=>r.querySelector(s);
function ensureTravelWorld(scene){
  let viewport=$('.mh-travel-world',scene);
  if(viewport)return viewport;
  viewport=document.createElement('div');
  viewport.className='mh-travel-world';
  viewport.setAttribute('aria-hidden','true');
  viewport.innerHTML='<div class="mh-travel-track"></div>';
  scene.insertBefore(viewport,scene.firstChild);
  return viewport;
}
function parkVariant(index){
  const variants=[
    {landmark:'playset',accent:'flowerbed',feature:'squirrel'},
    {landmark:'swing',accent:'lavender',feature:'lamp'},
    {landmark:'pond',accent:'wildflowers',feature:'duck'},
    {landmark:'climber',accent:'daisies',feature:'squirrel'},
    {landmark:'picnic',accent:'tulips',feature:'kite'},
    {landmark:'bridge',accent:'wildflowers',feature:'lamp'}
  ];
  return variants[Math.max(0,Number(index)||0)%variants.length];
}
function parkScenery(index){
  const wrap=document.createElement('div');wrap.className='mh-park-world';
  const v=parkVariant(index);
  wrap.innerHTML=`
    <div class="mh-park-sky"><i class="mh-cloud c1"></i><i class="mh-cloud c2"></i><i class="mh-cloud c3"></i></div>
    <div class="mh-park-horizon"><i></i><i></i><i></i><i></i></div>
    <div class="mh-park-far-trees">${'<i></i>'.repeat(9)}</div>
    <div class="mh-park-lawn"></div>
    <div class="mh-park-path"></div>
    <div class="mh-park-tree tree-a"><i></i></div><div class="mh-park-tree tree-b"><i></i></div>
    <div class="mh-park-shrub shrub-a"></div><div class="mh-park-shrub shrub-b"></div>
    <div class="mh-park-landmark ${v.landmark}"><i></i><b></b><em></em></div>
    <div class="mh-park-flowerbed ${v.accent}"><i></i><i></i><i></i><i></i><i></i><i></i></div>
    <div class="mh-park-feature ${v.feature}"><i></i></div>
    <div class="mh-park-stones"><i></i><i></i><i></i></div>
    <div class="mh-park-foreground"><i></i><i></i><i></i><i></i><i></i></div>`;
  return wrap;
}
function propMarkup(name,slot='primary',motif=0){
  return `<div class="mh-world-prop mh-prop-${String(name||'tree').replace(/[^a-z0-9-]/gi,'')} ${slot} motif-${motif}"><i></i><b></b><em></em><span></span></div>`;
}
function genericScenery(index,def){
  const v=def?.visual||{},gt=def?.gradeTheme||{},tile=def?.tiles?.[Math.max(0,Number(index)||0)%Math.max(1,def?.tiles?.length||1)]||{},wrap=document.createElement('div');
  wrap.className=`mh-unit-world mh-world-theme-${def?.theme||'campus'} mh-world-environment-${def?.environment||'outdoor'} mh-grade-world-${String(def?.grade||1).padStart(2,'0')} mh-grade-shape-${gt.shape||'round'} mh-unit-variant-${tile.motif||0}`;
  wrap.dataset.unitWorld=def?.id||'';wrap.dataset.tile=String(tile.index||0);
  wrap.style.setProperty('--world-sky',v.sky||'#a9dcf3');wrap.style.setProperty('--world-horizon',v.horizon||'#b7d6b0');wrap.style.setProperty('--world-ground',v.ground||'#83b77a');wrap.style.setProperty('--world-path',v.path||'#d9c7a8');wrap.style.setProperty('--world-far',v.far||'#7193a2');wrap.style.setProperty('--world-accent',v.accent||'#ef9b58');
  const props=tile.props||['school','tree','bench'];
  wrap.innerHTML=`
    <div class="mh-unit-sky"><i></i><i></i><i></i></div>
    <div class="mh-unit-atmosphere"><i class="mh-world-motif"></i></div>
    <div class="mh-unit-horizon"><i></i><i></i><i></i><i></i><i></i></div>
    <div class="mh-unit-ground"></div><div class="mh-unit-path"></div>
    <div class="mh-world-props">${propMarkup(props[0],'primary',tile.motif)}${propMarkup(props[1],'secondary',(tile.motif+1)%6)}${propMarkup(props[2],'tertiary',(tile.motif+2)%6)}</div>
    <div class="mh-unit-edge-detail"><i></i><i></i><i></i><i></i><i></i></div>
    <div class="mh-unit-foreground"><i></i><i></i><i></i><i></i></div>
    <div class="mh-unit-world-label"><b>G${def?.grade||''} · U${def?.unit||''}</b><span>${String(tile.label||def?.title||'').replace(/[&<>]/g,'')}</span></div>`;
  return wrap;
}
function segment(index,question,isNext,def){
  const el=document.createElement('section');
  el.className='mh-travel-segment'+(isNext?' is-next':' is-current');
  el.dataset.segment=String(index);
  el.append(genericScenery(index,def));
  if(isNext&&question){
    const q=document.createElement('div');q.className='mh-travel-question-object';
    const skill=document.createElement('span');skill.className='mh-travel-question-skill';skill.textContent=question.skill||'';
    const text=document.createElement('span');text.className='mh-travel-question-text';text.textContent=question.prompt||'';
    q.append(skill,text);el.append(q);
  }
  return el;
}
function initialize(scene,index=0,def=null){
  if(!scene)return null;
  const viewport=ensureTravelWorld(scene),track=$('.mh-travel-track',viewport);
  const current=Math.max(0,Number(index)||0);
  track.replaceChildren(segment(current,null,false,def));
  track.style.transition='none';track.style.transform='translate3d(0,0,0)';
  viewport.dataset.currentSegment=String(current);
  scene.dataset.worldAuthority=def?.id||'world.campus';scene._maihocWorldDefinition=def;
  return viewport;
}
async function travelBetweenQuestions(scene,opts={}){
  if(!scene)return false;
  const fromIndex=Math.max(0,Number(opts.fromIndex)||0),toIndex=Math.max(fromIndex+1,Number(opts.toIndex)||fromIndex+1);
  const viewport=ensureTravelWorld(scene),track=$('.mh-travel-track',viewport);
  // The park track is the persistent world authority. Rescue the single canonical carrier lane before rebuilding segments.
  // The next-question lane will be mounted INSIDE the incoming segment, so scenery + question + carriers share one transform.
  const carrierLane=$('#catchLane',scene);
  if(carrierLane&&carrierLane.parentElement!==scene)scene.append(carrierLane);
  const def=scene._maihocWorldDefinition||null;
  track.replaceChildren(segment(fromIndex,null,false,def),segment(toIndex,opts.nextQuestion||null,true,def));
  viewport.dataset.currentSegment=String(fromIndex);
  const liveQuestion=$('.mh-world-question',scene);
  scene.classList.add('mse-world-travelling');scene.dataset.transition='question-travel';
  track.style.transition='none';track.style.transform='translate3d(0,0,0)';
  void track.offsetWidth;
  const duration=Math.max(2400,Math.min(4200,Number(opts.duration)||3200));
  scene.style.setProperty('--mh-world-travel-duration',`${duration}ms`);
  if(opts.nextQuestion)window.dispatchEvent(new CustomEvent('maihoc:questionapproach',{detail:{fromIndex,toIndex,question:opts.nextQuestion,duration}}));
  track.style.transition=`transform ${duration}ms cubic-bezier(.42,.08,.32,1)`;
  track.style.transform='translate3d(-50%,0,0)';
  if(liveQuestion)liveQuestion.classList.add('mh-world-question-departing');
  await sleep(duration);
  if(liveQuestion)liveQuestion.classList.remove('mh-world-question-departing');
  // Commit the ACTUAL incoming segment. Do not reconstruct it: its question-bound carrier lane must survive arrival.
  const arrived=$('.mh-travel-segment.is-next',track);
  if(arrived){
    const first=$('.mh-travel-segment.is-current',track);if(first)first.remove();
    arrived.classList.remove('is-next');arrived.classList.add('is-current');
    $('.mh-travel-question-object',arrived)?.remove();
  }
  track.style.transition='none';track.style.transform='translate3d(0,0,0)';
  viewport.dataset.currentSegment=String(toIndex);
  scene.classList.remove('mse-world-travelling');delete scene.dataset.transition;
  window.dispatchEvent(new CustomEvent('maihoc:worldarrived',{detail:{fromIndex,toIndex}}));
  return true;
}
async function run(scene,type='travel'){scene.dataset.transition=type;scene.classList.add('world-transitioning');await sleep(420);scene.classList.remove('world-transitioning');delete scene.dataset.transition}
window.MAIHOC_WORLD_TRANSITION={run,initialize,travelBetweenQuestions};
})();
