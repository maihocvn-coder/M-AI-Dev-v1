/* M-AI Học sample engine descriptor — behavior is the cloned Grade 1 movement/catch interaction. */
(()=>{'use strict';window.MAIHOC_SAMPLE_ENGINE={id:'sample-g1-letter-catch',referenceGrade:1,controls:'g1v475-controls',interaction:'move-jump-catch'};})();
