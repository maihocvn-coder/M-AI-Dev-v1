(()=>{'use strict';
/* Sage is a service over canonical content. Content supplies the learning truth via
   sageContract; Core is deterministic/free. AI may later personalize within the contract. */
function questionContract(q={}){
  if(q.sageContract)return q.sageContract;
  const authored=Array.isArray(q.sage)?q.sage.filter(Boolean):[];
  return Object.freeze({contentType:'question',contentId:q.id||null,loId:q.loId||q.lo||null,skill:q.skill||null,concept:q.testedConcept||q.correctAnswer||null,testedDistinction:q.testedDistinction||null,coachingType:String(q.skill||'general').toLowerCase(),steps:authored.length?authored:null});
}
function knowledgeContract(k={}){
  if(k.sageContract)return k.sageContract;
  return Object.freeze({contentType:'knowledge',contentId:k.id||k.conceptId||null,loId:k.loId||null,skill:k.skill||null,concept:k.semantic?.canonicalConcept||k.label||k.target||k.conceptId||null,coachingType:String(k.skill||'general').toLowerCase(),requiredTeaching:['explain','example','notice','quick-check']});
}
function coreHints(q={}){const c=questionContract(q);if(Array.isArray(c.steps)&&c.steps.length)return c.steps;const bySkill={Vocabulary:['Xác định từ hoặc cụm từ đang được hỏi.','So sánh nghĩa của các lựa chọn với nội dung vừa học.','Loại lựa chọn không phù hợp rồi thử lại.'],Phonics:['Nghe âm hoặc từ mẫu đang được luyện.','So sánh âm mục tiêu trong từng lựa chọn.','Chọn sau khi em đã đối chiếu với âm mẫu.'],Pronunciation:['Nghe âm hoặc từ mẫu đang được luyện.','Chú ý vị trí miệng, trọng âm hoặc âm mục tiêu.','So sánh từng lựa chọn rồi thử lại.'],Grammar:['Xác định mẫu ngữ pháp câu đang kiểm tra.','Nhắc lại form và cách dùng từ Knowledge.','Áp dụng đúng form vào câu hiện tại.'],Listening:['Nghe lại với một mục tiêu cụ thể.','Tập trung vào từ khóa liên quan trực tiếp đến câu hỏi.','Đối chiếu điều nghe được với từng lựa chọn.'],Reading:['Quay lại phần chứa thông tin được hỏi.','Tìm từ hoặc cụm từ làm bằng chứng.','Dùng bằng chứng đó để loại đáp án sai.'],Speaking:['Xem lại mẫu và từ khóa cần dùng.','Nói từng phần ngắn trước.','Ghép lại và tự kiểm tra theo yêu cầu.'],Writing:['Xem lại yêu cầu và checklist.','Viết ý chính bằng mẫu đã học.','Đọc lại để kiểm tra nghĩa, form và chính tả.']};return bySkill[c.skill]||['Đọc hoặc nghe lại nhiệm vụ.','Tìm manh mối quan trọng nhất.','Dùng manh mối đó rồi thử lại.']}
function resolveForQuestion(q,studentState={}){return Object.freeze({contract:questionContract(q),mode:'core',hints:coreHints(q),studentState})}
function resolveForKnowledge(k,studentState={}){return Object.freeze({contract:knowledgeContract(k),mode:'core',studentState})}
function needsAI({wrongAttempts=0,freeFormQuestion='',force=false}={}){return !!(force||freeFormQuestion||Number(wrongAttempts)>=2)}
window.MAIHOC_SAGE_SERVICE=Object.freeze({questionContract,knowledgeContract,resolveForQuestion,resolveForKnowledge,needsAI});
})();
