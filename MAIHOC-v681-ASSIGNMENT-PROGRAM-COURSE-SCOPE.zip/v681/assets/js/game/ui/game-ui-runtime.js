/* M-AI Học School English — canonical shared page UX. One frame; only MainScreen content changes. */
(()=>{
'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const isG1=()=>document.body.classList.contains('grade-1')||location.pathname.includes('/grade1/');
const usesG1Sample=()=>isG1()||document.body.classList.contains('mse-sample-g1');
let activeQuestion=null, holderQuestion=null, introShown=false, introTimer=null;
function mode(){return document.body.dataset.mseMode||'play'}
function shell(){return $('.game-shell')}
function cleanSpecializedPlayLayers(){
  if(!usesG1Sample())return;
  $$('#scene .mh-world-journey,#scene .mh-engine-targets,#scene .mh-engine-tool').forEach(el=>el.remove());
}
function ownFrame(){
  document.body.classList.add('mse-generic-frame');
  const layout=$('.layout'), crumb=$('.mh-site-breadcrumb');
  if(layout&&crumb&&crumb.parentElement!==layout) layout.prepend(crumb);
  const sh=shell(), scene=$('#scene'), content=$('#interaction'), sage=$('#sageFloat');
  // Shared frame hooks. These do not replace Grade 1's tested renderer.
  if(scene) scene.classList.add('mse-game-world-slot');
  if(sh){sh.classList.add('mse-main-screen'); if(scene)scene.classList.add('mse-main-content','mse-main-content-play'); if(content)content.classList.add('mse-main-content','mse-main-content-document'); if(sage&&sage.parentElement!==sh)sh.append(sage)}
  // Universal ownership: every grade, including Grade 1, exposes the same runtime hooks.
  const character=$('#cat,#character,.game-character,[data-game-character]',scene||document);
  const controls=$('.g1v475-controls,.game-controls,[data-game-controls]',scene||document);
  if(character) character.classList.add('mse-game-character');
  if(controls) controls.classList.add('mse-game-controls');
}
function mountPlayRows(){
  const scene=$('#scene'); if(!scene)return;
  // Universal Frame DOM contract: every grade owns the same canonical carrier lane.
  // Grade 1 already ships it in markup; Grades 2–12 receive the identical mount here.
  let lane=$('#catchLane',scene);
  if(!lane){lane=document.createElement('div');lane.id='catchLane';lane.className='catch-lane';lane.setAttribute('aria-label','Answer carriers');scene.append(lane)}
  // One bottom stack owns both rows. The rows themselves are normal-flow grid rows,
  // never independent absolute layers, so Controller cannot cover Character.
  let stack=$('.mse-play-bottom-stack',scene);
  if(!stack){stack=document.createElement('div');stack.className='mse-play-bottom-stack';scene.append(stack)}
  let characterRow=$('.mse-character-row',stack); if(!characterRow){characterRow=document.createElement('div');characterRow.className='mse-character-row';stack.append(characterRow)}
  let controllerRow=$('.mse-controller-row',stack); if(!controllerRow){controllerRow=document.createElement('div');controllerRow.className='mse-controller-row';stack.append(controllerRow)}
  const character=$('#cat,#character,.game-character,[data-game-character]',scene); if(character&&character.parentElement!==characterRow)characterRow.append(character);
  let controls=$('#g1v475Controls',scene);
  // Universal Frame owns one shared controller mount for every grade.
  // Character Movement renders the grade/unit-configured actions into this mount.
  if(!controls){controls=document.createElement('div');controls.id='g1v475Controls';controls.className='g1v475-controls mse-game-controls';controls.dataset.gameControls='1'}
  if(controls.parentElement!==controllerRow)controllerRow.append(controls);
}
function installResponsiveOwner(){window.MAIHOC_RESPONSIVE?.sync?.()}
function mountFullscreenControl(){
  const scene=$('#scene'); if(!scene||$('#mseFullscreenControl',scene))return;
  const btn=document.createElement('button');btn.type='button';btn.id='mseFullscreenControl';btn.className='mse-fullscreen-control';btn.title='Toàn màn hình';btn.setAttribute('aria-label','Xem game toàn màn hình');btn.textContent='⛶';scene.append(btn);
  const target=()=>$('.game-shell')||scene;
  const sync=()=>{const on=!!document.fullscreenElement;btn.textContent=on?'×':'⛶';btn.setAttribute('aria-label',on?'Thoát toàn màn hình':'Xem game toàn màn hình')};
  btn.addEventListener('click',ev=>{ev.preventDefault();ev.stopPropagation();document.fullscreenElement?document.exitFullscreen?.():target().requestFullscreen?.()});
  document.addEventListener('fullscreenchange',sync);sync();
}

function mountPlayUtilities(){const scene=$('#scene'),report=$('#report');if(!scene)return;mountPlayRows();mountFullscreenControl();installResponsiveOwner();if(!report)return;if(report.parentElement!==scene)scene.append(report);report.classList.add('mh-world-report-question');report.dataset.reportQuestion='1'}
function syncPresentation(){
  const m=mode();
  const scene=$('#scene'), content=$('#interaction');
  if(scene){scene.hidden=m!=='play';scene.setAttribute('aria-hidden',String(m!=='play'))}
  if(content){content.hidden=m==='play';content.setAttribute('aria-hidden',String(m==='play'))}
  $$('#modes [data-mode]').forEach(b=>b.classList.toggle('selected',b.dataset.mode===m));
  syncSage(); syncWorldQuestion(activeQuestion);
  if(m==='play'){cleanSpecializedPlayLayers();const q=holderQuestion||activeQuestion;if(q&&Array.isArray(q.options)&&q.options.length)renderAnswerCarriers(q);else if(activeQuestion)renderGenericWorldAnswers(activeQuestion)}
}
function observeCanonicalMode(){
  if(document.body.dataset.mseModeObserved==='1')return;
  document.body.dataset.mseModeObserved='1';
  new MutationObserver(records=>{if(records.some(r=>r.attributeName==='data-mse-mode'))queueMicrotask(syncPresentation)}).observe(document.body,{attributes:true,attributeFilter:['data-mse-mode']});
}
function mountWorldQuestion(){const scene=$('#scene');if(!scene)return null;let c=$('.mh-world-question',scene);if(!c){c=document.createElement('div');c.className='mh-world-question';c.innerHTML='<span class="mh-world-question-skill"></span><span class="mh-world-question-copy"><span class="mh-world-question-text"></span><span class="mh-world-question-stimulus"></span></span><span class="mh-world-question-actions"></span>';scene.append(c)}return c}
function questionPhonemes(q){
  if(!q)return [];
  const vals=[q.phonemeTarget,q.targetSound,q.phoneme,q.pronunciationTarget,q.phonicsTarget,q.stimulus,q.prompt];
  const out=[];
  vals.forEach(v=>{const raw=String(v||'');for(const m of raw.matchAll(/\/([^/]{1,8})\//g)){const ph=m[1].trim();if(ph&&!out.includes(ph))out.push(ph)}});
  return out;
}
function questionPhoneme(q){
  if(!q)return '';
  const skill=String(q.skill||'').trim().toLowerCase();
  if(!['phonics','pronunciation'].includes(skill))return '';
  return questionPhonemes(q).find(ph=>window.MAIHOC_PHONEME_AUDIO?.has?.(ph))||'';
}
function hasAudio(q){const skill=String(q?.skill||'').trim().toLowerCase();return !!(q&&(q.audioPrompt||(skill==='listening'&&q.stimulus)||questionPhoneme(q)))}
function isTyped(q){if(!q)return false;const t=String(q.responseType||q.answerType||q.inputType||'').toLowerCase();if(q.requiresTextInput===true||q.openResponse===true||['text-input','type','typed','input','open','open-response','short-answer','long-answer'].includes(t))return true;if(Array.isArray(q.options)&&q.options.length>1)return false;return q.skill==='Writing'}
function syncWorldQuestion(q=activeQuestion){
  activeQuestion=q||activeQuestion;const c=mountWorldQuestion();if(!c)return;
  const skill=$('.mh-world-question-skill',c),text=$('.mh-world-question-text',c),stimulus=$('.mh-world-question-stimulus',c),actions=$('.mh-world-question-actions',c);
  const skillName=String(q?.skill||$('#questionSkill')?.textContent||'').trim();
  const skillKey=skillName.toLowerCase();
  const instruction=String(q?.prompt||$('#prompt')?.textContent||'').trim();
  const rawStimulus=String(q?.stimulus||'').trim();
  const hideStimulus=q?.hideStimulusText===true||skillKey==='listening';
  if(skill)skill.textContent=skillName;
  if(text)text.textContent=instruction;
  if(stimulus){stimulus.textContent=hideStimulus?'':rawStimulus;stimulus.hidden=!rawStimulus||hideStimulus}
  if(actions){
    actions.replaceChildren();
    if(hasAudio(q)){
      const b=document.createElement('button');b.type='button';b.className='mh-world-action mh-world-question-audio';b.textContent='🔊';
      const ph=questionPhoneme(q);
      if(ph){b.dataset.phoneme=ph;b.setAttribute('aria-label','Listen to phoneme /'+ph+'/');b.setAttribute('title','Listen to /'+ph+'/');window.MAIHOC_PHONEME_AUDIO?.mount?.(b,ph)}
      else{b.setAttribute('aria-label','Play question audio');b.setAttribute('title','Play question audio');b.onclick=e=>{e.preventDefault();e.stopPropagation();const canonical=$('#stimulus .question-audio');if(canonical){canonical.click();return}const source=String(q?.audioPrompt||((skillKey==='listening')?q?.stimulus:'')||'').trim();if(source)window.MAIHOC_TTS?.speak?.(source)}}
      actions.append(b)
    }
    if(isTyped(q)){const b=document.createElement('button');b.type='button';b.className='mh-world-action mh-world-answer-open';b.textContent='Answer';b.onclick=()=>{$('#interaction')?.classList.add('mh-typed-open')};actions.append(b)}
  }
  const show=mode()==='play'&&!!(instruction||rawStimulus||hasAudio(q));c.hidden=!show;c.classList.toggle('mh-world-question-visible',show)
}
function audioFor(q,i){const skill=String(q?.skill||'').trim().toLowerCase();return usesG1Sample()||!!(q&&(q.ttsOptions||skill==='phonics'||skill==='pronunciation'||q.optionAudio||q.audioOptions?.[i]))}
function makeBadge(q,text,i){const badge=document.createElement('span');badge.className='mh-answer-badge';badge.dataset.answerIndex=i;const svc=window.MAIHOC_SCHOOL_ENGLISH;const probe={...q,rewardObject:q?.optionRewards?.[i]??q?.rewardObjects?.[i]??q?.optionObjects?.[i]??null,options:[String(text??'')],answer:0,prompt:'',stimulus:'',context:''};const reward=svc?.resolveRewardObject?.(probe,{fallbackIndex:i});if(reward){const obj=svc?.rewardNode?.(reward,'mh-answer-reward-object')||document.createElement('span');obj.classList.add('mh-answer-reward-object');badge.append(obj)}const t=document.createElement('span');t.className='mh-answer-badge-text';t.textContent=text;badge.append(t);if(audioFor(q,i)){const a=document.createElement('button');a.type='button';a.className='mh-answer-badge-audio';a.textContent='🔊';a.setAttribute('aria-label','Listen to '+String(text??''));a.onclick=e=>{e.preventDefault();e.stopPropagation();const canonical=$$('#answers .answer-row')[i]?.querySelector('.option-audio');if(canonical){canonical.click();return}window.MAIHOC_TTS?.speak?.(String(text??''))};badge.append(a)}return badge}
const ANSWER_CARRIERS=[
  {id:'butterfly-rose',kind:'butterfly',body:'#ef6f9f',wing:'#ffd86b'},
  {id:'butterfly-blue',kind:'butterfly',body:'#5f7ee8',wing:'#8fe1ef'},
  {id:'butterfly-orange',kind:'butterfly',body:'#e98645',wing:'#ffd27a'},
  {id:'dragonfly',kind:'dragonfly',body:'#4f9b9a',wing:'#bdeaf0'},
  {id:'bee',kind:'bee',body:'#f0bd45',wing:'#eaf8fb'},
  {id:'bluebird',kind:'bird',body:'#4fa9e8',wing:'#2f78b7'},
  {id:'robin',kind:'bird',body:'#9b694a',wing:'#e98254'},
  {id:'hummingbird',kind:'bird',body:'#49a889',wing:'#2d7463'},
  {id:'swallow',kind:'bird',body:'#365d82',wing:'#203d5d'},
  {id:'canary',kind:'bird',body:'#f0cf45',wing:'#d8aa28'},
  {id:'finch',kind:'bird',body:'#c98b55',wing:'#8e6245'},
  {id:'dove',kind:'bird',body:'#c8ced7',wing:'#929aaa'}
];
function carrierSeed(q){return [...String(q?.id||q?.prompt||'')].reduce((a,c)=>(a*33+c.charCodeAt(0))>>>0,5381)}
// Canonical carrier-motion authority. Motion is a fantasy/game asset: any carrier may use any registered motion.
// Grade/Unit config supplies defaults and optional per-carrier overrides; there are no biological restrictions.
const CARRIER_MOTIONS=Object.freeze({
  still:{id:'still'},wiggle:{id:'wiggle'},hover:{id:'hover'},flutter:{id:'flutter'},
  drift:{id:'drift'},dart:{id:'dart'},circle:{id:'circle'},'fly-path':{id:'fly-path'},
  hop:{id:'hop'},crawl:{id:'crawl'},climb:{id:'climb'},flee:{id:'flee'}
});
function carrierMotionPolicy(){
  const ctx=window.MAIHOC_GAME_STATE?.get?.()||{};
  const cfg=window.MAIHOC_GAME_CONFIG?.resolve?.({program:'school-english',grade:ctx.grade||1,unit:ctx.unit||1})||{};
  const configured=cfg.carrierMotions||{};
  const fallback=CARRIER_MOTIONS[configured.default]?configured.default:'wiggle';
  return {default:fallback,byCarrier:(configured.byCarrier&&typeof configured.byCarrier==='object')?configured.byCarrier:{}};
}
function chooseCarrierMotion(spec){
  const policy=carrierMotionPolicy();
  const requested=policy.byCarrier?.[spec.id]||policy.default;
  return CARRIER_MOTIONS[requested]?requested:policy.default;
}
function applyCarrierMotion(holder,spec,q,i){const art=$('.mh-answer-carrier',holder);if(!art)return;const motion=chooseCarrierMotion(spec,q,i);art.dataset.motion=motion;holder.dataset.carrierMotion=motion}
function carrierArt(spec){
  const el=document.createElement('span');el.className='mh-answer-holder-visual mh-answer-carrier';el.dataset.carrier=spec.id;el.dataset.kind=spec.kind;el.setAttribute('aria-hidden','true');
  const common='stroke-linecap="round" stroke-linejoin="round"';
  if(spec.kind==='butterfly')el.innerHTML=`<svg viewBox="0 0 112 58"><g class="mh-carrier-wing"><path d="M47 29C23 3 5 12 13 30c5 12 18 15 34 6Z" fill="${spec.wing}"/><path d="M47 31C24 50 10 46 15 34c6-12 18-12 32-8Z" fill="${spec.body}"/></g><path d="M48 17q18 7 31 16-13 11-31 10" fill="none" stroke="#4a4050" stroke-width="5" ${common}/><circle cx="79" cy="33" r="5" fill="#4a4050"/><path d="M82 30q8-8 14-3" fill="none" stroke="#4a4050" stroke-width="2" ${common}/></svg>`;
  else if(spec.kind==='dragonfly')el.innerHTML=`<svg viewBox="0 0 116 58"><path d="M32 29h58" stroke="${spec.body}" stroke-width="7" ${common}/><circle cx="93" cy="29" r="7" fill="${spec.body}"/><circle cx="96" cy="27" r="1.8" fill="#173a58"/><g class="mh-carrier-wing" fill="${spec.wing}" stroke="#78b9c2" stroke-width="1"><ellipse cx="53" cy="17" rx="25" ry="7" transform="rotate(-18 53 17)"/><ellipse cx="53" cy="41" rx="25" ry="7" transform="rotate(18 53 41)"/></g><path d="M31 29 18 23M31 29 18 35" stroke="#427c7c" stroke-width="3" ${common}/></svg>`;
  else if(spec.kind==='bee')el.innerHTML=`<svg viewBox="0 0 112 58"><g class="mh-carrier-wing" fill="${spec.wing}" stroke="#b8dce3"><ellipse cx="52" cy="17" rx="20" ry="10" transform="rotate(-18 52 17)"/><ellipse cx="52" cy="39" rx="18" ry="9" transform="rotate(16 52 39)"/></g><ellipse cx="61" cy="31" rx="31" ry="17" fill="${spec.body}"/><path d="M47 17v28M61 14v34M75 17v28" stroke="#60482d" stroke-width="6" opacity=".85"/><circle cx="91" cy="29" r="4" fill="#173a58"/><path d="M92 23q6-10 11-8" fill="none" stroke="#60482d" stroke-width="2" ${common}/></svg>`;
  else if(spec.kind==='ladybug')el.innerHTML=`<svg viewBox="0 0 112 58"><ellipse cx="61" cy="32" rx="31" ry="19" fill="${spec.body}"/><path d="M60 14v36" stroke="#3d3a39" stroke-width="3"/><circle cx="90" cy="31" r="11" fill="#3d3a39"/><g fill="#3d3a39"><circle cx="47" cy="25" r="4"/><circle cx="47" cy="39" r="4"/><circle cx="68" cy="24" r="4"/><circle cx="70" cy="40" r="4"/></g><path d="M96 24q7-8 12-5M96 38q7 8 12 5" fill="none" stroke="#3d3a39" stroke-width="2" ${common}/></svg>`;
  else if(spec.kind==='squirrel')el.innerHTML=`<svg viewBox="0 0 120 64"><path d="M35 43C8 43 8 12 31 12c20 0 21 24 8 31" fill="none" stroke="${spec.wing}" stroke-width="14" ${common}/><ellipse cx="68" cy="39" rx="29" ry="17" fill="${spec.body}"/><circle cx="94" cy="31" r="14" fill="${spec.body}"/><path d="M88 19 92 7l8 13" fill="${spec.body}"/><circle cx="100" cy="29" r="2.5" fill="#173a58"/><path d="M104 35q8 2 11-1M55 51l-7 9M78 51l6 9" fill="none" stroke="#75482d" stroke-width="4" ${common}/></svg>`;
  else if(spec.kind==='rabbit')el.innerHTML=`<svg viewBox="0 0 118 64"><ellipse cx="64" cy="42" rx="31" ry="16" fill="${spec.body}"/><circle cx="91" cy="34" r="14" fill="${spec.body}"/><ellipse cx="86" cy="13" rx="6" ry="20" fill="${spec.body}" transform="rotate(-8 86 13)"/><ellipse cx="99" cy="14" rx="6" ry="20" fill="${spec.body}" transform="rotate(8 99 14)"/><circle cx="98" cy="32" r="2.5" fill="#173a58"/><circle cx="31" cy="39" r="8" fill="#f4eee8"/><path d="M58 54 48 61M79 54l10 7" stroke="#9f8978" stroke-width="4" ${common}/></svg>`;
  else el.innerHTML=`<svg viewBox="0 0 112 58"><path d="M20 35Q34 9 68 16Q84 18 91 29Q82 43 60 45Q35 48 20 35Z" fill="${spec.body}"/><path class="mh-carrier-wing" d="M43 25Q58 15 73 26Q60 43 40 38Z" fill="${spec.wing}"/><circle cx="82" cy="25" r="2.8" fill="#173a58"/><path d="M91 27l17 6-17 5Z" fill="#e7a33e"/><path d="M23 34 6 22l8 17-9 8 22-5Z" fill="${spec.wing}"/></svg>`;
  return el;
}
function faceCarrierToCharacter(holder){const art=$('.mh-answer-carrier',holder),cat=$('#cat');if(!art||!cat)return;const a=holder.getBoundingClientRect(),c=cat.getBoundingClientRect();art.dataset.facing=(c.left+c.width/2)<(a.left+a.width/2)?'left':'right'}
function questionCarrierKey(q){return String(q?.id||q?.itemId||q?.questionId||q?.prompt||'')}
function renderAnswerCarriers(q,{staged=false}={}){if(mode()!=='play')return;holderQuestion=q;const lane=$('#catchLane');if(!lane||!q||!Array.isArray(q.options))return;const qkey=questionCarrierKey(q);if(lane.dataset.questionKey===qkey&&lane.children.length){lane.hidden=false;lane.classList.toggle('mh-answer-holder-lane-staged',!!staged);lane.classList.toggle('mh-answer-holder-lane-active',!staged);$$('.mh-answer-holder',lane).forEach(h=>h.disabled=!!staged);return}lane.replaceChildren();lane.hidden=false;lane.dataset.questionKey=qkey;lane.className='catch-lane mh-answer-holder-lane '+(staged?'mh-answer-holder-lane-staged':'mh-answer-holder-lane-active');const answerCount=Math.max(1,Math.min(4,q.options.length));lane.style.setProperty('--mse-answer-count',String(answerCount));const seed=carrierSeed(q);q.options.slice(0,answerCount).forEach((text,i)=>{const h=document.createElement('button');h.type='button';h.className='mh-answer-holder';h.dataset.answerIndex=i;h.dataset.questionKey=qkey;h.disabled=!!staged;const altitude=[18,48,30][(seed+i*2)%3]+Math.abs(((seed>>(i*3))%9)-4);h.style.setProperty('--mh-carrier-altitude',`${altitude}px`);const spec=ANSWER_CARRIERS[(seed+i)%ANSWER_CARRIERS.length];h.dataset.carrier=spec.id;h.append(carrierArt(spec),makeBadge(q,text,i));applyCarrierMotion(h,spec,q,i);lane.append(h);requestAnimationFrame(()=>faceCarrierToCharacter(h))});$('#obstacle')?.classList.add('mh-legacy-target-hidden');requestAnimationFrame(()=>fitCarrierHeightsToScreen(q))}
function stageApproachingCarriers(detail={}){const q=detail.question;if(!q)return;renderAnswerCarriers(q,{staged:true});const lane=$('#catchLane'),next=$('#scene .mh-travel-segment.is-next');if(lane&&next&&lane.parentElement!==next)next.append(lane)}
function fitCarrierHeightsToScreen(q){
 const lane=$('#catchLane'),question=$('.mh-world-question');if(!lane||!question||lane.hidden)return;
 const qr=question.getBoundingClientRect(),lr=lane.getBoundingClientRect(),holders=$$('.mh-answer-holder',lane);if(!holders.length)return;
 // Carrier + tether + answer badge is one geometry object. Never allow any part
 // of that object to rise into the live question card. Variation is downward only.
 const clearance=Math.max(12,Math.min(28,lr.height*.06));
 const seed=carrierSeed(q||holderQuestion||{}),pattern=[[18,52,34],[42,20,56],[28,58,18],[54,32,22]][seed%4];
 holders.forEach((h,i)=>{
   const base=pattern[i%pattern.length]||24;
   h.style.setProperty('--mh-carrier-altitude',`${base}px`);
 });
 requestAnimationFrame(()=>{
   holders.forEach((h,i)=>{
     const art=$('.mh-answer-carrier',h),ar=art?.getBoundingClientRect();if(!ar)return;
     const intrusion=(qr.bottom+clearance)-ar.top;
     if(intrusion>0){const current=parseFloat(getComputedStyle(h).marginTop)||0;h.style.setProperty('--mh-carrier-altitude',`${Math.ceil(current+intrusion)}px`)}
   });
 });
}
function collectCaughtCarrier(detail={}){const lane=$('#catchLane');if(!lane)return;const index=Number(detail.answerIndex),holders=$$('.mh-answer-holder',lane),chosen=holders.find(h=>Number(h.dataset.answerIndex)===index);if(!chosen)return;holders.forEach(h=>h.disabled=true);chosen.classList.add('mh-answer-carrier-caught');setTimeout(()=>{lane.replaceChildren();lane.hidden=true;lane.removeAttribute('data-question-key');lane.classList.remove('mh-answer-holder-lane-active','mh-answer-holder-lane-staged')},420)}
function renderGenericWorldAnswers(q){if(mode()!=='play')return;const scene=$('#scene');if(!scene)return;let list=$('.mh-world-answer-list',scene);if(!list){list=document.createElement('div');list.className='mh-world-answer-list';scene.append(list)}list.replaceChildren();if(!q||!Array.isArray(q.options)){list.hidden=true;return}list.hidden=false;q.options.slice(0,4).forEach((text,i)=>{const b=document.createElement('button');b.type='button';b.className='mh-world-answer-choice';b.textContent=text;b.onclick=()=>$$('#answers .answer-row')[i]?.querySelector('button:not(.option-audio)')?.click();list.append(b)})}
function syncSage(){const s=$('#sageFloat');if(!s)return;const hide=mode()==='test';s.hidden=hide;s.setAttribute('aria-hidden',String(hide));if(hide)s.dataset.collapsed='true'}
function bindSage(){const s=$('#sageFloat');if(!s||s.dataset.mseBound==='1')return;s.dataset.mseBound='1';$('#sageOpen',s)?.addEventListener('click',()=>s.dataset.collapsed='false');$('#sageCollapse',s)?.addEventListener('click',()=>s.dataset.collapsed='true')}
function manageInstruction(){const b=$('#sceneStatus');if(!b||!/LETTER\s*CATCH|bắt đúng hình|chơi tiếp/i.test(b.textContent||''))return;if(introShown){b.hidden=true;return}introShown=true;b.hidden=false;b.classList.add('mh-game-intro-toast');clearTimeout(introTimer);introTimer=setTimeout(()=>{b.hidden=true;b.classList.remove('mh-game-intro-toast')},2600)}
function onQuestion(e){activeQuestion=e?.detail?.question;requestAnimationFrame(()=>{cleanSpecializedPlayLayers();syncWorldQuestion(activeQuestion);if(Array.isArray(activeQuestion?.options)&&activeQuestion.options.length)renderAnswerCarriers(activeQuestion);else renderGenericWorldAnswers(activeQuestion);manageInstruction();syncSage()})}
function boot(){ownFrame();mountPlayUtilities();cleanSpecializedPlayLayers();bindSage();observeCanonicalMode();activeQuestion=window.MAIHOC_CURRENT_QUESTION?.()||activeQuestion;holderQuestion=activeQuestion;syncPresentation();syncWorldQuestion(activeQuestion);const resync=()=>{activeQuestion=window.MAIHOC_CURRENT_QUESTION?.()||activeQuestion;syncPresentation();syncWorldQuestion(activeQuestion);if(mode()==='play'&&activeQuestion){if(Array.isArray(activeQuestion.options)&&activeQuestion.options.length)renderAnswerCarriers(activeQuestion);else renderGenericWorldAnswers(activeQuestion)}};requestAnimationFrame(resync);setTimeout(resync,80)}
window.MAIHOC_GAME_FRAME={
  configure(next={}){window.MAIHOC_GAME_CONFIG={...(window.MAIHOC_GAME_CONFIG||{}),...next}},
  referenceGrade:1,
  contract:'Grade 1 is the visual reference; Grades 2–12 plug world/engine/character/answerHolder into the same frame.',
  version:'frame-v2-g1-reference'
};
window.MAIHOC_CARRIER_MOTION={motions:CARRIER_MOTIONS,policy:carrierMotionPolicy,choose:chooseCarrierMotion,unrestricted:true,version:'current'};
window.MAIHOC_ANSWER_BADGE={create:makeBadge,renderAnswerCarriers,version:'current'};
window.addEventListener('maihoc:questionapproach',e=>stageApproachingCarriers(e?.detail||{}));
window.addEventListener('maihoc:questionchange',onQuestion);
window.addEventListener('maihoc:answercorrect',e=>collectCaughtCarrier(e?.detail||{}));
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
