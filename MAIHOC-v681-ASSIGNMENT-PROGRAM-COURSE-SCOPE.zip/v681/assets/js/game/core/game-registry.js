(()=>{'use strict';
const mascots=[{id:'cat',name:'Cat',icon:'🐱'},{id:'bunny',name:'Bunny',icon:'🐰'},{id:'duck',name:'Duckling',icon:'🦆'},{id:'frog',name:'Frog',icon:'🐸'},{id:'poodle',name:'Fancy Poodle',icon:'🐩'},{id:'shiba',name:'City Shiba',icon:'🐕'},{id:'tiger',name:'Tiger',icon:'🐯'},{id:'raccoon',name:'Raccoon',icon:'🦝'},{id:'red-panda',name:'Red Panda',icon:'🐾'},{id:'penguin',name:'Penguin',icon:'🐧'},{id:'koala',name:'Koala',icon:'🐨'},{id:'snow-leopard',name:'Snow Leopard',icon:'🐆'}];
const worlds=[
 {id:'beach',name:'Sunny Beach',icon:'🏖️'},{id:'mountain',name:'Mountain Trail',icon:'⛰️'},{id:'space',name:'Space Journey',icon:'🚀'},{id:'farm',name:'Happy Farm',icon:'🚜'},{id:'castle',name:'Magic Castle',icon:'🏰'},{id:'snow',name:'Snow Adventure',icon:'❄️'},{id:'desert',name:'Desert Explorer',icon:'🏜️'},{id:'museum',name:'Discovery Museum',icon:'🏛️'},{id:'library',name:'Magic Library',icon:'📚'},{id:'music',name:'Music Festival',icon:'🎵'},
 {id:'school',name:'School Adventure',icon:'🏫'},{id:'home',name:'Home & Rooms',icon:'🏠'},{id:'park',name:'Park & Playground',icon:'🛝'},{id:'forest',name:'Forest Adventure',icon:'🌲'},{id:'jungle',name:'Jungle Climb',icon:'🌴'},{id:'water',name:'Underwater World',icon:'🌊'},{id:'sky',name:'Sky Adventure',icon:'☁️'},{id:'city',name:'City Explorer',icon:'🏙️'},{id:'market',name:'Market',icon:'🛍️'},{id:'biology',name:'Biology Lab',icon:'🔬'},{id:'physics',name:'Physics Lab',icon:'🧲'},{id:'chemistry',name:'Chemistry Lab',icon:'🧪'},{id:'engineering',name:'Engineering Studio',icon:'⚙️'},{id:'clinic',name:'Health Clinic',icon:'🩺'},{id:'business',name:'Business Studio',icon:'📊'}];
(window.MAIHOC_WORLD_PROFILES?.worlds||[]).forEach(w=>{if(!worlds.some(x=>x.id===w.id))worlds.push({...w})});
const engines=[
 {id:'walk-collect',name:'Walk & Collect',motion:'walk'},{id:'jump-catch',name:'Jump & Catch',motion:'jump'},{id:'climb-collect',name:'Climb & Collect',motion:'climb'},{id:'dive-catch',name:'Dive & Catch',motion:'dive'},{id:'fly-collect',name:'Fly & Collect',motion:'fly'},{id:'letter-catch',name:'Letter Catch',motion:'catch'},{id:'word-fishing',name:'Word Fishing',motion:'fish'},{id:'build-place',name:'Build & Place',motion:'build'},{id:'experiment',name:'Experiment Lab',motion:'experiment'},{id:'route-quest',name:'Route Quest',motion:'walk'},{id:'role-play',name:'Role Play',motion:'role'},{id:'evidence-hunt',name:'Evidence Hunt',motion:'search'}];

const customKey='maihoc.schoolEnglish.customAssets.v1';
function readCustom(){try{return JSON.parse(localStorage.getItem(customKey)||'{"mascots":[],"worlds":[]}')}catch{return {mascots:[],worlds:[]}}}
function saveCustom(v){localStorage.setItem(customKey,JSON.stringify(v))}
function installCustom(){
 const c=readCustom();(c.mascots||[]).forEach(x=>{if(!mascots.some(m=>m.id===x.id))mascots.push(x)});(c.worlds||[]).forEach(x=>{if(!worlds.some(w=>w.id===x.id))worlds.push(x)})
}
function addCustomAsset(type,item){
 const c=readCustom(),k=type==='mascot'?'mascots':'worlds';c[k]=c[k]||[];const i=c[k].findIndex(x=>x.id===item.id);if(i>=0)c[k][i]=item;else c[k].push(item);saveCustom(c);installCustom();return item
}
function removeCustomAsset(type,id){const c=readCustom(),k=type==='mascot'?'mascots':'worlds';c[k]=(c[k]||[]).filter(x=>x.id!==id);saveCustom(c)}
installCustom();

const carrierTypes=[
 {id:'butterfly',name:'Butterfly',icon:'🦋'},{id:'dragonfly',name:'Dragonfly',icon:'🪰'},{id:'bee',name:'Bee',icon:'🐝'},{id:'bluebird',name:'Bluebird',icon:'🐦'},{id:'robin',name:'Robin',icon:'🐦'},{id:'swallow',name:'Swallow',icon:'🐦'}];
const carrierMotions=[{id:'still',name:'Still'},{id:'wiggle',name:'Wiggle'},{id:'hover',name:'Hover'},{id:'flutter',name:'Flutter'},{id:'drift',name:'Drift'},{id:'dart',name:'Dart'},{id:'circle',name:'Circle'},{id:'fly-path',name:'Fly path'},{id:'hop',name:'Hop'},{id:'crawl',name:'Crawl'},{id:'climb',name:'Climb'},{id:'flee',name:'Flee'}];
/* Actions are fantasy/game abilities, never biological restrictions. Any character may use any action. */
const characterActions=[{id:'idle',name:'Idle'},{id:'walk',name:'Walk'},{id:'run',name:'Run'},{id:'jump',name:'Jump'},{id:'fly',name:'Fly'},{id:'climb',name:'Climb'},{id:'swim',name:'Swim'},{id:'dive',name:'Dive'},{id:'carry',name:'Carry'},{id:'push',name:'Push / Pull'},{id:'swing',name:'Swing'},{id:'dance',name:'Dance'}];
const actionStyles=[{id:'auto',name:'Auto / character-specific first'},{id:'generic',name:'Generic motion'},{id:'superhero',name:'Superhero'},{id:'wings',name:'Magic wings'},{id:'jetpack',name:'Jetpack'},{id:'balloon',name:'Balloon'},{id:'silly',name:'Silly / playful'}];
const reactionOptions=[{id:'happy_hop',name:'Happy hop'},{id:'paw_clap',name:'Paw clap'},{id:'tail_dance',name:'Tail dance'},{id:'dance_spin',name:'Spin dance'},{id:'sad_ears',name:'Sad ears'},{id:'cry_small',name:'Little cry'},{id:'pout',name:'Pout'},{id:'tantrum_small',name:'Funny tantrum'},{id:'oops',name:'Oops / surprised'},{id:'bump_head',name:'Bump head'},{id:'dizzy',name:'Dizzy stars'},{id:'victory_dance',name:'Victory dance'},{id:'super_celebrate',name:'Super celebrate'}];

const questionBanks=[
 {id:'Vocabulary',name:'Vocabulary'},{id:'Pronunciation',name:'Phonemes / Pronunciation'},{id:'Grammar',name:'Grammar'},{id:'Speaking',name:'Speaking'},{id:'Reading',name:'Reading'},{id:'Listening',name:'Listening'},{id:'Writing',name:'Writing'}];

const learningObjectiveOrder={Vocabulary:1,Pronunciation:2,Phonemes:2,Grammar:3,Speaking:4,Reading:5,Listening:6,Writing:7};
function loCode(grade,unit,skill){const n=learningObjectiveOrder[skill];return n?`G${grade}U${unit}L${String(n).padStart(2,'0')}`:''}
function isBankEnabled(grade,unit,skill){return get(grade,unit).questionBanks.includes(skill)}
const defaults={1:['cat','school','jump-catch'],2:['bunny','home','jump-catch'],3:['duck','forest','jump-catch'],4:['frog','water','jump-catch'],5:['poodle','sky','jump-catch'],6:['shiba','city','jump-catch'],7:['tiger','biology','jump-catch'],8:['raccoon','physics','jump-catch'],9:['red-panda','chemistry','jump-catch'],10:['penguin','engineering','jump-catch'],11:['koala','clinic','jump-catch'],12:['snow-leopard','business','jump-catch']};
const key='maihoc.schoolEnglish.gameSetup.v45';
function read(){try{return JSON.parse(localStorage.getItem(key)||'{}')}catch{return {}}}
function write(v){localStorage.setItem(key,JSON.stringify(v));window.dispatchEvent(new CustomEvent('maihoc-game-setup-change'))}
function previewRead(grade,unit){
 try{
  const qs=new URLSearchParams(location.search);
  if(qs.get('adminPreview')!=='1')return null;
  const raw=qs.get('previewConfig');
  if(raw)return JSON.parse(decodeURIComponent(escape(atob(raw))));
  const fallback=sessionStorage.getItem(`maihoc.gamePreview.${grade}.${unit}`);
  return fallback?JSON.parse(fallback):null;
 }catch{return null}
}
function get(grade,unit){const all=read(),d=defaults[grade]||defaults[1],saved=all?.[grade]?.[unit]||{},pv=previewRead(grade,unit),x=pv||saved;const characterId=x.characterId||x.character||d[0],sceneId=x.sceneId||x.scene||x.world||window.MAIHOC_WORLD_PROFILES?.get?.(grade,unit)?.worldId||d[1],engineId='jump-catch';return {characterId,sceneId,engineId,character:characterId,scene:sceneId,world:sceneId,engine:engineId,questionBanks:Array.isArray(x.questionBanks)?x.questionBanks:questionBanks.map(b=>b.id),carrierTypes:Array.isArray(x.carrierTypes)?x.carrierTypes:['butterfly','dragonfly','bee','bluebird','robin','swallow'],carrierMotions:(x.carrierMotions&&typeof x.carrierMotions==='object')?x.carrierMotions:{default:'wiggle'},enabledActions:['walk','jump'],actionStyles:(x.actionStyles&&typeof x.actionStyles==='object')?x.actionStyles:{},reactions:(x.reactions&&typeof x.reactions==='object')?x.reactions:{correct:['happy_hop','paw_clap','tail_dance'],wrong:['sad_ears','cry_small','pout'],miss:['oops'],bump:['bump_head','dizzy'],levelComplete:['victory_dance'],perfect:['super_celebrate']}}}
function set(grade,unit,value){const all=read();all[grade]=all[grade]||{};all[grade][unit]={...get(grade,unit),...value};write(all);return all[grade][unit]}
function reset(grade,unit){const all=read();if(all[grade])delete all[grade][unit];write(all)}
function registerPack(pack={}){
 const merge=(target,items)=>{(items||[]).forEach(item=>{if(!item||!item.id)return;const i=target.findIndex(x=>x.id===item.id);if(i>=0)target[i]={...target[i],...item};else target.push(item)})};
 merge(mascots,pack.mascots); merge(worlds,pack.worlds); merge(engines,pack.engines); merge(questionBanks,pack.questionBanks);
 window.dispatchEvent(new CustomEvent('maihoc-game-registry-change'));
 return {mascots:mascots.length,worlds:worlds.length,engines:engines.length,questionBanks:questionBanks.length};
}
const scenes=worlds;window.MAIHOC_GAME_REGISTRY={addCustomAsset,removeCustomAsset,readCustom,mascots,worlds,scenes,engines,questionBanks,carrierTypes,carrierMotions,characterActions,actionStyles,reactionOptions,learningObjectiveOrder,loCode,isBankEnabled,defaults,key,get,set,reset,read,previewRead,registerPack};
})();
