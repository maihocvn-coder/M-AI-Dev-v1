(()=>{'use strict';
/* Canonical School English grade configuration authority.
   Grade config is DATA only. It never implements an engine/world/character. */
const PROGRAM='school-english';
const defaults={
  1:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'cat',enabledActions:['walk','jump']}},
  2:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'bunny',enabledActions:['walk','jump']}},
  3:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'duck',enabledActions:['walk','jump']}},
  4:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'frog',enabledActions:['walk','jump']}},
  5:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'poodle',enabledActions:['walk','jump']}},
  6:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'shiba',enabledActions:['walk','jump']}},
  7:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'tiger',enabledActions:['walk','jump']}},
  8:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'raccoon',enabledActions:['walk','jump']}},
  9:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'red-panda',enabledActions:['walk','jump']}},
  10:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'penguin',enabledActions:['walk','jump']}},
  11:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'koala',enabledActions:['walk','jump']}},
  12:{content:{bankId:'MAISCHOOLENGLISH'},progression:{masteryThreshold:90},game:{engineId:'jump-catch',characterId:'snow-leopard',enabledActions:['walk','jump']}}
};
const clone=x=>JSON.parse(JSON.stringify(x));
function get(grade){const g=Number(grade)||1;return Object.freeze({program:PROGRAM,grade:g,...clone(defaults[g]||defaults[1])})}
function all(){return Object.keys(defaults).map(Number).map(get)}
window.MAIHOC_GRADE_CONFIG=Object.freeze({program:PROGRAM,get,all});
})();
