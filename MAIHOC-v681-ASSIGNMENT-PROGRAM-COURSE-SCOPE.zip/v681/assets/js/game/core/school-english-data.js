/* M-AI Học School English — canonical logical content authority.
   Consumers resolve School English through MAIHOC_CONTENT / MAISCHOOLENGLISH.
   Physical release selection is owned here only. V1 wraps the existing legacy
   banks without mutating them. Engine/world/character and learner state are
   intentionally outside this content authority. */
(()=>{'use strict';
  const PROGRAM_ID='schoolEnglish';
  const DEFAULT_VERSION='v1';
  const releases=new Map();
  let activeVersion=DEFAULT_VERSION;
  let previewVersion=null;

  const legacyV1=()=>({
    programId:PROGRAM_ID,
    version:'v1',
    status:'released',
    locked:true,
    bank:window.MAIHOC_BANK_DATA||{levels:[],questions:[]},
    knowledge:Array.isArray(window.MAIHOC_G6_LESSONS)?window.MAIHOC_G6_LESSONS:[],
    sage:window.MAIHOC_SAGE_KNOWLEDGE_DATA||window.MAIHOC_SAGE_KNOWLEDGE||null
  });
  releases.set('v1',legacyV1);

  function normalizeVersion(version){return String(version||'').trim().toLowerCase()}
  function provider(version){
    const key=normalizeVersion(version||activeVersion);
    const source=releases.get(key);
    if(!source)throw new Error('Unknown M-AI School English content release: '+key);
    return typeof source==='function'?source():source;
  }
  function resolvedVersion(options={}){
    return options.preview===true&&previewVersion?previewVersion:activeVersion;
  }
  function schoolEnglish(options={}){
    const release=provider(resolvedVersion(options));
    const bank=release.bank||{levels:[],questions:[]};
    const baseKnowledgeRows=Array.isArray(release.knowledge)?release.knowledge:[];
    const knowledgeRowsForGrade=(grade)=>{const g=Number(grade);const named=window['MAIHOC_G'+g+'_LESSONS'];return Array.isArray(named)?named:baseKnowledgeRows};
    return Object.freeze({
      programId:PROGRAM_ID,
      version:release.version||resolvedVersion(options),
      status:release.status||'unknown',
      locked:release.locked===true,
      release,
      bank(){return bank},
      levels(){return Array.isArray(bank.levels)?bank.levels:[]},
      questions(){return Array.isArray(bank.questions)?bank.questions:[]},
      knowledge({grade,unit,skill}={}){
        const rows=knowledgeRowsForGrade(grade??options.grade);return rows.filter(x=>(unit==null||Number(x.level)===Number(unit))&&(!skill||x.skill===skill));
      },
      sage(){return release.sage||null},
      select({grade,unit,skill,pool,surface}={}){
        const gradeNum=grade==null?null:Number(grade), unitNum=unit==null?null:Number(unit);
        const knowledgeRows=knowledgeRowsForGrade(gradeNum);
        const questions=(Array.isArray(bank.questions)?bank.questions:[]).filter(q=>(gradeNum==null||Number(q.grade)===gradeNum)&&(unitNum==null||Number(q.unit)===unitNum)&&(!skill||q.skill===skill)&&(!pool||q.pool===pool)&&(!surface||!Array.isArray(q.surfaces)||q.surfaces.includes(surface)));
        const levels=(Array.isArray(bank.levels)?bank.levels:[]).filter(l=>unitNum==null||Number(l.unit)===unitNum);
        const selectedKnowledge=knowledgeRows.filter(x=>(unitNum==null||Number(x.level)===unitNum)&&(!skill||x.skill===skill));
        return Object.freeze({programId:PROGRAM_ID,bankId:'MAISCHOOLENGLISH',version:release.version||resolvedVersion(options),grade:gradeNum,unit:unitNum,bank(){return {...bank,levels,questions}},levels(){return levels},questions(){return questions},knowledge(){return selectedKnowledge},sage(){return release.sage||null},sageContracts(){const svc=window.MAIHOC_SAGE_SERVICE;return {knowledge:selectedKnowledge.map(x=>svc?.knowledgeContract?.(x)||x.sageContract||null),questions:questions.map(x=>svc?.questionContract?.(x)||x.sageContract||null)}}});
      },
      ready(){return !!release.bank&&Array.isArray(release.knowledge)}
    });
  }

  const contentAuthority=Object.freeze({
    get(programId,options={}){
      if(programId!==PROGRAM_ID)throw new Error('Unknown M-AI Học content program: '+programId);
      return schoolEnglish(options);
    },
    activeVersion(programId=PROGRAM_ID){
      if(programId!==PROGRAM_ID)return null;
      return activeVersion;
    },
    previewVersion(programId=PROGRAM_ID){
      if(programId!==PROGRAM_ID)return null;
      return previewVersion;
    },
    /* Control-plane hooks. Admin UI is intentionally not implemented in this phase. */
    registerRelease(version,releaseOrProvider){
      const key=normalizeVersion(version);
      if(!key||key==='v1')return false; // V1 is frozen legacy authority.
      if(typeof releaseOrProvider!=='function'&&(!releaseOrProvider||typeof releaseOrProvider!=='object'))return false;
      releases.set(key,releaseOrProvider);
      return true;
    },
    activate(programId,version){
      if(programId!==PROGRAM_ID)return false;
      const key=normalizeVersion(version);
      const release=provider(key);
      if(String(release.status||'').toLowerCase()!=='released')return false;
      activeVersion=key;
      return true;
    },
    setPreview(programId,version){
      if(programId!==PROGRAM_ID)return false;
      if(version==null||version===''){previewVersion=null;return true}
      const key=normalizeVersion(version); provider(key); previewVersion=key; return true;
    }
  });

  window.MAIHOC_CONTENT=contentAuthority;
  Object.defineProperty(window,'MAISCHOOLENGLISH',{configurable:true,get(){return schoolEnglish()}});

  /* Compatibility facade: existing game controller keeps one stable data API. */
  const api={
    bank(){return schoolEnglish().bank()},
    levels(){return schoolEnglish().levels()},
    questions(){return schoolEnglish().questions()},
    knowledge(query){return schoolEnglish().knowledge(query)},
    sage(){return schoolEnglish().sage()},
    select(query){return schoolEnglish().select(query)},
    ready(){return schoolEnglish().ready()},
    version(){return schoolEnglish().version}
  };
  window.MAIHOC_SCHOOL_ENGLISH_DATA=Object.freeze(api);
})();
