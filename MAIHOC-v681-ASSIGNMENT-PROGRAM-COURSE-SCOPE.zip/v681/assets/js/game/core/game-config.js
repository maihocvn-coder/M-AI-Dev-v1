(()=>{'use strict';
/* Single gameplay selection authority. Context -> final asset IDs.
   Engines/worlds/characters are reusable registry assets; content never selects them. */
const JUMP_BASELINE_ACTIONS=Object.freeze(['walk','jump']);
const actionProgression=Object.freeze(Object.fromEntries(Array.from({length:12},(_,i)=>[i+1,JUMP_BASELINE_ACTIONS])));
const actionsFor=()=>[...JUMP_BASELINE_ACTIONS];
function adminOverride(grade,unit){
  /* Existing Admin-published records remain the control-plane store during migration.
     This resolver is the only runtime reader. */
  try{const raw=window.MAIHOC_GAME_REGISTRY?.read?.()||{};return raw?.[grade]?.[unit]||raw?.[String(grade)]?.[String(unit)]||{}}catch{return {}}
}
function previewOverride(grade,unit){try{const qs=new URLSearchParams(location.search);if(qs.get('adminPreview')!=='1')return {};const raw=qs.get('previewConfig');if(raw)return JSON.parse(decodeURIComponent(escape(atob(raw))));const v=sessionStorage.getItem(`maihoc.gamePreview.${grade}.${unit}`);return v?JSON.parse(v):{}}catch{return {}}}
function resolve(context={}){
  const grade=Number(context.grade)||1,unit=Math.max(1,Number(context.unit)||1);
  const gradeCfg=window.MAIHOC_GRADE_CONFIG?.get?.(grade)||{game:{}};
  const base=gradeCfg.game||{},profile=window.MAIHOC_WORLD_PROFILES?.get?.(grade,unit)||null,saved=adminOverride(grade,unit),preview=previewOverride(grade,unit),o={...saved,...preview};
  return Object.freeze({
    program:context.program||gradeCfg.program||'school-english',grade,unit,
    engineId:'jump-catch',
    worldId:o.worldId||o.sceneId||o.scene||o.world||profile?.worldId||base.worldId||'world.campus',
    sceneId:o.worldId||o.sceneId||o.scene||o.world||profile?.worldId||base.worldId||'world.campus',
    characterId:o.characterId||o.character||base.characterId||'cat',
    carrierSetId:o.carrierSetId||base.carrierSetId||null,
    reactionSetId:o.reactionSetId||base.reactionSetId||null,
    enabledActions:actionsFor(),
    actionStyles:o.actionStyles||{},carrierTypes:Array.isArray(o.carrierTypes)?o.carrierTypes:[],carrierMotions:o.carrierMotions||{default:'wiggle'},reactions:o.reactions||{}
  });
}
/* get is a compatibility alias only; resolve(context) is canonical. */
function get(grade,unit){return resolve({program:'school-english',grade,unit})}
window.MAIHOC_GAME_CONFIG=Object.freeze({resolve,get,actionProgression,enabledActions:actionsFor});
})();
