const uiLang=()=>{try{return (localStorage.getItem('maihoc.ui.language')||document.documentElement.lang||'vi').toLowerCase().startsWith('en')?'en':'vi'}catch{return 'vi'}};const KH=(vi,en)=>uiLang()==='en'?en:vi;
(()=>{
/* Universal School English frame: grade/unit identity comes from context; learning data comes from the canonical bank. */'use strict';const DATA=window.MAIHOC_SCHOOL_ENGLISH_DATA;const $=id=>document.getElementById(id);
const requestedContext=window.MAIHOC_SCHOOL_ENGLISH_CONTEXT||{};
const sourceBank=DATA?.bank?.();
const inferredGrade=Number(sourceBank?.questions?.find?.(q=>Number.isFinite(Number(q?.grade)))?.grade)||1;
const CONTEXT=Object.freeze({program:requestedContext.program||'school-english',grade:Number(requestedContext.grade)||inferredGrade});
const selectedContent=DATA?.select?.({grade:CONTEXT.grade});
const bank=selectedContent?.bank?.()||sourceBank;
const PRIMARY_GRADE=CONTEXT.grade;
const PRIMARY_ANIMAL=requestedContext.companionLabel||'Chuột';
const CONTENT_FAMILIES=Array.isArray(requestedContext.knowledgeFamilies)&&requestedContext.knowledgeFamilies.length?requestedContext.knowledgeFamilies:['Vocabulary','Phonics','Sentence Patterns','Pronunciation','Grammar','Listening','Reading','Speaking','Writing'].filter(skill=>bank?.questions?.some?.(q=>q.skill===skill));
const initialGameConfig=window.MAIHOC_GAME_CONFIG?.resolve?.({program:CONTEXT.program,grade:PRIMARY_GRADE,unit:1})||{};
const FRAME_ENGINE_ID=requestedContext.engineId||initialGameConfig.engineId||bank?.gradeGameEngine||bank?.levels?.[0]?.engine||'letter-catch';
const FRAME_ENGINE_NAME=requestedContext.engineName||bank?.levels?.[0]?.engine_name||String(FRAME_ENGINE_ID).split('-').map(x=>x.charAt(0).toUpperCase()+x.slice(1)).join(' ');
const gradeLabel=()=>`Grade ${PRIMARY_GRADE}`;
const gradeStorage=(suffix)=>`maihoc.schoolEnglish.g${PRIMARY_GRADE}.${suffix}`;
function phonemesFrom(v){const s=String(v||'');return [...new Set([...s.matchAll(/\/([^/]{1,5})\//g)].map(m=>m[1].trim()).filter(Boolean))];}
function playPhoneme(p){return !!window.MAIHOC_PHONEME_AUDIO?.play(p);}
function playEnglishChoice(text){const ps=phonemesFrom(text);if(ps.length===1&&String(text).trim().replace(/\s+/g,'')==='/'+ps[0]+'/'){if(playPhoneme(ps[0]))return;}window.MAIHOC_TTS?.speak(text);}
function questionPhoneme(q){if(!q)return '';const skill=String(q.skill||'').trim().toLowerCase();if(!['phonics','pronunciation'].includes(skill))return '';const vals=[q.phonemeTarget,q.targetSound,q.phoneme,q.pronunciationTarget,q.phonicsTarget,q.stimulus,q.prompt];for(const v of vals){for(const ph of phonemesFrom(v)){if(window.MAIHOC_PHONEME_AUDIO?.has?.(ph))return ph}}return ''}
function questionAudioSource(q){if(!q)return '';if(String(q.audioPrompt||'').trim())return String(q.audioPrompt).trim();if(String(q.skill||'').trim().toLowerCase()==='listening'&&String(q.stimulus||'').trim())return String(q.stimulus).trim();return ''}
function questionNeedsStimulus(q){const p=String(q?.prompt||'').toLowerCase();return /complete (the )?(sentence|dialogue|text)|fill (in )?(the )?blank|\bgap\b/.test(p)}
function validQuestionContract(q){if(!q||!String(q.prompt||'').trim())return false;const skill=String(q.skill||'').trim().toLowerCase();const hasResponse=(Array.isArray(q.options)&&q.options.length)||q.responseRequired||q.openResponse||skill==='speaking'||skill==='writing';if(!hasResponse)return false;if(questionNeedsStimulus(q)&&!String(q.stimulus||'').trim())return false;if(skill==='listening'&&!questionAudioSource(q))return false;return true}

if(!bank||!Array.isArray(bank.levels)||!Array.isArray(bank.questions)){document.body.insertAdjacentHTML('beforeend','<p style="padding:20px;color:var(--mh-danger)">Không tải được dữ liệu game. Hãy tải lại trang.</p>');return;}const key=gradeStorage('frame.v41');const safeGet=(k,f)=>window.MAIHOC_SCHOOL_ENGLISH.safeRead(k,f);const state=window.MAIHOC_SCHOOL_ENGLISH.createState({bank,storageKey:key});/* Every School English game entry starts in Level Play. Learn/Test remain selectable from Học & Chơi. */state.mode='play';const save=()=>window.MAIHOC_SCHOOL_ENGLISH.saveState(key,state);
const RESUME_KEY=gradeStorage('resume.v376');
const GAME_DESIGN_KEY='maihoc.schoolEnglish.gameDesign.v1';
const DEFAULT_COIN_RULE={correctFirstTry:2,correctAfterRetry:1,levelComplete:5,mastery90Bonus:10};
function coinRule(){try{const all=JSON.parse(localStorage.getItem(GAME_DESIGN_KEY)||'{}');return {...DEFAULT_COIN_RULE,...(all.default||{}),...(all.grades?.[String(PRIMARY_GRADE)]||{})}}catch{return {...DEFAULT_COIN_RULE}}}
function syncCoinUI(){const n=window.MAIHOC_WALLET?.load?.().balance;const shown=Number.isFinite(n)?n:state.coins;state.coins=shown;const b=$('pouchCoins');if(b)b.textContent=shown}
function awardCoins(amount,label,keySuffix){amount=Math.max(0,Number(amount)||0);if(!amount)return;const q=current();const id='mse:g'+PRIMARY_GRADE+':l'+state.unit+':'+(q?.id||'level')+':'+keySuffix,seenKey='maihoc.schoolEnglish.coinAwards.v1';let seen={};try{seen=JSON.parse(localStorage.getItem(seenKey)||'{}')}catch{};if(seen[id]){syncCoinUI();return}seen[id]=Date.now();try{localStorage.setItem(seenKey,JSON.stringify(seen))}catch{};if(window.MAIHOC_WALLET?.earn){window.MAIHOC_WALLET.earn(id,amount,label).then(()=>syncCoinUI()).catch(()=>{delete seen[id];try{localStorage.setItem(seenKey,JSON.stringify(seen))}catch{}})}else{state.coins+=amount;save();syncCoinUI()}}

function resumeSnapshot(){const q=state.queue[state.index];return {programId:'m-ai-school-english',grade:PRIMARY_GRADE,level:state.unit,mode:state.mode,index:state.index,questionId:q?.id||null,queueIds:state.queue.map(x=>x.id),topicFilter:state.topicFilter||null,updatedAt:new Date().toISOString()}}
function persistResume(){if(state.mode==='knowledge')return;const snap=resumeSnapshot();try{localStorage.setItem(RESUME_KEY,JSON.stringify(snap));localStorage.setItem('maihoc.student.lastSelfStudyActivity',JSON.stringify(snap))}catch{}}
const rememberRecentActivity=()=>persistResume();
const level=()=>bank.levels[state.unit-1];const items=()=>{const enabled=new Set(CONTENT_FAMILIES);return bank.questions.filter(q=>q.unit===state.unit&&q.pool===(state.mode==='test'&&bank.questions.some(x=>x.pool==='test')?'test':'practice')&&enabled.has(q.skill));};const current=()=>state.queue[state.index];window.MAIHOC_CURRENT_QUESTION=()=>state.mode==='knowledge'?null:current();let pendingTimer=0;/* Exactly one orientation landing; Level clicks and Play Level open the selected level directly. */const entryParams=new URLSearchParams(location.search);const HOME_DEMO=entryParams.get('homeDemo')==='1';/* External School English game entries use the same direct-play contract. */let showGameWelcome=false;/* v397: no intermediate welcome page; every Grade 1 entry opens Level Play directly. */const wantsResume=entryParams.get('resume')==='1';const entryKnowledgeTopic=entryParams.get('topic')||'Vocabulary';let resumeApplied=false;
function engineName(l=level()){return l?.engine_name||FRAME_ENGINE_NAME;}
function setupPrimaryAdventure(){renderPouch();window.MAIHOC_SCHOOL_ENGLISH?.setupBag()}
function pouchKey(){return gradeStorage('adventurePouch');}
const VISUAL_ICONS={ball:'⚽',bike:'🚲',bicycle:'🚲',book:'📘',bag:'🎒',cat:'🐱',dog:'🐶',fish:'🐟',sun:'☀️',moon:'🌙',star:'⭐',boy:'👦',girl:'👧',teacher:'👩‍🏫',school:'🏫',pencil:'✏️',pen:'🖊️',ruler:'📏',chair:'🪑',apple:'🍎',banana:'🍌',orange:'🍊',cake:'🍰',car:'🚗',bus:'🚌',train:'🚆',plane:'✈️',house:'🏠',home:'🏠',tree:'🌳',flower:'🌸',bird:'🐦',duck:'🦆',frog:'🐸',rabbit:'🐰',mouse:'🐭',hand:'✋',eye:'👁️',ear:'👂',nose:'👃',mouth:'👄',door:'🚪'};
function visualIconForOption(value){const raw=String(value||'').trim();if(!raw)return '•';const key=raw.toLowerCase();const singular=key.endsWith('s')?key.slice(0,-1):key;return VISUAL_ICONS[key]||VISUAL_ICONS[singular]||raw.slice(0,1).toUpperCase()}
function hasMeaningfulVisual(value){return visualIconForOption(value)!=='✨'}
function useSceneChoices(q){return false}
function pouchData(){return window.MAIHOC_SCHOOL_ENGLISH.readRewardBag(pouchKey(),false)}
function renderPouch(){return window.MAIHOC_SCHOOL_ENGLISH.renderRewardBag({key:pouchKey(),withCoins:false,emptyText:'Trả lời đúng để nhặt đồ cho '+PRIMARY_ANIMAL+' nhé!'})}
function collectAdventureItem(q){return window.MAIHOC_SCHOOL_ENGLISH.collectRewardObject(q,{key:pouchKey(),withCoins:false,emptyText:'Trả lời đúng để nhặt đồ cho '+PRIMARY_ANIMAL+' nhé!'})}

function remember(topic){if(HOME_DEMO)return;const q=state.queue[state.index];const last={grade:PRIMARY_GRADE,level:state.unit,mode:state.mode,question:state.mode==='knowledge'?null:q?.id||null,topic:state.mode==='knowledge'?topic||null:null,updated:Date.now()};try{localStorage.setItem('maihoc.schoolEnglish.lastPlayed',JSON.stringify(last))}catch{}}
function navigateUnit(nextUnit){const previousMode=state.mode;state.unit=Math.max(1,Math.min(bank.levels.length,Number(nextUnit)||1));state.index=0;state.done=false;state.mode=previousMode;state.topicFilter=null;showGameWelcome=false;history.replaceState(null,'','?level='+state.unit+'&mode='+state.mode);save();start()}window.MAIHOC_NAVIGATE_UNIT=navigateUnit;
function nav(){ $('levelList').replaceChildren();bank.levels.forEach(l=>{const b=document.createElement('button');b.className='level'+(l.unit===state.unit?' active':'');const progress=Object.values(state.mastery).filter(x=>x.unit===l.unit);const score=progress.length?Math.round(progress.reduce((a,v)=>a+v.weight,0)/progress.length*100):null;b.innerHTML='<span class="level-num">'+String(l.unit).padStart(2,'0')+'</span><span><strong></strong><small></small></span><span class="pct">'+(score===null?'—':score+'%')+'</span>';b.querySelector('strong').textContent=l.title;b.querySelector('small').textContent='🎮 '+engineName(l);b.onclick=()=>navigateUnit(l.unit);$('levelList').append(b)})}
function masteryRows(unit=state.unit){return Object.values(state.mastery).filter(x=>x&&x.unit===unit)}
function readiness(){const rows=masteryRows(),eligible=items(),score=rows.length?Math.round(rows.reduce((a,x)=>a+Number(x.weight||0),0)/rows.length*100):0;const r=$('readiness'),bar=$('readinessBar'),note=$('progressNote');if(r)r.textContent=rows.length?score+'%':'—';if(bar)bar.style.width=score+'%';if(note){note.replaceChildren();const skills=[...new Set(eligible.map(x=>x.skill))];const wrap=document.createElement('div');wrap.className='skill-progress-list';skills.forEach(skill=>{const skillRows=rows.filter(x=>x.skill===skill);const pct=skillRows.length?Math.round(skillRows.reduce((a,x)=>a+Number(x.weight||0),0)/skillRows.length*100):0;const row=document.createElement('div');row.className='skill-progress-row';const label=document.createElement('span');label.textContent=skill;const value=document.createElement('strong');value.textContent=pct+'%';row.append(label,value);wrap.append(row)});if(wrap.children.length)note.append(wrap);else note.textContent=KH('Chưa có tiến trình ở Level này','No progress in this Level yet')}syncCoinUI()}
function theme(){const l=level();document.documentElement.style.setProperty('--sky',l.colors[0]);document.documentElement.style.setProperty('--sun',l.colors[1]);const en=engineName(l);$('levelLabel').textContent='LEVEL '+String(l.unit).padStart(2,'0')+' / '+bank.levels.length+' · '+en.toUpperCase();$('levelTitle').textContent=l.title;$('scope').textContent='';$('scope').hidden=true;$('sceneCaption').innerHTML='🎮 '+en.toUpperCase();nav();readiness();setupPrimaryAdventure()}
function gameWelcome(){remember();$('questionSkill').textContent='BẮT ĐẦU';$('questionNumber').textContent='';$('prompt').hidden=false;$('prompt').textContent='Chào mừng em đến với Học & Chơi!';$('stimulus').hidden=false;$('stimulus').replaceChildren();$('stimulus').classList.add('game-welcome');const card=document.createElement('div');card.className='game-welcome-card';card.innerHTML='<p><strong>Level '+state.unit+': '+level().title+'</strong></p><p>🎮 <b>'+engineName(level())+'</b> · Nhìn hình và chữ ngay trong màn hình game, rồi chọn đáp án đúng để giúp '+PRIMARY_ANIMAL+' đi tiếp.</p><p>🎒 Trả lời đúng, <b>hình của đáp án</b> sẽ bay vào Túi phiêu lưu. Em cũng nhận coin khi hoàn thành thử thách.</p><p>✨ <b>Sage</b> luôn ở góc phải phía dưới. Khi chưa chắc, mở Sage để nhận gợi ý.</p>';const navNote=document.createElement('p');navNote.className='game-welcome-nav-note';navNote.textContent='Chọn Học kiến thức, Luyện 10 câu, Chơi Level hoặc Bài luyện kiểm tra ở thanh điều hướng bên trái để bắt đầu.';card.append(navNote);$('stimulus').append(card);$('answers').replaceChildren();$('answers').hidden=true;$('report').hidden=true;$('next').hidden=true;$('moreHint').hidden=true;$('sageText').textContent='Mình là Sage. Khi em cần, nhấn biểu tượng Sage ở góc phải để mình cùng em tìm manh mối nhé!';$('sceneStatus').textContent='Chọn Level hoặc cách học để bắt đầu cuộc phiêu lưu!';}
function start(){document.body.dataset.mseMode=state.mode;clearTimeout(pendingTimer);theme();document.body.dataset.schoolEnglishMode=state.mode;window.MAIHOC_SCHOOL_ENGLISH?.syncModeUI(state.mode);state.index=0;state.tries=0;state.hint=0;state.done=false;state.testScore=0;const chosenSkill=state.topicFilter;let baseItems=items().filter(q=>!chosenSkill||!['practice','play'].includes(state.mode)||q.skill===chosenSkill);if(HOME_DEMO){const allowed=new Set(['Vocabulary','Grammar','Listening','Reading']);baseItems=baseItems.filter(q=>allowed.has(q.skill)&&validQuestionContract(q)&&Array.isArray(q.sage)&&q.sage.length>=2&&q.sageCoach&&Array.isArray(q.sageCoach.askMore));for(let i=baseItems.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[baseItems[i],baseItems[j]]=[baseItems[j],baseItems[i]]}}if(state.mode==='play'){if(chosenSkill){state.queue=baseItems.slice(0,10)}else{const skills=CONTENT_FAMILIES;const buckets=Object.fromEntries(skills.map(sk=>[sk,baseItems.filter(q=>q.skill===sk)]));state.queue=[];for(const sk of skills){if(buckets[sk].length)state.queue.push(buckets[sk].shift())}const rest=[];skills.forEach(sk=>rest.push(...buckets[sk]));state.queue.push(...rest.slice(0,Math.max(0,10-state.queue.length)))}}else if(state.mode==='practice'&&chosenSkill){let done=0;try{const pp=JSON.parse(localStorage.getItem('maihoc_primary_progress')||'{}');done=pp['L'+state.unit+'|'+chosenSkill]?.done||0}catch{};const ordered=baseItems.slice(0,30);state.queue=ordered.slice(done%20).concat(ordered.slice(0,done%20));}else{state.queue=baseItems.slice(0,state.mode==='test'?Math.min(20,items().length):10)}
if(wantsResume&&!resumeApplied){
  /* v381 Continue contract: Student Home Continue opens the requested Level immediately at Question 1.
     Do not restore a stale/shuffled queue snapshot here; the current Level URL is authoritative. */
  state.index=0;
  showGameWelcome=false;
  resumeApplied=true;
}

if(state.mode!=='knowledge'&&!state.queue.length){const fallback=items().slice(0,state.mode==='test'?20:10);state.queue=fallback;state.index=0;showGameWelcome=false}
if(state.mode!=='knowledge'&&!current()&&state.queue.length){state.index=0}
if(state.mode!=='knowledge'&&(!state.queue.length||!current())){const enabled=new Set(CONTENT_FAMILIES);const emergency=bank.questions.filter(q=>q.unit===state.unit&&enabled.has(q.skill)).slice(0,10);state.queue=emergency;state.index=0;showGameWelcome=false}
state.topicFilter=null;if(state.mode==='knowledge'){knowledge(entryKnowledgeTopic);return}if(state.mode==='play'&&showGameWelcome){gameWelcome();return}render()}
function expandCurriculumPhrases(list){
  const prefixes=['play ','go ','do ','have ','get ','take ','visit ','watch ','read ','listen to ','talk about ','go to ','go by ','travel by '];
  return (list||[]).flatMap(v=>{
    if(typeof v!=='string'||!v.includes('/'))return [v];
    const low=v.trim().toLowerCase(),pre=prefixes.find(p=>low.startsWith(p));
    if(!pre)return [v];
    const head=v.trim().slice(0,pre.length),rest=v.trim().slice(pre.length);
    if(/[()\[\]]/.test(rest))return [v];
    const bits=rest.split('/').map(x=>x.trim()).filter(Boolean);
    return bits.length>1?bits.map(x=>head+x):[v];
  });
}
function knowledge(skill='Vocabulary'){
  const lessons=selectedContent?.knowledge?.()||[];
  const knowledgeHead=$('questionSkill')?.closest('.question-head');if(knowledgeHead)knowledgeHead.hidden=true;$('questionSkill').textContent='';$('questionNumber').textContent='';
  $('prompt').textContent='';$('prompt').hidden=true;
  $('answers').hidden=true;$('answers').replaceChildren();$('stimulus').hidden=false;$('stimulus').replaceChildren();$('stimulus').classList.add('lesson-container');
  $('report').hidden=true;$('moreHint').hidden=true;$('next').hidden=true;
  const wrap=$('stimulus'),add=(tag,cls,txt,parent=wrap)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;parent.append(e);return e};
  const speak=t=>{if(t)window.MAIHOC_TTS?.speak(t)};
  const tabs=add('nav','knowledge-tabs','');tabs.setAttribute('aria-label',KH('Chủ đề kiến thức','Knowledge topics'));const knowledgeLabels={Vocabulary:['Từ vựng','Vocabulary'],Phonics:['Phonics','Phonics'],'Sentence Patterns':['Mẫu câu','Sentence Patterns'],Pronunciation:['Phát âm','Pronunciation'],Grammar:['Ngữ pháp','Grammar'],Listening:['Nghe','Listening'],Reading:['Đọc','Reading'],Speaking:['Nói','Speaking'],Writing:['Viết','Writing']};CONTENT_FAMILIES.forEach(sk=>{const labels=knowledgeLabels[sk]||[sk,sk],b=add('button','knowledge-tab'+(sk===skill?' active':''),KH(labels[0],labels[1]),tabs);b.type='button';b.dataset.knowledgeSkill=sk;b.setAttribute('aria-pressed',sk===skill?'true':'false');b.onclick=()=>knowledge(sk)});
  const x=lessons.find(x=>x.skill===skill);if(!x)return;const sv=x.studentView||{};window.dispatchEvent(new CustomEvent('maihoc:questionchange',{detail:{question:null,source:'knowledge'}}));window.MAIHOC_KNOWLEDGE_CONTEXT={gradeId:PRIMARY_GRADE,unitId:state.unit,unit:state.unit,skill,loId:x.loId,conceptId:x.conceptId,target:x.target,lesson:x};window.dispatchEvent(new CustomEvent('maihoc:knowledgechange',{detail:window.MAIHOC_KNOWLEDGE_CONTEXT}));
  const body=add('section','knowledge-body','');add('h2','knowledge-title',x.title,body);
  if(skill==='Phonics'){
    const letter=sv.letter||x.letterTarget||sv.target||x.target||'';const phs=phonemesFrom(sv.phoneme||x.phonemeTarget||'');const targetBox=add('div','phonic-target','',body);add('span','phonic-target-text',phs.length?('Letter '+letter+' → /'+phs[0]+'/'):('Letter '+letter),targetBox);phs.forEach(ph=>{const pb=add('button','phoneme-audio','▶ /'+ph+'/',targetBox);pb.type='button';pb.setAttribute('aria-label','Nghe âm /'+ph+'/');if(window.MAIHOC_PHONEME_AUDIO?.has(ph)){pb.onclick=()=>playPhoneme(ph)}else{pb.disabled=true;pb.title='Thiếu audio âm vị đã xác minh';pb.dataset.audioMissing='true'}});
    if(sv.video?.type==='video'){const f=document.createElement('iframe');f.className='phonics-video';f.src='https://www.youtube.com/embed/'+sv.video.id+'?playsinline=1&origin='+encodeURIComponent(location.origin)+(sv.video.start?'&start='+encodeURIComponent(sv.video.start):'');f.title=sv.video.label||'Phonics pronunciation';f.referrerPolicy='strict-origin-when-cross-origin';f.allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';f.allowFullscreen=true;body.append(f)}
    if(sv.contrastVideo?.type==='video'){add('h3','','So sánh âm gần giống',body);const f2=document.createElement('iframe');f2.className='phonics-video';f2.src='https://www.youtube.com/embed/'+sv.contrastVideo.id+'?playsinline=1&origin='+encodeURIComponent(location.origin)+(sv.contrastVideo.start?'&start='+encodeURIComponent(sv.contrastVideo.start):'');f2.title=sv.contrastVideo.label||'Sound contrast';f2.referrerPolicy='strict-origin-when-cross-origin';f2.allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';f2.allowFullscreen=true;body.append(f2)}
    if(sv.examples?.length){add('h3','',KH('Nghe từ mẫu','Listen to model words'),body);const d=add('div','phonic-examples','',body);sv.examples.forEach(w=>{const b=add('button','', '▶ '+w,d);b.onclick=()=>speak(w)})}
    if(sv.practiceChecks?.length){add('h3','',sv.phoneme?'Luyện nghe và phân biệt':'Luyện nghe',body);sv.practiceChecks.forEach((q,qi)=>{const card=add('div','mini-check','',body);add('p','',q.prompt,card);if(q.listenWord){const lb=add('button','mini-listen','▶ Nghe',card);lb.onclick=()=>speak(q.listenWord)}q.options.forEach((op,oi)=>{const b=add('button','',op,card);b.onclick=()=>{if(q.listenOptions){speak(op);return}card.querySelectorAll('button:not(.mini-listen)').forEach(z=>z.disabled=true);const fb=add('span','mini-feedback',oi===q.answer?'✓ Đúng rồi!':'Chưa đúng — nghe lại rồi thử câu tiếp theo.',card);fb.classList.add(oi===q.answer?'ok':'no')}})})}
  }else if(skill==='Vocabulary'){
    const list=add('div','word-list','',body);(sv.words||x.wordItems||[]).forEach(w=>{const row=add('div','word-row','',list);const b=add('button','word-audio','▶',row);b.onclick=()=>speak(w.word);add('strong','',w.word,row);add('span','',w.meaning?' — '+w.meaning:'',row)});
    if(sv.examples?.length){add('h3','',KH('Ví dụ trong câu','Examples'),body);sv.examples.forEach(ex=>{const row=add('div','vocab-example','',body);const b=add('button','word-audio','▶',row);b.onclick=()=>speak(ex.en);const t=add('div','', '',row);add('strong','',ex.en,t);add('small','',ex.vi,t)})}
  }else if(skill==='Sentence Patterns'){
    const teach=sv.teaching||{},pf=sv.patternFlow;add('h3','',teach.title||KH('Em học cách nói gì?','What will I learn to say?'),body);const tc=add('div','pattern-teach','',body);add('div','pattern-vi',teach.use||'',tc);if(teach.formula)add('div','pattern-formula',teach.formula,tc);
    if(pf){add('h3','',KH('1. Hiểu và dùng','1. Meaning and use'),body);pf.meaningUse?.forEach(x=>{const row=add('div','pattern-example','',body);const b=add('button','word-audio','🔊',row);b.onclick=()=>speak(x.phrase.replace('…','Bill'));const t=add('div','', '',row);add('strong','',x.phrase+' = '+x.meaning,t);add('div','teacher-note',x.use,t)});add('h3','',KH('2. Từ em cần biết','2. Words you need'),body);const kw=add('div','pattern-teach','',body);pf.keyWords?.forEach(x=>add('div','pattern-vi',x.word+' — '+x.meaning,kw));add('h3','',KH('3. Nghe và nói theo','3. Listen and repeat'),body);pf.repeat?.forEach(en=>{const row=add('div','pattern-example mimic','',body);const b=add('button','word-audio','🔊',row);b.onclick=()=>speak(en);add('strong','',en,row)});add('h3','',KH('4. Em chọn câu nào?','4. Choose the sentence'),body);pf.checks?.forEach(ch=>{const box=add('div','pattern-teach','',body);add('div','pattern-vi',ch.prompt,box);ch.options.forEach((op,i)=>{const b=add('button','lesson-cta',op,box);b.onclick=()=>{box.querySelectorAll('.pattern-feedback').forEach(n=>n.remove());add('div','pattern-feedback',i===ch.answer?'⭐ '+ch.feedback:'Thử lại nhé. Nghĩ xem em đang gặp bạn hay đang tạm biệt bạn.',box)}})});if(pf.swap){add('h3','',KH('5. Đổi tên, tạo câu mới','5. Swap the name'),body);const box=add('div','pattern-teach','',body);add('div','pattern-vi',pf.swap.instruction,box);pf.swap.items.forEach(name=>{const b=add('button','lesson-cta',pf.swap.lead+' '+name+'.',box);b.onclick=()=>speak(pf.swap.lead+' '+name+'.')})}if(pf.yourTurn){add('h3','',KH('6. Đến lượt em','6. Your turn'),body);const d=add('div','dialogue-practice','',body);add('p','',pf.yourTurn.prompt,d);const qb=add('button','dialogue-listen','🔊 '+pf.yourTurn.model,d);qb.onclick=()=>speak(pf.yourTurn.model)}}else{add('div','pattern-vi',teach.use||'',tc)}
  }else{
    // Secondary/upper-secondary Knowledge uses the authored studentView schema.
    // Keep this renderer schema-driven so Grades 6–12 share the frame without
    // being forced through the Primary Phonics/Sentence-Patterns presentation.
    const section=(title)=>title?add('h3','knowledge-section-title',title,body):null;
    const text=(value,cls='knowledge-text')=>{if(value==null||value==='')return null;return add('p',cls,String(value),body)};
    const list=(values)=>{if(!Array.isArray(values)||!values.length)return;const ul=add('ul','knowledge-list','',body);values.forEach(v=>{const li=add('li','',typeof v==='string'?v:(v.text||v.label||v.word||v.phrase||JSON.stringify(v)),ul);if(typeof v==='object'&&v.example)add('small','knowledge-example',' '+v.example,li)})};
    if(sv.intro)text(sv.intro,'knowledge-intro');
    if(skill==='Pronunciation'){
      if(sv.explanation)text(sv.explanation);
      (sv.soundGroups||[]).forEach(g=>{section(g.label||g.sound||g.target||'');text(g.explanation||g.note||'');list(g.examples||g.words)});
      if(sv.phonemes?.length){section(KH('Âm trọng tâm','Target sounds'));const d=add('div','phonic-examples','',body);sv.phonemes.forEach(ph=>{const val=typeof ph==='string'?ph:(ph.phoneme||ph.sound||ph.label||'');const b=add('button','phoneme-audio','▶ '+val,d);b.type='button';b.onclick=()=>{const clean=String(val).replaceAll('/','');if(!playPhoneme(clean))speak(val)}})}
      section(KH('Mẹo luyện tập','Practice tips'));list(sv.teacherTips||sv.guidedPractice);
    }else if(skill==='Grammar'){
      (sv.sections||[]).forEach(sec=>{section(sec.heading||sec.title);text(sec.text||sec.explanation||sec.rule);list(sec.points||sec.examples)});
      if(sv.summary){section(KH('Tóm tắt','Summary'));text(sv.summary)}
      if(sv.examples?.length){section(KH('Ví dụ','Examples'));list(sv.examples)}
      if(sv.mistakes?.length){section(KH('Lỗi cần tránh','Common mistakes'));list(sv.mistakes)}
    }else if(skill==='Listening'){
      const d=sv.listening||{};section(d.scenario||KH('Chiến lược nghe','Listening strategy'));list(d.focus||d.steps||d.strategy);if(d.model||d.transcript)text(d.model||d.transcript,'lesson-quote');list(d.questions||d.checks);
    }else if(skill==='Reading'){
      list(sv.strategy);const d=sv.reading||{};section(d.title||KH('Bài đọc','Reading'));text(d.passage||d.text||d.content,'lesson-quote');list(d.questions||d.checks);
    }else if(skill==='Speaking'){
      const d=sv.speaking||{};section(d.scenario||KH('Nhiệm vụ nói','Speaking task'));text(d.goal||d.task);list(d.usefulLanguage||d.usefulPhrases||d.phrases);if(d.model)text(d.model,'lesson-quote');
    }else if(skill==='Writing'){
      const d=sv.writing||{};section(KH('Nhiệm vụ viết','Writing task'));text(d.task);text(d.purpose);list(d.organisation||d.organization||d.plan);list(d.usefulLanguage||d.usefulPhrases);if(d.model)text(d.model,'lesson-quote');list(d.checklist);
    }else{
      Object.entries(sv).forEach(([k,v])=>{if(k==='intro')return;if(typeof v==='string'){section(k.replace(/([A-Z])/g,' $1'));text(v)}else if(Array.isArray(v)){section(k.replace(/([A-Z])/g,' $1'));list(v)}});
    }
  }
}
function speak(s){if(!window.MAIHOC_TTS?.speak(s)){$('sageText').textContent='Trình duyệt này không hỗ trợ đọc âm thanh.'}}

function render(){const _qh=$('questionSkill')?.closest('.question-head');if(_qh)_qh.hidden=false;const _a=$('answers');if(_a){_a.style.opacity='';_a.style.transition='';_a.style.pointerEvents=''}const _l=$('catchLane');if(_l){_l.style.opacity='';_l.style.transition='';_l.style.pointerEvents=''}const _st=$('sceneStatus');if(_st){_st.style.fontSize='';_st.style.padding='';_st.style.boxShadow='';_st.style.transform='';_st.style.zIndex=''}remember();rememberRecentActivity();if(state.mode!=='knowledge'){window.MAIHOC_KNOWLEDGE_CONTEXT=null;}$('prompt').hidden=false;$('answers').hidden=false;$('stimulus').classList.remove('lesson-container');let q=current();if(q&&q.unit!==state.unit){console.error('School English stale question/unit mismatch', {stateUnit:state.unit,questionId:q.id,questionUnit:q.unit});state.queue=items().filter(x=>!state.topicFilter||x.skill===state.topicFilter).slice(0,10);state.index=0;q=current();}if(q&&!validQuestionContract(q)){console.error('Invalid School English question content contract',q);state.queue=items().filter(validQuestionContract).slice(0,10);state.index=0;}const safeQ=current();if(safeQ!==q)return render();$('report').hidden=!q;if(!q){if(state.mode==='play'){window.dispatchEvent(new CustomEvent('maihoc:levelcomplete',{detail:{grade:PRIMARY_GRADE,unit:state.unit,perfect:masteryRows().length>0&&masteryRows().every(x=>Number(x.weight||0)>=.999)}}));const rule=coinRule();awardCoins(rule.levelComplete,'M-AI School English · '+gradeLabel()+' · Level '+state.unit+' complete','complete')} $('questionSkill').textContent='LEVEL COMPLETE';$('questionNumber').textContent='WELL DONE';$('prompt').textContent=state.mode==='test'?'Practice Test finished · '+state.testScore+' / '+state.queue.length+' correct':'Tiến trình của em đã được cập nhật';$('stimulus').hidden=true;$('answers').replaceChildren();$('sageText').textContent=state.mode==='test'?'Đã ghi nhận kết quả. Xem lại Knowledge ở những mục cần luyện thêm.':'Tốt lắm! Em có thể chọn một kỹ năng bên dưới để luyện tiếp. Phần trăm cũng đã cập nhật ở Bản đồ Level bên trái.';$('sceneStatus').textContent='Level clear ✦';$('next').hidden=state.unit===bank.levels.length;$('next').textContent='Next level →';$('next').onclick=()=>{state.unit++;state.mode='play';save();start()};;$('moreHint').hidden=true;if(state.mode!=='test'){const skills=[...new Set(items().map(x=>x.skill))];const box=$('answers');box.replaceChildren();box.hidden=false;const title=document.createElement('p');title.className='lesson-note';title.textContent='Chọn kỹ năng em muốn cải thiện:';box.append(title);skills.forEach(skill=>{const vals=Object.values(state.mastery).filter(x=>x.unit===state.unit&&x.skill===skill);const pct=vals.length?Math.round(vals.reduce((a,v)=>a+v.weight,0)/vals.length*100):0;const b=document.createElement('button');b.textContent=skill+' · '+pct+'% → Luyện tiếp';b.onclick=()=>{state.topicFilter=skill;state.mode='play';start()};box.append(b)});$('next').hidden=true;}const aid=new URLSearchParams(location.search).get('assignment_id');if(aid){try{const aa=JSON.parse(localStorage.getItem('maihoc.demo.assignments')||'[]'),ix=aa.findIndex(x=>x.id===aid);if(ix>=0){const pct=state.mode==='test'?Math.round(state.testScore/Math.max(1,state.queue.length)*100):100;aa[ix]={...aa[ix],status:'submitted',score:pct,submitted_at:new Date().toISOString()};localStorage.setItem('maihoc.demo.assignments',JSON.stringify(aa))}}catch{}}return}window.dispatchEvent(new CustomEvent('maihoc:questionchange',{detail:{question:q}}));state.tries=0;state.hint=0;state.done=false;$('next').hidden=false;$('next').disabled=true;$('next').textContent='Câu tiếp theo →';$('moreHint').hidden=state.mode==='test';$('moreHint').textContent='Ask Sage · gợi ý 1';$('questionSkill').textContent=q.skill.toUpperCase();$('questionNumber').textContent=(state.mode==='test'?'BÀI KIỂM TRA ':'CÂU ')+(state.index+1)+' / '+state.queue.length;$('prompt').textContent=q.prompt;$('stimulus').replaceChildren();$('stimulus').classList.remove('g1-audio-stimulus');const ph=questionPhoneme(q);const audioSource=questionAudioSource(q);const hasQuestionAudio=!!(ph||audioSource);const hideStimulus=q.hideStimulusText===true||String(q.skill||'').trim().toLowerCase()==='listening';const showStimulusText=!!q.stimulus&&!hideStimulus;$('stimulus').hidden=!(hasQuestionAudio||showStimulusText);if(hasQuestionAudio)$('stimulus').classList.add('g1-audio-stimulus');if(showStimulusText){const span=document.createElement('span');span.textContent=q.stimulus;$('stimulus').append(span)}if(hasQuestionAudio){const btn=document.createElement('button');btn.className='question-audio';btn.textContent='▶ Nghe';btn.setAttribute('aria-label',ph?'Nghe âm /'+ph+'/':'Nghe âm thanh của câu hỏi');btn.setAttribute('title',ph?'Listen to /'+ph+'/':'Nghe âm thanh của câu hỏi');btn.onclick=()=>{if(ph){playPhoneme(ph);return}if(audioSource)speak(audioSource)};$('stimulus').append(btn)}$('answers').replaceChildren();q.options.forEach((option,i)=>{const row=document.createElement('div');row.className='answer-row';const b=document.createElement('button');b.textContent=option;b.onclick=()=>answer(i,b);row.append(b);if(q.ttsOptions||['phonics','pronunciation'].includes(String(q.skill||'').trim().toLowerCase())){const a=document.createElement('button');a.className='option-audio';a.textContent='🔊';a.setAttribute('aria-label','Listen to '+option);a.onclick=e=>{e.stopPropagation();playEnglishChoice(option)};row.append(a)}$('answers').append(row)});$('sageText').textContent=state.mode==='test'?'Làm bài độc lập. Sage sẽ trở lại sau khi hoàn thành bài kiểm tra.':String((q.sage&&q.sage[0])||'Nhìn kỹ câu hỏi và các lựa chọn nhé.').replace(/^[\s·•.;,:-]+/,'').replace(/\s+/g,' ').trim();if(state.mode!=='test'){state.hint=1;$('moreHint').hidden=false;$('moreHint').textContent='GỢI Ý TIẾP THEO →'}$('sceneStatus').textContent=state.mode==='test'?'Test in progress':'Chọn đáp án để tiếp tục!';;$('obstacle').textContent=level().obstacles[state.index%level().obstacles.length];$('obstacle').className='obstacle'+(useSceneChoices(q)?' flying':'');$('scene').classList.remove('celebrate','bonked');$('sceneStatus').textContent=state.mode==='play'?'LETTER CATCH · bắt đúng hình/chữ để chơi tiếp':'Chọn đáp án để tiếp tục!';$('scene').classList.remove('bonked');$('obstacle').classList.remove('bonk');{const m=$('mouth');if(m)m.textContent='⌣'};$('evidence').textContent='';if((q.skill==='Speaking'||q.skill==='Writing')&&state.mode!=='test')openResponse(q);}
function openResponse(q){$('answers').replaceChildren();const area=$('answers');area.style.display='block';const note=document.createElement('p');note.className='lesson-note';note.textContent=q.skill==='Speaking'?'Say a complete sentence. You may record and replay your voice. Recording is not graded.':'Write your own complete sentence. Review it before continuing; automatic grading is unavailable.';area.append(note);let content;if(q.skill==='Writing'){content=document.createElement('textarea');content.className='lesson-draft';content.rows=3;content.placeholder='Write your sentence here';area.append(content)}else{content=document.createElement('input');content.className='lesson-draft';content.placeholder='Type the sentence you said (optional)';area.append(content);const speakButton=document.createElement('button');speakButton.className='lesson-cta';speakButton.textContent='▶ Hear a model';speakButton.onclick=()=>speak(q.options[q.answer]);area.append(speakButton);const record=document.createElement('button');record.className='lesson-cta';record.textContent='● Record';area.append(record);record.onclick=async()=>{try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});const media=new MediaRecorder(stream);let parts=[];media.ondataavailable=e=>parts.push(e.data);media.onstop=()=>{const player=document.createElement('audio');player.controls=true;player.src=URL.createObjectURL(new Blob(parts,{type:media.mimeType}));area.append(player);stream.getTracks().forEach(t=>t.stop())};media.start();record.textContent='■ Stop';record.onclick=()=>{media.stop();record.disabled=true}}catch{record.textContent='Microphone unavailable'}}}const submit=document.createElement('button');submit.className='lesson-cta';submit.textContent='Finish my response →';submit.onclick=()=>{if(q.skill==='Writing'&&!content.value.trim()){content.focus();return}state.done=true;$('scene').classList.add('celebrate');$('sageText').textContent=q.skill==='Writing'?'Kiểm tra lại: câu có chủ ngữ, động từ và một chi tiết rõ ràng chưa?':'Nghe lại phần em vừa nói và thử thêm một chi tiết nếu cần.';$('evidence').textContent='Submitted for reflection · no automatic mastery score';$('next').hidden=false;$('next').textContent='Next mission →';$('next').onclick=()=>{state.index++;area.style.display='';render()}};area.append(submit)}
function masteryKey(q){return String(q?.id||[q?.unit,q?.skill,q?.lo].filter(Boolean).join(':'))}
function evidence(q,correct){const mk=masteryKey(q);if(state.mode==='test'){state.mastery[mk]={questionId:q.id,lo:q.lo,unit:state.unit,skill:q.skill,weight:correct?1:0,updated:Date.now()};save();readiness();nav();return}if(!correct)return;const usedExtraHint=state.hint>1;const weight=state.tries===1&&!usedExtraHint?1:state.tries<=2?.65:.38;const prev=state.mastery[mk];state.mastery[mk]={questionId:q.id,lo:q.lo,unit:state.unit,skill:q.skill,weight:prev?Math.max(.1,Number(prev.weight||0)*.45+weight*.55):weight,updated:Date.now()};$('evidence').textContent='';const rule=coinRule();awardCoins(state.tries===1?rule.correctFirstTry:rule.correctAfterRetry,'M-AI School English · '+gradeLabel()+' · Level '+state.unit+' · correct answer','correct');save();readiness();nav();window.dispatchEvent(new CustomEvent('maihoc:progresschange',{detail:{grade:PRIMARY_GRADE,unit:state.unit,questionId:q.id,skill:q.skill,weight:state.mastery[mk].weight}}))}
function showSkillChoice(){const nextQ=state.queue[state.index+1];const enabled=[...new Set(items().map(x=>x.skill))];const data=enabled.map(skill=>{const rows=masteryRows().filter(x=>x.skill===skill);const pct=rows.length?Math.round(rows.reduce((a,x)=>a+Number(x.weight||0),0)/rows.length*100):0;return {skill,pct,available:skill===nextQ?.skill}});$('prompt').textContent='Tiến trình đã cập nhật';$('questionSkill').textContent='TIẾN TRÌNH';$('questionNumber').textContent='';$('answers').replaceChildren();$('answers').hidden=false;$('stimulus').hidden=true;$('next').hidden=true;$('sageText').textContent='Tiến trình vừa được cập nhật và lưu ở navigation. Chọn kỹ năng để làm câu demo tiếp theo.';$('sceneStatus').textContent='Đã cập nhật tiến trình';if(window.MAIHOC_PROGRESS_UI){window.MAIHOC_ACTIVE_LEVEL=state.unit;MAIHOC_PROGRESS_UI.show(data,(skill)=>{state.topicFilter=skill;state.mode='play';start()},state.unit)}else{const b=document.createElement('button');b.textContent='Làm Demo Question 2 →';b.onclick=()=>{state.index++;render()};$('answers').append(b)}}
function clearGameFeedback(){
  clearTimeout(pendingTimer);pendingTimer=0;
  const a=$('answers');if(a){a.style.opacity='';a.style.transition='';a.style.pointerEvents=''}
  const lane=$('catchLane');if(lane){lane.style.opacity='';lane.style.transition='';lane.style.pointerEvents=''}
  const st=$('sceneStatus');if(st){st.classList.remove('g1-feedback-active');st.classList.add('mh-scene-status-suppressed');st.style.top='';st.style.fontSize='';st.style.padding='';st.style.boxShadow='';st.style.transform='';st.style.zIndex='';}
}
function praiseGame(){
  const vi=['🎉 Chính xác!','⭐ Tuyệt lắm!','👏 Giỏi quá!','🌟 Làm tốt lắm!'];
  const en=['🎉 Correct!','⭐ Great job!','👏 Well done!','🌟 Awesome!'];
  const msg=(uiLang()==='vi'?vi:en)[Math.floor(Math.random()*4)];
  const st=$('sceneStatus');if(st){st.classList.remove('mh-scene-status-suppressed');st.classList.add('g1-feedback-active');st.textContent=msg;st.style.top='';st.style.fontSize='';st.style.padding='';st.style.boxShadow='';st.style.transform='';st.style.zIndex=''}
  const a=$('answers');if(a){a.style.transition='opacity .2s ease';a.style.opacity='.22';a.style.pointerEvents='none';a.querySelectorAll('button').forEach(x=>x.disabled=true)}
  const lane=$('catchLane');if(lane&&!lane.hidden){lane.style.opacity='';lane.style.transition='';lane.style.pointerEvents='none';lane.querySelectorAll('button').forEach(x=>x.disabled=true)}
}
function scheduleGameNext(){
  const last=state.index===state.queue.length-1;
  let transitioning=false;
  const go=async()=>{
    if(transitioning)return;transitioning=true;clearTimeout(pendingTimer);pendingTimer=0;
    const next=$('next');if(next)next.disabled=true;
    const st=$('sceneStatus');if(st){st.classList.remove('mh-scene-status-suppressed');st.textContent=last?'Đang về đích…':'Đi tới thử thách tiếp theo…'}
    /* v595: Level Play advances through the world before the next question renders. Practice keeps the compact transition. */
    if(state.mode==='play'&&!last){
      const mover=window.MAIHOC_CHARACTER_MOVEMENT;
      if(mover&&typeof mover.autoTravel==='function'){
        try{await mover.autoTravel({fromIndex:state.index,toIndex:state.index+1,nextQuestion:state.queue[state.index+1]||null,reason:'correct-answer'})}catch(e){console.warn('Auto travel skipped',e)}
      }
    }
    state.index++;persistResume();clearGameFeedback();render();
  };
  $('next').hidden=false;$('next').disabled=false;$('next').textContent=last?'Hoàn thành Level →':'Câu tiếp theo →';$('next').onclick=go;
  /* Keep the praise/reward visible briefly, then travel. */
  pendingTimer=setTimeout(go,1250);
}
function answer(i,b){if(state.done)return;const q=current();state.tries++;const right=i===q.answer;if(state.mode==='test'){state.done=true;if(right)state.testScore++;evidence(q,right);$('answers').querySelectorAll('button').forEach(x=>x.disabled=true);$('sageText').textContent='Đã lưu câu trả lời. Kết quả chỉ hiện sau khi kết thúc.';pendingTimer=setTimeout(()=>{state.index++;render()},450);return}if(right){state.done=true;b.classList.add('correct');window.dispatchEvent(new CustomEvent('maihoc:answercorrect',{detail:{question:q,answerIndex:i,tries:state.tries}}));$('scene').classList.add('celebrate');{const m=$('mouth');if(m)m.textContent='◡'};$('obstacle').classList.add('pass');collectAdventureItem(q);$('sageText').textContent=uiLang()==='vi'?q.explanation_vi:q.explanation_en;evidence(q,true);if((state.mode==='practice'||state.mode==='play')&&window.MAIHOC_primaryRecord){window.MAIHOC_primaryRecord(state.unit,q.skill,state.tries===1)}praiseGame();scheduleGameNext()}else{b.classList.add('wrong');b.disabled=true;window.dispatchEvent(new CustomEvent('maihoc:answerwrong',{detail:{question:q,answerIndex:i,tries:state.tries}}));$('scene').classList.add('bonked');if(useSceneChoices(q))$('obstacle').classList.add('bonk');{const m=$('mouth');if(m)m.textContent='︵'};$('sceneStatus').textContent=KH('💪 Thử lại nhé!','💪 Try again!');$('sceneStatus').classList.add('g1-feedback-active');setTimeout(()=>{$('sceneStatus')?.classList.remove('g1-feedback-active');if(!state.done)$('sceneStatus')?.classList.add('mh-scene-status-suppressed')},2000);if(state.hint===0){showHint()}else{$('sageText').textContent=KH('Em có thể xem thêm gợi ý hoặc thử lại câu hỏi.','You can ask for another hint or try the question again.')}setTimeout(()=>{if(!state.done){$('scene').classList.remove('bonked');$('obstacle').classList.remove('bonk');{const m=$('mouth');if(m)m.textContent='⌣'}}},650)}}

function showHint(){const q=current();if(!q||state.mode==='test')return;if(state.hint>=3){state.mode='knowledge';start();knowledge(q.skill);return}const hint=q.sage[state.hint];if(!hint){$('sageText').textContent='Gợi ý đang được kiểm tra. Em có thể xem bài hướng dẫn hoặc báo lỗi câu hỏi này.';$('moreHint').textContent='Xem bài hướng dẫn';state.hint=3;return}$('sageText').textContent=String(hint).replace(/^[\s·•.;,:-]+/,'').replace(/\s+/g,' ').trim();state.hint++;$('moreHint').hidden=false;$('moreHint').textContent=state.hint>=3?'XEM BÀI HƯỚNG DẪN →':'GỢI Ý TIẾP THEO →'}$('moreHint').onclick=showHint;$('modes').querySelectorAll('button').forEach(b=>b.onclick=(ev)=>{state.mode=b.dataset.mode;if(state.mode==='play'&&ev?.isTrusted)showGameWelcome=false;start()});$('report').onclick=()=>{const q=current();if(!q)return;$('reportItem').textContent=q.id+' · '+gradeLabel()+' · Level '+q.unit+' · '+q.lo+' · '+q.engine+' · v'+q.version;$('reportDialog')?.showModal?.()};if($('submitReport'))$('submitReport').onclick=()=>{const q=current();if(!q)return;const record={question_id:q.id,grade:PRIMARY_GRADE,unit:q.unit,lo:q.lo,engine:q.engine,version:q.version,category:$('category').value,description:$('reportDescription').value,at:new Date().toISOString()};try{const reports=JSON.parse(localStorage.getItem('maihoc.schoolEnglish.reports')||'[]');reports.push(record);localStorage.setItem('maihoc.schoolEnglish.reports',JSON.stringify(reports))}catch{};Promise.resolve(window.MAIHOC?.ensureNonce?.()||window.MAIHOC_CONFIG?.nonce||'').then(nonce=>fetch((window.MAIHOC_CONFIG?.rest||'/wp-json/maihoc/v1/')+'report-content',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json',...(nonce?{'X-WP-Nonce':nonce}:{})},body:JSON.stringify({source_type:'question',source_ref:'grade'+PRIMARY_GRADE+'/level'+q.unit,question_ref:q.id,report_type:record.category,message:record.description,context:record})})).catch(()=>{});$('sageText').textContent='Đã lưu báo cáo trên thiết bị để xem xét. Cảm ơn em!';$('reportDescription').value=''};window.MAIHOC_SCHOOL_ENGLISH_START=start;window.MAIHOC_SCHOOL_ENGLISH_RENDER=render;try{setupPrimaryAdventure();start()}catch(e){console.error('School English game boot failed',e);try{nav();readiness()}catch(_){};const prompt=$('prompt');if(prompt){prompt.hidden=false;prompt.textContent='Game cần tải lại để tiếp tục.'}const answers=$('answers');if(answers){answers.hidden=false;answers.replaceChildren();const retry=document.createElement('button');retry.type='button';retry.textContent='Tải lại game';retry.onclick=()=>location.reload();answers.append(retry)}}
window.addEventListener('maihoc:choose-skill',e=>{
  state.topicFilter=e.detail.skill; state.mode='play'; showGameWelcome=false; start();
});
window.addEventListener('maihoc:primary-progress',e=>{
  const d=e.detail;
  const vals=window.MAIHOC_PRIMARY_SKILLS.map(sk=>window.MAIHOC_primaryProgress['L'+d.level+'|'+sk]).filter(Boolean);
  const overall=vals.length?Math.round(vals.reduce((a,p)=>a+(100*p.correct/Math.max(1,p.done)),0)/vals.length):0;
  const rows=[...document.querySelectorAll('#levelList .level')];
  const row=rows[d.level-1];
  if(row){const pct=row.querySelector('.pct');if(pct){pct.textContent=overall+'%';pct.classList.remove('progress-fly');void pct.offsetWidth;pct.classList.add('progress-fly')}}
});
})();

/* V68 PRIMARY 3-SKILL CHECKPOINT CONTRACT */
window.MAIHOC_PRIMARY_SKILLS=PRIMARY_GRADE<=5?CONTENT_FAMILIES.slice():[];
window.MAIHOC_PRIMARY_BLOCK_SIZE=5;
window.MAIHOC_primaryProgress=window.MAIHOC_primaryProgress||{};
window.MAIHOC_primaryRecord=function(level,skill,correct){
  const k='L'+level+'|'+skill,p=window.MAIHOC_primaryProgress[k]||(window.MAIHOC_primaryProgress[k]={done:0,correct:0});
  p.done++; if(correct)p.correct++;
  try{localStorage.setItem('maihoc_primary_progress',JSON.stringify(window.MAIHOC_primaryProgress))}catch(e){}
  window.dispatchEvent(new CustomEvent('maihoc:primary-progress',{detail:{level,skill,...p,percent:Math.round(100*p.correct/p.done)}}));
  /* v97: checkpoint timing is controlled by the mixed Level Play flow. */
};
window.MAIHOC_showSkillCheckpoint=function(level,skill,p){
  document.querySelector('.maihoc-checkpoint')?.remove();
  const m=document.createElement('div');m.className='maihoc-checkpoint';
  const pct=Math.round(100*p.correct/p.done);
  m.innerHTML='<div class="checkpoint-card"><h2>Tiến trình '+skill+'</h2><div class="checkpoint-score">'+pct+'%</div><p>Em vừa hoàn thành 5 câu. Chọn phần em muốn luyện tiếp.</p><div class="checkpoint-skills"></div></div>';
  const box=m.querySelector('.checkpoint-skills');
  window.MAIHOC_PRIMARY_SKILLS.forEach(sk=>{const b=document.createElement('button');b.textContent=(sk===skill?'Tiếp tục · ':'')+sk;b.onclick=()=>{m.remove();window.dispatchEvent(new CustomEvent('maihoc:choose-skill',{detail:{level,skill:sk}}))};box.append(b)});
  document.body.append(m);
};
window.addEventListener('maihoc:primary-progress',e=>{
  const d=e.detail;
  document.querySelectorAll('[data-level="'+d.level+'"]').forEach(el=>{
    let tag=el.querySelector('.level-progress-fly'); if(!tag){tag=document.createElement('span');tag.className='level-progress-fly';el.append(tag)}
    tag.textContent=d.skill+' '+d.percent+'%'; tag.classList.remove('fly'); void tag.offsetWidth; tag.classList.add('fly');
  });
});


/* v161: level-map lifecycle + global audio stop + separated coin badge */
;(()=>{
  const stopAllAudio=()=>{
    try{ window.speechSynthesis?.cancel(); }catch(e){}
    try{ window.MAIHOC_TTS?.stop?.(); }catch(e){}
    try{ window.MAIHOC_PHONEME_AUDIO?.stop?.(); }catch(e){}
    document.querySelectorAll('audio,video').forEach(m=>{try{m.pause();m.currentTime=0}catch(e){}});
    document.querySelectorAll('[data-audio-toggle="dialogue"]').forEach(b=>b.textContent='▶ Nghe đoạn hội thoại');
    window.dispatchEvent(new CustomEvent('maihoc:stop-audio'));
  };
  window.MAIHOC_STOP_ALL_AUDIO=stopAllAudio;

  const ensureLevelMap=()=>{
    const list=document.getElementById('levelList');
    if(!list) return;
    try{ if(typeof nav==='function') nav(); }catch(e){}
    // If an earlier render failed, build a safe map directly from the loaded bank.
    if(!list.children.length && window.MAIHOC_G6_BANK?.levels){
      const levels=bank.levels;
      levels.forEach(l=>{
        const b=document.createElement('button'); b.className='level'+(l.unit===state?.unit?' active':'');
        b.innerHTML='<span class="level-num">'+String(l.unit).padStart(2,'0')+'</span><span><strong></strong><small></small></span><span class="pct">—</span>';
        b.querySelector('strong').textContent=l.title||('Level '+l.unit);
        b.querySelector('small').textContent='🎮 '+(l.engineName||l.world||'Play');
        b.onclick=()=>{stopAllAudio();state.unit=l.unit;state.mode='play';state.index=0;showGameWelcome=false;history.replaceState(null,'','?level='+l.unit+'&mode=play&start=1');try{save()}catch(e){};try{start()}catch(e){}};
        list.appendChild(b);
      });
    }
    list.querySelectorAll('.level').forEach((b,i)=>b.classList.toggle('active',i+1===Number(state?.unit||1)));
  };
  window.MAIHOC_ENSURE_LEVEL_MAP=ensureLevelMap;

  // Stop old sound before every context transition.
  document.addEventListener('click',e=>{
    const t=e.target.closest('#answers button,#next,#modes button,#levelList .level,.knowledge-tab,.mini-option,[data-skill],[data-mode]');
    if(t) stopAllAudio();
    const mode=t?.closest?.('#modes button')?.dataset?.mode || t?.dataset?.mode;
    if(mode==='play') requestAnimationFrame(()=>requestAnimationFrame(ensureLevelMap));
  },true);
  window.addEventListener('maihoc:questionchange',stopAllAudio);
  window.addEventListener('maihoc:knowledgechange',stopAllAudio);
  window.addEventListener('pagehide',stopAllAudio);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAllAudio()});
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',ensureLevelMap,{once:true}); else ensureLevelMap();
  setTimeout(ensureLevelMap,80);
})();

/* v376 exact Continue: persist the current queue/question before navigation away. */
window.addEventListener('pagehide',()=>{try{persistResume()}catch{}});
