(()=>{'use strict';window.MAIHOC_GAME_SAGE_ADAPTER={open(){document.getElementById('sageOpen')?.click()},notifyWrong(){window.MAIHOC_GAME_EVENTS?.emit('game:wrong',{source:'engine'})}}})();
