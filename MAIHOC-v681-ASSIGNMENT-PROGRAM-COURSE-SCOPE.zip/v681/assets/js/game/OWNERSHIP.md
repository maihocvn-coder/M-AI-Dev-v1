# M-AI School English Game Runtime Ownership (v528)

One behavior = one runtime owner.

- `core/game-registry.js`: game asset/config catalog only (characters/worlds/engines/question-bank availability). No rendering or movement.
- `core/game-config*.js`: resolve Grade + Unit -> IDs/config. No UI.
- `core/game-state.js`, `core/game-events.js`: shared state/events only.
- `core/game-runtime.js`: orchestration only. Connects world/engine/adapters; no question/Sage/holder rendering.
- `world/*`: world/scene/camera/transition only. Never owns character movement, Sage, Answer Holder, or question UI.
- `character/character-runtime.js`: generic character position/motion API.
- `character/character-movement.js`: primary interactive movement/controller/catch behavior. This is the only live replacement for the former `maihoc-g1-character-movement.js`.
- `engines/*`: HOW TO PLAY / engine mechanics only.
- `ui/game-ui-runtime.js`: MainScreen mode mounting, Question/Feedback/Answer Holder visible UI, Report mounting, Sage shell open/close. This is the only live replacement for former `maihoc-game-ux.js`.
- `sage/sage-runtime.js`: Sage teaching/content interaction runtime only. It does not own responsive geometry.
- `adapters/sage-adapter.js`: bridge from game events to Sage; no Sage positioning/UI ownership.
- `adapters/question-adapter.js`: reads question surface only.
- `adapters/answer-adapter.js`: answer event bridge only.
- `adapters/reward-adapter.js`: calls canonical School English reward authority; no second reward system.

Canonical CSS remains exactly `assets/css/maischoolenglish.css`.
Responsive geometry belongs to CSS/MainScreen, not JS.
