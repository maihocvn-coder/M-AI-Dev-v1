/* Compatibility descriptor only; rendering belongs to canonical game-ui-runtime answer carriers. */
(()=>{'use strict';window.MAIHOC_SAMPLE_ANSWER_HOLDER={id:'canonical-answer-carrier',carrierLibrary:'MAIHOC_ANSWER_BADGE',rewardObject:'canonical',renderer:'MAIHOC_ANSWER_BADGE'};})();
