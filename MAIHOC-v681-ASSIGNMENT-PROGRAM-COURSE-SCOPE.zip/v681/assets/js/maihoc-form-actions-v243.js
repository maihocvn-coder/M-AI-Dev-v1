(function(){
  'use strict';
  const dirty=new WeakMap();
  function snapshot(form){ try{return new URLSearchParams(new FormData(form)).toString()}catch(e){return ''} }
  function mark(form){ if(form) dirty.set(form,snapshot(form)); }
  function isDirty(form){ return form && dirty.has(form) && dirty.get(form)!==snapshot(form); }
  function toast(msg,type){
    let box=document.getElementById('mh-global-toast');
    if(!box){box=document.createElement('div');box.id='mh-global-toast';box.setAttribute('role','status');Object.assign(box.style,{position:'fixed',right:'18px',bottom:'18px',zIndex:99999,maxWidth:'420px',padding:'12px 16px',borderRadius:'12px',boxShadow:'0 8px 28px rgba(0,0,0,.18)',fontWeight:'800',background:'#fff',color:'#123b61',border:'1px solid #b9d6e8'});document.body.appendChild(box)}
    box.textContent=msg;box.hidden=false;clearTimeout(box._t);box._t=setTimeout(()=>box.hidden=true,2200);
  }
  async function confirmCancel(){return window.confirm('Discard unsaved changes?')}
  function wireCancel(el){
    if(el.dataset.mhWired)return; el.dataset.mhWired='1';
    el.addEventListener('click',async function(e){
      const modal=el.closest('dialog,.modal,[role="dialog"],.drawer,.mh-modal');
      const form=el.closest('form') || (modal&&modal.querySelector('form'));
      if(form&&isDirty(form) && !(await confirmCancel())){e.preventDefault();return}
      if(modal && (!el.matches('a[href]') || el.getAttribute('href')==='#')){e.preventDefault(); if(typeof modal.close==='function')modal.close(); else {modal.hidden=true;modal.classList.remove('open','active')}}
    });
  }
  function init(root=document){
    root.querySelectorAll('form').forEach(f=>{mark(f);f.addEventListener('input',()=>{});f.addEventListener('submit',()=>setTimeout(()=>mark(f),0))});
    root.querySelectorAll('button,a').forEach(el=>{const t=(el.textContent||'').trim().toLowerCase(); if(/\bcancel\b/.test(t))wireCancel(el)});
  }
  window.MAIHOC_FORM_ACTIONS={init,toast,mark,isDirty};
  document.addEventListener('DOMContentLoaded',()=>init());
})();
