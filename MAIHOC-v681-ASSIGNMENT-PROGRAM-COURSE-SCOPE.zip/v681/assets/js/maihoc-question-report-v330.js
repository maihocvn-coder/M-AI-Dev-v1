(()=>{
'use strict';
const STORE='maihoc.question.reports.v330';
let currentQuestion=null;
const $=id=>document.getElementById(id);
function lang(){
  const raw=(window.MAIHOC_I18N?.getLanguage?.()||localStorage.getItem('maihoc.ui.language')||document.documentElement.lang||'vi').toLowerCase();
  const btn=$('lang');
  if(btn && /EN\s*[→/]|EN\b/.test(btn.textContent||'') && !/VI\s*→\s*EN/.test(btn.textContent||'')) return 'en';
  return raw.startsWith('en')?'en':'vi';
}
const copy={
 vi:{title:'Báo câu hỏi này',intro:'Cho M-AI Học biết câu hỏi này có vấn đề gì.',reason:'Vấn đề',choose:'Chọn một vấn đề',wrong:'Đáp án hoặc lời giải chưa đúng',unclear:'Câu hỏi khó hiểu hoặc thiếu thông tin',audio:'Âm thanh không hoạt động hoặc không đúng',display:'Hình ảnh / hiển thị có lỗi',other:'Khác',detail:'Chi tiết (không bắt buộc)',placeholder:'Mô tả ngắn để đội nội dung kiểm tra nhanh hơn…',cancel:'Hủy',send:'Gửi báo cáo',sent:'Đã gửi báo cáo. Cảm ơn em!',need:'Hãy chọn vấn đề trước khi gửi.'},
 en:{title:'Report this question',intro:'Tell M-AI Học what is wrong with this question.',reason:'Issue',choose:'Choose an issue',wrong:'The answer or explanation is incorrect',unclear:'The question is unclear or missing information',audio:'Audio does not work or is incorrect',display:'Image / display problem',other:'Other',detail:'Details (optional)',placeholder:'Add a short note to help the content team review it faster…',cancel:'Cancel',send:'Send report',sent:'Report sent. Thank you!',need:'Please choose an issue before sending.'}
};
function ensure(){
 if($('mhQuestionReportModal')) return;
 const d=document.createElement('div'); d.id='mhQuestionReportModal'; d.hidden=true;
 d.innerHTML=`<div class="mqr-backdrop" data-mqr-close></div><section class="mqr-dialog" role="dialog" aria-modal="true" aria-labelledby="mqrTitle"><button class="mqr-x" type="button" data-mqr-close aria-label="Close">×</button><h2 id="mqrTitle"></h2><p id="mqrIntro"></p><label class="mqr-label" for="mqrReason" id="mqrReasonLabel"></label><select id="mqrReason"><option value=""></option><option value="wrong"></option><option value="unclear"></option><option value="audio"></option><option value="display"></option><option value="other"></option></select><label class="mqr-label" for="mqrDetail" id="mqrDetailLabel"></label><textarea id="mqrDetail" rows="4"></textarea><div class="mqr-actions"><button type="button" class="mqr-cancel" data-mqr-close></button><button type="button" class="mqr-send" id="mqrSend"></button></div><p class="mqr-status" id="mqrStatus" aria-live="polite"></p></section>`;
 document.body.appendChild(d);
 const s=document.createElement('style'); s.textContent=`#mhQuestionReportModal[hidden]{display:none}#mhQuestionReportModal{position:fixed;inset:0;z-index:100000}.mqr-backdrop{position:absolute;inset:0;background:rgba(15,42,68,.48)}.mqr-dialog{position:relative;width:min(560px,calc(100% - 32px));margin:10vh auto;background:#fff;border-radius:24px;padding:28px;box-shadow:0 22px 70px rgba(0,0,0,.28);color:#173b60}.mqr-x{position:absolute;right:18px;top:14px;border:0;background:transparent;font-size:30px;cursor:pointer}.mqr-dialog h2{margin:0 40px 8px 0}.mqr-label{display:block;font-weight:800;margin:18px 0 7px}.mqr-dialog select,.mqr-dialog textarea{box-sizing:border-box;width:100%;border:1.5px solid #a9d5f3;border-radius:12px;padding:12px;font:inherit;background:#fff}.mqr-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:18px}.mqr-actions button{border-radius:12px;padding:11px 18px;font-weight:800;cursor:pointer}.mqr-cancel{background:#fff;border:1px solid #9fccea;color:#173b60}.mqr-send{background:#177fc5;color:#fff;border:1px solid #177fc5}.mqr-status{font-weight:700;min-height:1.4em;margin:12px 0 0}`; document.head.appendChild(s);
 d.querySelectorAll('[data-mqr-close]').forEach(x=>x.addEventListener('click',close));
 $('mqrSend').addEventListener('click',submit);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!d.hidden)close()});
 }
function paint(){
 const c=copy[lang()];
 $('mqrTitle').textContent=c.title; $('mqrIntro').textContent=c.intro; $('mqrReasonLabel').textContent=c.reason;
 const o=$('mqrReason').options; o[0].textContent=c.choose;o[1].textContent=c.wrong;o[2].textContent=c.unclear;o[3].textContent=c.audio;o[4].textContent=c.display;o[5].textContent=c.other;
 $('mqrDetailLabel').textContent=c.detail;$('mqrDetail').placeholder=c.placeholder;document.querySelector('.mqr-cancel').textContent=c.cancel;$('mqrSend').textContent=c.send;
 }
function open(){
 ensure(); paint(); $('mqrReason').value=''; $('mqrDetail').value=''; $('mqrStatus').textContent=''; $('mhQuestionReportModal').hidden=false; setTimeout(()=>$('mqrReason').focus(),0);
 }
function close(){const m=$('mhQuestionReportModal');if(m)m.hidden=true}
function safeReports(){try{const a=JSON.parse(localStorage.getItem(STORE)||'[]');return Array.isArray(a)?a:[]}catch{return []}}
function qSnapshot(q){if(!q)return null;return {id:q.id||q.questionId||q.qid||null,unit:q.unit||q.level||null,skill:q.skill||null,prompt:q.prompt||q.question||null,options:Array.isArray(q.options)?q.options.slice(0,8):null,answer:Number.isInteger(q.answer)?q.answer:null}}
function submit(){
 const c=copy[lang()], reason=$('mqrReason').value; if(!reason){$('mqrStatus').textContent=c.need;return}
 const params=new URLSearchParams(location.search); const path=location.pathname; const m=path.match(/grade(\d+)/i);
 const report={id:'qr_'+Date.now()+'_'+Math.random().toString(36).slice(2,8),createdAt:new Date().toISOString(),status:'new',grade:m?Number(m[1]):null,level:Number(params.get('level')||params.get('unit')||0)||null,mode:params.get('mode')||null,reason,detail:$('mqrDetail').value.trim(),question:qSnapshot(currentQuestion),page:path+location.search};
 const a=safeReports();a.push(report);localStorage.setItem(STORE,JSON.stringify(a));
 window.dispatchEvent(new CustomEvent('maihoc:questionreported',{detail:report})); $('mqrStatus').textContent=c.sent; setTimeout(close,900);
 }
window.addEventListener('maihoc:questionchange',e=>{currentQuestion=e.detail&&e.detail.question||null});
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('#report,[data-report-question]');if(!b)return;e.preventDefault();e.stopPropagation();open()});
window.MAIHOC_QUESTION_REPORT={open,getReports:safeReports,storageKey:STORE};
})();
