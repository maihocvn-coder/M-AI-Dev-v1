# v246 Extension Architecture

Canonical flow: Define → Validate → Preview → Save Draft → Publish immutable release → Runtime placement → Disable/Rollback.

Rules:
1. New business extensions enter through Extension Studio, not direct page patches.
2. Extension data entities must use `ext.<extensionId>.*`.
3. Drafts never execute. Only published extensions execute.
4. Published releases are immutable snapshots; rollback republishes a prior snapshot.
5. Placement is declarative: audience roles + page paths + slot.
6. Core entities remain owned by MAIHOC_DATA/domain services. Extensions may read core data but must store their own new data in their namespace.
7. Resource types can be registered as extensions without altering existing resource tables.
