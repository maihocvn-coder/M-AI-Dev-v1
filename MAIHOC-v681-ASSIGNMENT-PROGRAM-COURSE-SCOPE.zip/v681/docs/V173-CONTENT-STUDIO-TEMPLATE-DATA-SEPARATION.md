# V173 Content Studio — canonical publishing flow

Template/Shell and Content/Data are separate systems. Content scripts cannot contain or override navigation, header, breadcrumb, CSS, game shell, Sage shell, Wallet UI, or shared components.

## Existing content
Open target → current content is pre-populated → Edit → Copy for AI → paste revised JSON → Validate → WYSIWYG sync → Preview (shared template + draft) → Save Draft → Publish.

## New content
Choose Product/Grade/Unit/Section → create content record → paste data script → Validate → Preview → Save Draft → Publish. No page HTML is generated.

## Supported product targets
M-AI School English, Question Bank, Sage Coaching, My Programs, Sage Games, Worksheets.

## Version safety
Draft does not change published content. Publish increments content version only. Template version and student progress/accounts/coins/inventory are independent. History restores an older version as a new draft, never directly to production.

## Hard gate
Reject scripts containing header/nav/style/script/iframe or code that attempts to manipulate document/window/layout. Identity IDs are locked.
