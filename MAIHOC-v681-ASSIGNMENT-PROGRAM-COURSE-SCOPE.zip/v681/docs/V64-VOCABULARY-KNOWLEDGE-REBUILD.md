# v64 Vocabulary Knowledge Rebuild

- Rebuilt Vocabulary Knowledge for every Unit in Grades 1–12 from the current Unit target list.
- Removed legacy generic vocabulary teaching copy and replaced it with unit-target-driven teaching sections.
- Heading policy: Grades 1–5 Vietnamese headings; Grades 6–12 English headings. Explanations remain Vietnamese.
- Knowledge flow: focus once → teacher explanation → examples → common mistakes → one MCQ Try It → remember.
- Vocabulary words retain TTS playback.
- No isolated phoneme TTS policy changed.
- This patch changes Knowledge presentation/content structure, not the curriculum source verification status.
