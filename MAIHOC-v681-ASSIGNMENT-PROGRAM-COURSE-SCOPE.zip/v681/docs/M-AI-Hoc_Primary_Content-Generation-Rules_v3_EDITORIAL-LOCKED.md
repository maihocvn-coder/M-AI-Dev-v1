# M-AI Học Primary Content Generation Rules v3 — EDITORIAL LOCKED

1. Knowledge is teaching, not a data dump. Every English example must have its actual Vietnamese meaning directly below it. Never prefix translations with “Nghĩa:”.
2. Separate translation from teacher explanation. Teacher notes explain meaning, use, politeness, culture, grammar, pronunciation, or a common mistake.
3. Dialogue is turn-taking. Never ask a child to mimic a question and its answer as one utterance. Split Speaker → Learner turn.
4. Practice must state a real situation. “Read the context” is forbidden unless a visible context exists. Context-choice questions require a visual cue plus a meaningful situation.
5. For Grade 3–5, context questions require meaning + grammar. Grade 4 adds application in a concrete situation. Grade 5 adds naturalness, inference, or communicative appropriateness where the curriculum supports it.
6. Images/visual cues must support the answer without printing the answer.
7. Sentence-pattern teaching sequence: communicative purpose → meaning → complete natural examples → teacher explanation → listen to individual turns → learner response in a scenario.
8. Politeness is taught explicitly when relevant: please, thank you/thanks, excuse me, may/could/would, respectful turn-taking. Explain the pragmatic meaning in child-friendly Vietnamese.
9. Never expose formula notation in TTS or mimic practice. Formulas are teacher explanation only.
10. Proofread as an English teacher/editor: reject unnatural English, mismatched translation, fake context, answer leakage, semantically impossible dialogue, duplicated roles, curriculum leftovers, and age-inappropriate difficulty.
11. Curriculum Truth Table v19 is the source of truth. Vocabulary and Sentence Patterns are already normalized; do not recreate slash-compressed items.
12. Every generated question must pass: curriculum match → one defensible answer → visible/listenable evidence → age-appropriate cognitive demand → natural English → correct Vietnamese support → 3 question-specific Sage hints.
