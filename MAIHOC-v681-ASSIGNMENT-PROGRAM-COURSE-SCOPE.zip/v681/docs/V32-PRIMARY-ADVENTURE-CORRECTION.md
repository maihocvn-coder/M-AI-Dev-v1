# V32 Primary Adventure correction

The v26 design strings such as MAIN ENGINE / CHARACTER / SCENE are authoring specifications, not learner-facing copy. V32 no longer renders those strings as scene captions.

Persistent Grade companions: Grade 1 Frog, Grade 2 Rabbit, Grade 3 Cat, Grade 4 Dog, Grade 5 Bear. Each Grade keeps the same companion across Levels while each Level changes game engine and world. Correct responses add a collectible to the Adventure Pouch stored in localStorage.

Grade cards route directly to Level 1 Play. Level selection also opens Play directly; Knowledge remains available in the left navigation.
