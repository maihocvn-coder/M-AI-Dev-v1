# v26 School English rebuild

Built from the v18 Smart Game Engine contract. Grade 1, Grade 6 and Grade 9 are rebuilt as age-band pilots. Each has a Level map, Knowledge teaching UI, game-world visual, stable LO-tagged Question Bank, and question-specific Sage Bank. Question Bank records carry eligibility for game/practice/test so Teacher Test can use the same content IDs while reserved test items remain hint-free. Before public publication, exact LO wording for every Grade/Level should be verified against the approved curriculum source as required by the v18 specification.
