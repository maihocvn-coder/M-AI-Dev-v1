# V74 Sentence Patterns QA
Reviewed all 92 Grade 1–5 Sentence Patterns lessons.

Required learner flow:
1. Explain in Vietnamese what the pattern is used for.
2. Show the curriculum formula as a non-audio reference only.
3. Give complete natural example sentences with audio.
4. Give complete sentences for listen-and-repeat.
5. Give a complete dialogue question and Record my answer.

QA gate: no spoken example may contain blanks, brackets, slash alternatives, `he/she`, `He/She`, `V(s/es)`, or `+ frequency`-style developer notation.
