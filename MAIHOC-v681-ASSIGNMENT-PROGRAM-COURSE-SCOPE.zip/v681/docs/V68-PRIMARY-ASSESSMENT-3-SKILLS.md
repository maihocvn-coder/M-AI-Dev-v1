# V68 Primary Assessment
Locked schema: Phonics / Vocabulary / Sentence Patterns only.
Each Unit has 20 unique bank items per skill (60 per Unit).
Audio target/transcript is hidden before scoring. Vocabulary audio prompts never expose the target word.
Each practice item contains exactly three question-specific Sage hints.
After each 5 completed questions in a skill, runtime shows a checkpoint popup with progress and lets the learner continue or choose another of the three skills.
Progress is stored independently per Level × skill and emits an event for the Level navigation to update/fly in.
