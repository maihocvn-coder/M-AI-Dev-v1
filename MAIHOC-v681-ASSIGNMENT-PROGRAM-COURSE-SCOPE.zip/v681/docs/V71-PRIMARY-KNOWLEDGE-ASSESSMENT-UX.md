# V71
- Locked Primary schema: Phonics / Vocabulary / Sentence Patterns.
- 30 questions per Unit × skill.
- First game round: 10 mixed questions, randomized across all three skills.
- Difficulty metadata rises across the bank; Grade 1 recognition → Grade 5 application/early inference.
- Knowledge uses tabs and clears the prior assessment prompt.
- Phonics supports embedded verified Sounds American video plus mini discrimination checks.
- Vocabulary includes audio + Vietnamese meaning + sentence examples with audio.
- Sentence Patterns teaches meaning/use, audio models, mimic and recorded dialogue response.
- Adventure Pouch is draggable and docks left/right/bottom; position persists.
