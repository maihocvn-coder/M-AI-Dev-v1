# v86 QA
- Pronunciation video IDs in Grades 1–4: BBC Learning English QxQUapA-2w4 plus Pronunciation with Emma jUHuHVysCxs (British English / Modern RP source); Grade 5 has no phoneme-video auto-embedding for stress/rhythm/intonation.
- Removed learner-facing `Nghĩa:` labels.
- Runtime bank-data questions synchronized from canonical question-bank.json for Grades 1–5.
- Grade 5 Sentence Patterns now include an explicit scenario; Unit 17 story questions include an actual reading passage before the question.
- Grade 5 Unit 17 malformed generated story grammar replaced with coherent story-based items.
