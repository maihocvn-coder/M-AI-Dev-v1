# V176 Canonical Shell Root Fix

Every standalone page has one global shell. The shell owns the M-AI Học brand, master navigation, profile control, and breadcrumb. Page files own only page content.

Root cause fixed: three legacy stylesheets contained `body > header ... { display:none!important }` selectors that could hide the new canonical header even though the shared shell JavaScript had mounted it correctly. All legacy selectors now explicitly exempt `.mh-site-header`, and the canonical shell also carries a critical runtime visibility invariant.

Breadcrumb is no longer inserted into each page's `<main>`. It is a shell element mounted immediately after the canonical header, so game/admin/settings/content pages cannot move it through their own page structure.

Hard gate: standalone page missing shared shell = FAIL; legacy breadcrumb markup = FAIL; CSS capable of hiding `.mh-site-header` = FAIL; unguarded legacy shell renderer = FAIL.
