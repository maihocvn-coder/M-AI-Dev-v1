# v247 Deployment Safety & Version History

## Rule
Code/config deployment history is separate from user/business data. Publish, Disable and Revert must never restore, delete or overwrite protected data.

Protected domains: users, profiles, courses, enrollments, assignments, submissions, grades, calendar, attendance, attendanceConfirmations, wallet, transactions, progress.

## Super Admin flow
Extension Studio -> Preview -> Save Draft -> Publish. Every publish creates an immutable release, checksum, change manifest, previous-release pointer, preflight result and code/config safety snapshot.

Deployment History shows the changed fields and protected-data verification. Revert selects an existing release and restores only that extension's code/config/placement/data-contract definition. It does not restore a database snapshot.

## Guards
- Direct localStorage mutation from pasted extension scripts is rejected.
- Direct MAIHOC_DATA mutation of protected entities is rejected by preflight.
- Extension-owned data must use ext.<extensionId>.*.
- Protected-data fingerprints are checked before/after publish and revert. Unexpected mutation blocks the operation and restores the previous extension code/config.
- Historical releases are re-run through current preflight before revert.

## Future production backend
When localStorage is replaced with a server database, preserve this contract: immutable deployment ledger; append/forward-safe DB migrations; backups independent of code rollback; protected user data never included in normal code revert.
