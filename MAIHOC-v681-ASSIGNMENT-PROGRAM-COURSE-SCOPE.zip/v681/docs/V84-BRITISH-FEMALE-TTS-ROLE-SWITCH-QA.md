# v84 QA

- Default TTS locale: en-GB.
- Default voice preference: female British voice when no explicit Admin voice is saved.
- Explicit Admin-selected en-GB voice still overrides the default preference.
- Role switcher derives the checked/current role from the page URL and synchronises session.activeRole.
- Admin accounts always retain Student / Teacher / Parent / Admin options and Admin routes to admin/portal/home.html.
- Switching back to Admin therefore restores the Admin Portal rather than leaving the selector stale.
