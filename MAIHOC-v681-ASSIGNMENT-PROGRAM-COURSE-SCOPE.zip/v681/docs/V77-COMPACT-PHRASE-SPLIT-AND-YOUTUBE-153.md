# v77 QA
- Compact curriculum entries with a shared action prefix are expanded into independent phrases.
- Example: play badminton/basketball/chess/football/table tennis/volleyball becomes six phrases.
- Runtime Knowledge renderer also expands this notation defensively.
- YouTube iframe uses youtube.com/embed with dynamic origin=location.origin for localhost/server origins.
- Do not open play.html as file://; run through http://localhost or http://127.0.0.1.
