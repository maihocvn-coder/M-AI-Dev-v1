# V75 YouTube phonics embed QA
Every Grade 1–5 Phonics Knowledge lesson now receives a direct YouTube iframe source.
No learner-facing 'video will be embedded when verified' placeholder remains.

Video routing:
- Exact verified Sounds American videos are used where mapped (/w/, /b/, /t/, /k/, /d/, /æ/).
- Other sound/letter targets use the Sounds American pronunciation collection.
- Word-stress targets use a word-stress tutorial.
- Sentence-stress/rhythm targets use a sentence stress/rhythm tutorial.
- Intonation targets use an intonation tutorial.
