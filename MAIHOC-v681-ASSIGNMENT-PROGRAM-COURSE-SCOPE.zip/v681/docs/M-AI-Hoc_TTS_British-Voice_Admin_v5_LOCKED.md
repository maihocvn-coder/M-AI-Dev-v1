# M-AI Học TTS British Voice — LOCKED

- English learner-facing TTS must use `en-GB`.
- Never fall back to `en-US`.
- Admin → British TTS Voice lists only voices whose BCP-47 language begins `en-GB`.
- Admin may select voice, rate, and pitch and preview it.
- Persist the selected voice name/URI plus rate/pitch.
- On a learner device, use the exact saved en-GB voice when available; otherwise choose another installed en-GB voice.
- If no en-GB voice exists, keep utterance language `en-GB`; do not deliberately select an American voice.
- Phoneme teaching video/audio remains British-English aligned independently of TTS selection.
