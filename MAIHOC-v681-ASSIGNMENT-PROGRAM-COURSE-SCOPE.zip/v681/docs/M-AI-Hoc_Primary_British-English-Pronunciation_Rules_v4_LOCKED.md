# M-AI Học Primary British English Pronunciation Rules v4 — LOCKED

- Grades 1–5 pronunciation model: British English.
- Browser TTS requests `en-GB`; prefer an installed `en-GB` voice, with generic English only as technical fallback.
- An explicit IPA phoneme must have a verified British-English pronunciation video that teaches that exact phoneme.
- Primary verified source: BBC Learning English, “The complete guide to English Pronunciation — all 44 sounds”, using the exact timestamp for the target phoneme.
- `/i/` (happy vowel) uses a separately verified Modern RP British-English vowel lesson because the BBC legacy 44-sound video does not present `/i/` as a standalone segment.
- Never attach a phoneme video to pseudo-targets such as `weather sound focus`, topic-word lists, word stress, sentence stress, rhythm or intonation.
- Stress/rhythm/intonation may receive media only when that media explicitly teaches that feature and has been separately verified.
- If a lesson has no valid media object, render no video heading, video instruction or placeholder.
- Never use Sounds American as the default pronunciation source for this British-English curriculum.
- Example words, minimal pairs, Sage coaching and audio should be checked for compatibility with the British target.
