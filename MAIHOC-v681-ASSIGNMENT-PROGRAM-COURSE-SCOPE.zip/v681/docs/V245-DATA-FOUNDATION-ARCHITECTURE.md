# M-AI Học v245 — Data Foundation & Extension Architecture

## Frozen foundation rule
Business pages must not become owners of persistent business data. New features call domain services/repositories; repositories persist through `MAIHOC_DATA`. Direct browser storage is reserved for UI-only preferences/cache until moved into a later backend adapter.

## Canonical core
`assets/js/maihoc-data-core-v245.js` is the persistence boundary for canonical business entities currently consolidated: courses, assignments, submissions, tests, worksheets, calendar/session data, pay rates, attendance, attendance confirmations, and attendance settings.

The core provides: schema/core version metadata; migration registry; canonical entity definitions; read/write/list/object/get/upsert/archive/remove/transaction operations; stable createdAt/updatedAt behavior for repository upserts; change events; compatibility mirrors for assignment/submission legacy keys.

## Stable entity chain
User / Role / Organization -> Course/Class -> Enrollment -> Assignment/Resource -> Session -> Attendance -> Submission -> Grade -> Wallet/Transaction -> Subscription.

v245 establishes the persistence/process boundary without inventing missing backend tables. Future backend storage (API/SQL/Firebase/etc.) should replace the adapter under the repositories, not page behavior.

## Extension contract
1. New UI calls a domain service, never a storage key.
2. New domain service uses `MAIHOC_DATA` (or the future server repository adapter).
3. New persistent entity gets a canonical definition, stable ID, timestamps, ownership/scope, status lifecycle, validation, and migration entry before release.
4. Cross-domain behavior uses events/service calls, not duplicated writes.
5. Delete/archive behavior must be explicit. Historical academic/financial records default to archive/soft-delete.
6. Compatibility aliases are temporary adapters and must never become a second source of truth.

## Consolidated in v245
- Assignment/submission service now persists through Data Core while legacy keys remain mirrored for compatibility.
- Calendar/session persistence and pay-rate reads route through Data Core.
- Session/Attendance canonical operations from v244 now route attendance/settings/confirmation persistence through Data Core.
- Teacher common Courses/Assignments/Tests/Worksheets access routes through Data Core when available.
- All pages that consume these consolidated services load Data Core first.

## Not claimed as fully migrated
The package still contains browser storage for UI preferences, demo/auth state, avatars, game progress, content tooling, wallet and other modules. v245 does not blindly rewrite these because each needs domain-specific lifecycle/ownership rules. They are now governed by the extension contract: do not add new business-data direct writes; migrate each domain behind a repository when it is next changed.
