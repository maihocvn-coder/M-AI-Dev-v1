# v65 Grade-Differentiated Question Bank QA

v65 rebuilds the question-bank complexity by grade while preserving the v64 Knowledge architecture and existing game shell.

## Research calibration
Representative Global Success samples for primary, lower-secondary, secondary and upper-secondary were reviewed before defining the progression. The product content remains independently authored; source exercises/text are not copied into the bank.

Observed progression used for design: primary = listen/look/point/say/match/short read-write; G6-7 = contextual vocabulary, grammar manipulation, short skill texts; G8-9 = phrases/collocations, multi-step reading, contextual grammar, ~100-word writing by G9; G10-12 = lexical chunks, word forms/paraphrase, longer texts, inference/evidence, extended speaking/writing.

## v65 rules
- G1-2: concrete word/short-phrase recognition, short audio/text, minimal output.
- G3-5: sentence-level context, short passages, simple sequencing and production.
- G6-7: vocabulary learned as phrases/collocations; contextual questions; reading 105-130 words.
- G8-9: collocation + thesaurus/paraphrase awareness; reading 165-195 words; inference/evidence begins to matter more.
- G10-12: lexical chunks, synonym/paraphrase strategy, evidence/claim/inference, extended speaking and writing; reading 230/270/310 words.
- Reading and listening use multiple original passage/script variants per Unit and are not copied from Global Success.
- Grammar and pronunciation content mappings from v64 are preserved rather than overwritten by a generic generator.
- Sage remains question/skill aware and gives 3-step coaching.

## Automated QA
- 15,344 bank items retained across Grade 1-12.
- Every MCQ has valid options and answer index.
- Every bank item has >=3 Sage coaching steps.
- Reading passage word targets: G1 20, G2 30, G3 45, G4 60, G5 80, G6 105, G7 130, G8 165, G9 195, G10 230, G11 270, G12 310.
- JS syntax check passes for all 12 grade game/lesson/bank runtime files.

## Production gate
Automated QA does not replace curriculum/editorial review. Unit content, especially pronunciation/phoneme assets, remains subject to source verification and human-style content review before production publish.
