# v63 Knowledge + Journey + Sage QA

## Runtime changes
- Initial Level Play now samples one representative question from each enabled skill before showing the Journey/Skill Progress choice.
- Progress/Journey no longer appears after question 1.
- After the diagnostic skill sweep, selecting a skill starts focused Practice for that skill.

## Knowledge changes
- One focus statement only.
- Teacher-style Vietnamese explanation is split into meaningful sections by skill.
- Grammar explicitly teaches meaning, form and use (with rule-specific sections where the curriculum target identifies the grammar point).
- Examples follow the explanation.
- One MCQ Check Understanding follows the teaching section.
- Vocabulary/listening retain TTS hooks; isolated phoneme playback remains gated by verified audio policy.

## Sage changes
- Rebuilt coaching pattern by skill around TEACH → NOTICE/CHECK → CONNECT/GUIDE → RETRY ORIGINAL.
- Listening points learner to target/evidence in audio; Reading to text evidence; Grammar to exact rule/form; Vocabulary to meaning/context/collocation; Pronunciation to the current sound target; Speaking/Writing use production/revision scaffolds.

## QA executed
- 12 Grade game runtimes pass Node syntax check.
- 1,106 Knowledge lessons contain structured teaching sections.
- All non-open-response Knowledge lessons contain an MCQ understanding check.
- All question-bank items retain >=3 Sage coaching steps.
- Existing v62 bank count QA still passes: 15,344 items, 0 structural errors.
- ZIP integrity checked after packaging.

## Production caution
This QA validates structure, runtime hooks and generated alignment to the curriculum target fields currently stored in the package. It does not claim that all 1,106 lesson curriculum target fields have been independently source-verified against every current textbook/teacher-book edition. Those source facts must remain review-gated before production publication, especially pronunciation/phoneme assets.
