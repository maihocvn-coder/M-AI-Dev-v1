# V69 Knowledge clean student view
Removed all meta/instructional blocks such as “Em cần học gì?”, “Giáo viên giải thích”, and numbered teaching directions.
Phonics: target/audio or verified video + example words + simple sound/rhythm discrimination.
Vocabulary: curriculum list + enrichment list, each with audio and Vietnamese meaning, then a few examples.
Sentence Patterns: pattern + audio examples; Grades 4–5 retain record/replay.
Question bank/progress flow from V68 is preserved.
