# v33 Grade 1 Letter Catch fix
- Grade 6 is UX shell only; Grade 1 content is independent.
- Level 1: In the school playground; B/b /b/; ball, bike, book; Hi/Bye pattern.
- Main engine: Letter Catch. Targets float in scene and can be caught directly.
- Correct target animates toward persistent Adventure Pouch. Pouch can collapse/expand.
- Developer-only scene specification is never learner-facing.
