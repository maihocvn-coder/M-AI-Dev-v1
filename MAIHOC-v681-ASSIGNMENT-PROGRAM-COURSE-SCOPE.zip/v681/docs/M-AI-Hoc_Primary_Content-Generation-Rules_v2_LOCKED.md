# M-AI Học Primary Content Generation Rules v2 — LOCKED

Source of truth: Curriculum Truth Table v19 Primary Normalized.

1. Curriculum first. Never invent or merge curriculum targets. Vocabulary and Sentence Patterns are read from the normalized table.
2. Every learner-facing English example must have its actual Vietnamese meaning directly underneath. Never put “dùng trong câu mẫu”, “nghe và nhại lại”, or another instruction in the translation slot.
3. Teacher explanation is a separate field. M-AI Học teaches why/how a form is used, not merely displays it.
4. Politeness and social language are explicitly taught when relevant: please, thank you/thanks, May I, Could you, Would you like. Explain the pragmatic Vietnamese equivalent (ạ, làm ơn, vâng ạ, cảm ơn) without claiming word-for-word equivalence.
5. Formula notation is reference only. Never send blanks, he/she, V(s/es), V-ing, +frequency, slash alternatives, or developer notation to TTS or Listen-and-repeat.
6. Listen-and-repeat always uses complete, natural utterances.
7. Vocabulary examples must be semantically natural: no “This is a jam/juice”, no article errors, no category-label pseudo-words.
8. Grade progression: G1 recognition and one short utterance; G2 short meaning + polite exchanges; G3 short context and complete responses; G4 contextual application with 4-option distractors and multi-clue reading/listening; G5 application, pragmatic choice, grammar+meaning, short multi-sentence context/inference.
9. Question bank: 30 per skill per unit. Difficulty bands 1–10 foundation, 11–20 application, 21–30 transfer. Older grades must not be copies of younger-grade recognition questions.
10. Sage: exactly 3 useful hints tied to the question; hint 1 identifies evidence, hint 2 applies the rule/meaning, hint 3 supports transfer.
11. QA gates: no fake translations; no slash-compressed lexical items; no formula notation in spoken examples; no phoneme questions using unrelated place names; every answer must have one defensible correct option.
