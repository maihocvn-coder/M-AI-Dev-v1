# Phoneme audio v85

Isolated IPA targets use dedicated phonetic-sample audio and are never spoken by browser TTS. The runtime maps British/RP curriculum phonemes to Wikimedia Commons phonetic sample files through `Special:Redirect/file/`. Files are streamed rather than redistributed in this package. Verify each Commons file description/license before any future decision to bundle copies locally. Word/phrase/sentence audio continues through the Admin-selected `en-GB` TTS voice. Pronunciation videos remain a separate teaching layer.
