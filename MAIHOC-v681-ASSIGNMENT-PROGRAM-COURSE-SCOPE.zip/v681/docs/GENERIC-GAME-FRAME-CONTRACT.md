# M-AI School English — Generic Game Frame Contract

Grade 1 is the reference implementation for the shared School English game UX.

## Shared and inherited by Grades 1–12
- Page/navigation/breadcrumb grid
- Mode navigation, Level Map, Readiness, footer
- MainScreen geometry and viewport-fit behavior
- Question overlay slot
- Answer-holder lane/safe area
- Character safe area
- Controller anchor
- Sage layer
- Liquid/responsive behavior

## Replaceable per Grade / Unit
- Curriculum/question content (database)
- Game World / Scene
- Engine
- Character artwork
- Answer-holder visual/skin

## Direction of inheritance
Grade 1 reference -> shared frame -> Grades 2–12.
Generic Grades 2–12 CSS/JS must never override or redesign Grade 1.
