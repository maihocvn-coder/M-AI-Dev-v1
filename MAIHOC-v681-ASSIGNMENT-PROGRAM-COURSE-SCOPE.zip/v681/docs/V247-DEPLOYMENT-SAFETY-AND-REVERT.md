# v247 Deployment Safety & Revert

## Invariant
Code/config deployment history is separate from user/business data. A revert MUST NOT restore, delete, or overwrite users, profiles, enrollments, assignments, submissions, grades, progress, attendance, wallet balances, or transaction history.

## Publish flow
Draft -> Preflight -> code/config safety snapshot -> immutable release -> change manifest -> publish -> deployment ledger.

## Revert flow
Select historical release -> preflight historical code -> safety snapshot current code/config -> replace extension code/config only -> log revert. Extension-owned data is preserved. Protected core data is never part of a deployment snapshot.

## Guards
Extension scripts cannot directly call localStorage write/remove/clear. Extension scripts cannot directly mutate protected MAIHOC_DATA entities. New extension data uses ext.<extensionId>.*.

## History record
Stores action, extension ID, version/release, timestamp, field-level before/after manifest, checksum, preflight result, safety snapshot ID, and protectedDataUntouched flag.
