# M-AI Học v282 — Unified Roles, Human Content Governance & Role Guides

## Core rules
1. Administrative authority: Super Admin > Management Admin > Curriculum Admin > Organizational Admin.
2. Personal/workspace roles such as Teacher, Parent, Student and Curriculum Designer do not get blindly inherited as active roles.
3. **Manage down; switch sideways.** Admins manage lower-level data in admin context. Switch Role is used only when the person actually performs another personal role.
4. One canonical Admin Home design. Higher admin levels see more management sections; unavailable sections are removed, not disabled clutter.
5. One active role = one Home context = one Guide context.
6. New content begins Draft. Existing content migrates as Legacy Published.
7. AI creates → human review → Curriculum approval → Management release → Published.
8. Approval belongs to exact revision. Editing approved content creates a new Draft revision and invalidates the new revision's seal.
9. M-AI Human Reviewed seal = check mark + M-AI mark on the exact approved revision.
10. Removal is non-destructive; history is retained. Super Admin restoration creates a new revision.
11. Management Admin can perform Curriculum Admin/Designer work and can see workforce analytics, time, rates and payroll subject to permission.
12. Role + Permission + Scope + Assignment drives effective access.

## Content states
Draft → In Review → Needs Additional Review / Changes Requested → Approved → Release Review / Scheduled → Published → Unpublished / Archived / Removed.

## Role Guide
Every role has only its own Guide while active. Guide provides Getting Started, function instructions and contextual workflows. Switching role switches Guide.
