# M-AI Học: one platform, four workspaces

## What the benchmark suggests

- [Khan Academy teacher reporting](https://support.khanacademy.org/hc/en-us/articles/360031129891-What-reporting-options-are-available-on-Khan-Academy-for-teachers-to-track-student-performance) groups a class's assignment scores, activity and mastery. M-AI Học should keep class/assignment grades distinct from Grade game skill mastery, but offer a combined learner view.
- [Khan Academy's parent dashboard](https://support.khanacademy.org/hc/en-us/articles/360039664491-What-can-I-do-from-the-Khan-Academy-Parent-Dashboard) gives a parent linked child activity, assignments and scores. M-AI Học now provides a linked-child summary endpoint; the consent link determines which child data a parent may fetch.
- [Google Classroom guardian summaries](https://support.google.com/edu/classroom/answer/6386354?hl=en) highlight missing/upcoming work and class activity. A future digest should be opt-in and driven by real assignments; no invented grade information.
- [Moodle Question banks](https://docs.moodle.org/502/en/Question_banks) separate draft and ready questions, versions, search and reuse. M-AI Học now stores Admin question revisions separately from the shipped Grade bank. Published revisions load into Grade 6 game; drafts do not.
- [ClassDojo family/school communication](https://help.classdojo.com/hc/en-us/articles/4413208601357-What-are-ClassDojo-s-Collaboration-Features) suggests later class announcements and moderated family messaging. These are listed as later backend work, not emulated as live messaging in this package.

## Role paths in this build

| Role | Entry | Working flows in this package | Additional backend work |
| --- | --- | --- | --- |
| Student | `student/my-space/home.html` | last game and program, favorites, Grade 6 game, actual local mastery, character/theme, schedule tasks, family invite QR | account sync, purchase/checkout, live class access, broader Grades |
| Parent | `parent/my-family/home.html` | redeem/remove link; linked-child mastery, assignments and grades when present in WordPress | digest/alerts, payment history, parent-set goals |
| Teacher | `teacher/my-teaching/home.html` | class creation/list, existing gradebook/content-bank routes, class count | full roster enrollment, rich assignment builder, responses report, attendance |
| Admin | `admin/portal/home.html` | report inbox/status, click through to question, Grade 6 question/Sage draft-publish, page copy rich editor draft-publish, default theme/icon | approval queues for other Grades, media uploads, finance/role admin |

`maihoc-content.php` uses WordPress for authentication. WordPress authentication and role permissions are required for protected REST actions. The Admin page editor changes safe text blocks, not PHP, JavaScript, interactive form structure, or the engine. Question updates carry immutable IDs and version checks. Dynamic records need a real WordPress install, account roles and REST nonce. This package does not include a payment processor or communication service.

## Replace only one Grade later

Stable public route: `student/my-school-english/grade7/home.html`. Platform links must target this route, not a file internal to the Grade module. The module ZIP has `module.json` plus `grade7/` only. It references the shared shell/theme with relative URLs. Public page filenames and persistent question IDs/storage keys stay stable across replacements, or the new module supplies a migration.

From the extracted project directory:

```bash
python3 tools/grade_module.py pack --grade 7 --output Grade7-only.zip
python3 tools/grade_module.py install --archive Grade7-only.zip --dry-run
python3 tools/grade_module.py install --archive Grade7-only.zip
```

The installer checks module type, Grade number, stable route, platform API version, SHA-256 for every file, asset dependencies and path traversal. It stages the replacement, backs up the previous Grade and leaves every other directory untouched. Never copy Grade 7 files into `assets/`, `student/my-space/` or `grade6/`. Grade 6's current game is a working prototype; all other Grades have legacy content and are future module candidates.

After install, run local link checks and verify Grade selector → Grade home, breadcrumbs, favorite link, theme and return home. Changing a module is independent of changing the universal shell, but a module that needs a new shared API version must be coordinated with a platform update.

## Content editing contract

The shared `maihoc-page-copy.js` identifies editable headings/paragraphs. Admin's editor saves small safe markup in WordPress options with revision entries; drafts are private to Admin save and published copy appears after reload. New pages should give durable visible content order and avoid moving blocks that already have overrides. The Grade ZIP installer cannot overwrite these WordPress records. Source file edits remain possible in VS Code for layout, graphics, game engine and code changes.
