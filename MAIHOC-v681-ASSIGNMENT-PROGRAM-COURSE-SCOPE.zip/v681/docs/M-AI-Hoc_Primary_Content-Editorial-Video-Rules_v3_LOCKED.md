# M-AI Học Primary Content Editorial + Video Rules v3 — LOCKED

## YouTube / pronunciation media
1. Never add a YouTube video merely because the database skill is named `Phonics`.
2. Embed only when the curriculum lesson has an explicit, teachable phoneme/letter-sound target AND the exact video has been verified to teach that same sound.
3. No generic pronunciation video as a fallback. A missing verified video is better than a mismatched video.
4. Word stress, sentence stress, rhythm, intonation, topic-word pronunciation, or placeholder `sound focus` rows do not automatically receive a phoneme YouTube video.
5. If a video is removed, remove every learner-facing heading/instruction that refers to watching that video. Never show an empty video section.
6. Practice must match the actual pronunciation target: phoneme -> real-word sound discrimination; stress -> stress listening; rhythm/intonation -> complete utterances. Never fabricate a phoneme from unrelated vocabulary.

## Editorial gate
- Read every learner-facing block as an English teacher/editor, not as a template filler.
- Reject nonwords, unnatural example sentences, English-Vietnamese hybrid translations, fake context, formula text sent to TTS, and instructions for controls/media that are absent.
- Vietnamese directly below English is the natural Vietnamese meaning of that exact English line. Teaching explanation belongs in a separate teacher-note field.
- Every question must provide the evidence its instruction claims exists (image/context/audio/dialogue).
- Grade difficulty must increase progressively; Grades 4–5 require context, meaning, grammar, and communicative appropriateness rather than simple word recognition alone.
