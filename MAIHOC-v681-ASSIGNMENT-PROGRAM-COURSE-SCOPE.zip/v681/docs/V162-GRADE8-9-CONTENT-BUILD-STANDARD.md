# M-AI Học Grade 8–9 Content Build Standard

Truth Table → Global Success difficulty/activity review → original Knowledge → QA → Question Bank → QA/lock → 3-step Sage → runtime.

Global Success is used only to calibrate curriculum coverage, age-appropriate difficulty, skill demand and activity type. Do not copy textbook passages, dialogues, questions, distinctive examples or answer choices.

Each unit contains Vocabulary, Pronunciation, Grammar, Listening, Reading, Speaking and Writing. Questions bind to grade/unit/skill/LO/contentId.
