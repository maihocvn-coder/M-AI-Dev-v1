# v511 Shared Geometry Authority Audit

Root causes found:
1. Character had multiple competing `#cat` bottom/size rules, while the injected SVG artwork had no explicit width/height contract. Moving the anchor did not guarantee the visible SVG cleared the controller.
2. Learn/Test had multiple legacy `.interaction` rules. Knowledge is rendered inside `#stimulus.lesson-container`, not directly in `.mse-main-content-document`, so earlier direct-child fill rules did not own the real white surface.
3. `game.js` resets `#cat.className = 'cat'` during question renders. Direction therefore cannot rely only on a transient class; the canonical movement script persists `data-facing` and repaints the artwork.

v511 establishes one final shared authority at the end of `maischoolenglish.css`: explicit character artwork geometry + separate HUD band; and a full-height `#interaction -> #stimulus.lesson-container -> .knowledge-body` flex chain. This applies through the shared CSS rather than per-page CSS.
