# V538 — Compact Answer Payload

- Keeps the canonical vertical fish holder: carrier → tether → answer payload.
- Keeps all three answer holders on one horizontal row.
- Shrinks the lower payload to fit its actual reward icon + answer text + audio instead of filling the holder column.
- Uses `width:max-content` with a liquid MainScreen-relative maximum.
- Reduces payload height, padding, gap, reward icon, text, and audio control progressively.
- Does not change question data, engine selection, character/controller ownership, reward logic, or Sage.
