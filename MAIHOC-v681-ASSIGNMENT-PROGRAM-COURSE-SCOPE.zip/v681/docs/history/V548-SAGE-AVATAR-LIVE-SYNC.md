# V548 — Sage avatar live sync

- Baseline: v547 Grade 1 single-authority rebuild.
- Fixed Sage avatar refresh after saving a different Sage in Account Settings.
- Sage runtime now refreshes on `maihoc:characters`, storage, popup message, window focus, and pageshow.
- Settings save now notifies the opener directly and via postMessage; file:// null-origin preview is handled safely for local testing.
- No curriculum, question-bank, lesson-data, mode, or content-rendering changes.
