# V540 — Fish payload internal liquid
- Exactly three fish remain in one horizontal row at every MainScreen width.
- Wide/medium: compact payload is icon + text + audio horizontally.
- Compact/narrow/phone: only each fish payload rotates vertically to icon / text / audio.
- Payload stays content-sized and does not stretch to its one-third column.
- Carrier fish and tether are unchanged.
