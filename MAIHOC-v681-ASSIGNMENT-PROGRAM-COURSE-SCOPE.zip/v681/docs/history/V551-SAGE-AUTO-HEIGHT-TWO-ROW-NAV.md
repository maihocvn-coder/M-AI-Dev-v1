# v551 — Sage auto-height + two-row navigation

- Removed the expanded Sage panel's forced tall height. The card now follows rendered content with a maximum height and scroll only when content actually needs it.
- Changed Sage text navigation to an intentional 2 x 2 grid: Hint / Ask More, Quick Quiz / Play with Sage.
- Kept avatar and close control in independent header columns.
- No curriculum, question-bank, Sage coaching content, mode/controller, or data-pipeline changes.
