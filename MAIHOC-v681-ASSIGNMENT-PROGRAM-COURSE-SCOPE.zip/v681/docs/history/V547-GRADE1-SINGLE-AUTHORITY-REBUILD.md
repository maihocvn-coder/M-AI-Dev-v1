# V547 — Grade 1 Single-Authority Rebuild

Baseline: user-provided v541.

## Rebuilt architecture
- Added `assets/js/game/core/school-english-data.js` as the only data adapter between legacy Grade data and the controller.
- Grade 1 content remains unchanged in `bank-data.js`, `lesson-data.js`, and `sage-knowledge-data.js`.
- `school-english-controller.js` remains the sole owner of mode/state/content rendering.
- `game-ui-runtime.js` no longer binds Learn/Play/Test clicks and no longer writes `data-mse-mode`.
- UI runtime observes canonical controller mode and performs presentation-only synchronization after controller state/render work.

## Authority contract
Data -> Data Adapter -> School English Controller -> DOM -> Presentation runtime.
Responsive/presentation code must not select lessons/questions or mutate controller mode.

## Validation
- `node --check` passed for data adapter, controller, and UI runtime.
- Static audit confirms `bindModes()` and `applyMode()` ownership were removed from shared UI runtime.
- Browser-level Chromium verification could not complete in this container because headless Chromium hung before producing DOM; no browser-render claim is made.
