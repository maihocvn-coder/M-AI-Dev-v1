# V541 — Overlap Authority Consolidation

- Audited Grade 1, shared JS, and canonical School English CSS.
- Removed legacy `@media(max-width:800px){.cat{width:100px;height:105px}}` character sizing authority that caused the character to grow at the 800px viewport boundary.
- Consolidated Sage positioning to one MainScreen anchor for Learn and Play: bottom-right, sized/offset with MainScreen container units. Removed the compact Play rule that moved Sage to the left and removed the Learn center-bottom authority.
- Removed the old Answer Holder CSS authority plus v534–v540 stacked override chain. V541 is the sole base fish-holder authority; only its intentional compact internal-payload override remains.
- Removed `renderLetterCatch()` from the Grade 1 shared School English controller. It was clearing/hiding `#catchLane` after `game-ui-runtime.js` rendered the canonical fish holders on `maihoc:questionchange`.
- Grade 1 holder DOM ownership is now `game-ui-runtime.js`; Grade 1 controller no longer renders/hides the holder.
- Character movement/sample duplication remains a separate architecture concern for Grades 2–12; Grade 1 does not load `sample-cat.js`. No new duplicate runtime was added in this release.
