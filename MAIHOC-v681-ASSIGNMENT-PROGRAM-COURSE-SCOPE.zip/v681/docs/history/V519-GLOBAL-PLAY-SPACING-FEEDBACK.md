# v519 — Global Play spacing + feedback visibility

Baseline: v518 Sample Kit.

Scope is shared Play geometry only:
- Restores the existing `g1-feedback-active` runtime feedback toast that legacy suppression CSS was hiding.
- Separates Question and Answer Holder bands so answers no longer crowd the question card.
- Raises the character above the centered controller so the controller no longer covers the character.
- Applies to Grade 1 reference and Grades 2–12 while using the G1 sample kit through the shared `mse-sample-g1` contract.
- Keeps world art, answer-holder composition, question data, reward logic, Sage logic, navigation and engine behavior unchanged.
