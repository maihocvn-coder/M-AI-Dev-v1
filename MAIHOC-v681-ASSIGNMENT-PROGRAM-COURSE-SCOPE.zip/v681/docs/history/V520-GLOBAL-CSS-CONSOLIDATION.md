# v520 — Global CSS consolidation

Baseline: v519.

Scope: consolidate the shared M-AI School English MainScreen/Game World CSS without redesigning Grade 1 or changing runtime/content logic.

Changes:
- Removed one exact duplicated legacy game-world CSS block (406 lines).
- Removed historical v503/v504/v505 geometry override layers.
- Removed the older duplicate shared MainScreen geometry authority.
- Removed the normal-play `#sceneStatus:not(.mh-game-intro-toast){display:none!important}` suppression rule.
- Removed obsolete generic sceneStatus visual rules that competed with explicit intro/feedback states.
- Replaced v516/v517/v519 additive geometry patches with one canonical shared MainScreen authority.
- Preserved the compact Journey rail behavior as its own canonical responsibility.
- Consolidated Answer Holder, collectible object icon, feedback, character/HUD separation, Sage narrow placement, Learn/Test fill behavior and liquid narrow reflow.
- Grade 1 remains the visual reference; Grades 2–12 sample class inherits the same shared authority.

QA:
- CSS brace balance: PASS.
- `node --check` Grade 1–12 engine/game.js: PASS.
- `node --check assets/js/maihoc-game-ux.js`: PASS.
- No runtime/content/HTML/JS files changed from v519.
