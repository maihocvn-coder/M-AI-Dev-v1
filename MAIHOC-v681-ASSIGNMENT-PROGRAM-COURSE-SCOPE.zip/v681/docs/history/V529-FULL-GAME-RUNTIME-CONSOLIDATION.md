# V529 — Full Game Runtime Consolidation

Goal: one physical implementation per active School English game behavior; no legacy duplicate runtime copies.

## Canonical ownership
- Core/config/state/events/runtime: `assets/js/game/core/`
- Game UI / MainScreen / question projection / feedback / answer-holder projection / report shell: `assets/js/game/ui/game-ui-runtime.js`
- Character rendering/movement: `assets/js/game/character/`
- World: `assets/js/game/world/`
- Engines: `assets/js/game/engines/`
- Sage runtime: `assets/js/game/sage/sage-runtime.js`
- Question/answer/reward/Sage bridges: `assets/js/game/adapters/`
- CSS: `assets/css/maischoolenglish.css`

## Deleted duplicate physical trees/files
- `repository/js/`
- `repository/css/`
- `repository/student/`
- legacy runtime files previously replaced by canonical game modules (none remain physically).

## Reference cleanup
Active QA/code references to the old runtime filenames were changed to canonical module paths. Historical markdown under `docs/history/` remains historical documentation only and is not runtime authority.

## Verification
- one `maischoolenglish.css` physical file
- no duplicate `<script src>` in Grade 1–12 play pages
- no physical legacy runtime files
- no active non-history references to legacy runtime filenames
- JavaScript syntax check run on canonical game modules and Grade 1–12 `engine/game.js`
