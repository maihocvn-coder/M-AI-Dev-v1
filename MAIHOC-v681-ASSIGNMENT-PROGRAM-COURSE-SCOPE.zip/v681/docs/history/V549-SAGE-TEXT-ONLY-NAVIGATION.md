# v549 — Sage text-only navigation

- Removed visual button/card boxes from Hint, Ask More, Quick Quiz, and Play with Sage.
- Kept the four actions as semantic clickable buttons for keyboard/accessibility and existing Sage runtime behavior.
- Active action is indicated only by a compact underline.
- Avatar and Close remain separate controls.
- Shared CSS change applies to Sage consistently without touching curriculum/content/question data.
