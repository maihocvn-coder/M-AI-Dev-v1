# V535 — Shared controls + jump-space repair

- Root cause: `.mse-play-bottom-stack` and `.mse-controller-row` intentionally use `pointer-events:none`, but `#g1v475Controls` never restored `pointer-events:auto`; pointer input could not reach the buttons.
- `#g1v475Controls` now restores pointer events. Movement remains owned by the canonical shared `assets/js/game/character/character-movement.js`.
- Character now consumes `--g1-player-x` inside the reserved Character Row, so Left/Right visibly changes horizontal position.
- Character remains vertically contained by Character Row; Controller remains in its separate following row.
- Answer Holder lane raised from the old 40cqh band to 31cqh (clamped 180–270px) to create a larger jump corridor above the character.
- No grade-specific game controller was reintroduced.
