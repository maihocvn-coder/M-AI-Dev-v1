# v550 — Sage compact text navigation repair

- Removed emoji from the four Sage header navigation labels.
- Removed the inherited white `.sage-tabs` strip by making the navigation background explicitly transparent.
- Forced the four Sage actions onto one compact horizontal row.
- Sage header now has three explicit columns: avatar | text navigation | close.
- Active state is text + underline only; no card, white background, border, or outline.
- No changes to Sage coaching content, question data, School English content pipeline, or avatar persistence.
