# v516 — v511 baseline + answer object icon only

Baseline: Shared Geometry Authority v511.

Only functional change: `makeBadge()` adds the existing canonical reward object visual before answer text, using `MAIHOC_SCHOOL_ENGLISH.resolveRewardObject()` + `rewardNode()`.

Only CSS change: sizing for `.mh-answer-reward-object` and its image.

Explicitly unchanged: world, character, controller, Sage, MainScreen geometry, navigation, Learn/Test geometry, Grade 1 engine, answer-holder positioning.
