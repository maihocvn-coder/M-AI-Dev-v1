# V537 — Fish Holder Tether

- Restored a short visual tether between each fish carrier and its answer badge.
- Preserved the canonical one-row, three-choice layout.
- Preserved vertical holder composition: fish -> tether -> reward icon + text + audio.
- Tether is presentation-only and does not intercept pointer events.
