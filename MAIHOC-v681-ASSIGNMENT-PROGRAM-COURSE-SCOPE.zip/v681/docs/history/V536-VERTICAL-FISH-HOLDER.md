# V536 — Vertical Fish Answer Holder

- Keeps exactly three answer choices in one horizontal lane.
- Changes each fish holder from horizontal fish+tether+badge to vertical: fish above, answer strip below.
- Answer strip stays horizontal: reward object/icon + text + audio.
- Removes the visual tether from the canonical holder.
- Raises the holder lane to preserve a clear jump corridor between answers and Character Row.
- No Grade 1 page controller was restored; shared UI runtime remains the renderer.
