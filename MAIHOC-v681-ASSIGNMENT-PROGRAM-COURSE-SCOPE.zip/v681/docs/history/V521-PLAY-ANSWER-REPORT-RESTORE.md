# v521 — Restore Play Answer Holders + Report Question

Baseline: v520 consolidated CSS.

- Removed obsolete global `body.mse-primary .catch-lane{display:none!important}` suppression that hid the shared Grade 1/sample Answer Holder lane.
- Kept `#answers` as the hidden event/data authority in Play; visible answers are rendered by the Game World holder renderer.
- Moved the existing `#report` button into `#scene` at runtime so `Report this question` remains available while the legacy `#interaction` panel is hidden in Play.
- Reuses the existing delegated `maihoc-question-report-v330.js` behavior; no duplicate report logic.
- No changes to question bank, reward logic, character, world art, controller behavior, Sage logic, or navigation.
