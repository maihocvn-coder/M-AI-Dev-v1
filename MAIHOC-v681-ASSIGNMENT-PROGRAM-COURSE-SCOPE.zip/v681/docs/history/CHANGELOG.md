# M-AI Học Runtime History

## Consolidation release v489 — 2026-10-02
- Replaced versioned `maihoc-game-ux-v*.js` runtime files with one canonical `assets/js/maihoc-game-ux.js`.
- Replaced versioned Grade 1 movement runtime files with one canonical `assets/js/maihoc-g1-character-movement.js`.
- Removed legacy bottom dock, shell divider, game divider, resize handle, adaptive workspace, question-collapse and workspace-close ownership from the active Grade 1 runtime.
- Learn, Play and Test now share one `.game-shell` / main holder; mode changes only change its content surface.
- Sage is one persistent DOM instance: visible in Learn and Play, hidden in Test; it is no longer re-parented into/out of the game scene.
- Answer carrier text no longer uses ellipsis; holders size/wrap liquidly.
- Consolidated Grade 1 visual ownership into one canonical CSS block in `maischoolenglish.css`; release history belongs here, not in runtime filenames.
- Merged the former game-canvas CSS into `assets/css/maischoolenglish.css`; School English now has one physical CSS authority.

## Release v490 — bottom-strip and control-position cleanup
- Removed Grade 1 `scene-progress` / `sceneBar` from the DOM and removed its runtime writes; the yellow bottom strip is no longer part of the game.
- Removed residual bottom spacing from the shared Grade 1 main holder so Learn/Play/Test no longer expose a separate bottom box.
- Canonically suppresses obsolete resize/divider/dock surfaces for Grade 1.
- Positioned the single game control cluster at the bottom immediately to the left of the floating Sage launcher; it no longer participates in normal scene flow or appears at the top.
- No new versioned runtime JS/CSS files were created; edits remain in the canonical current files.

## Release v491 — remove legacy bottom hamburger/resize strip
- Removed the obsolete `#resize/.resize` separator markup from School English grade game pages.
- Removed the old pointer-drag scene-height code and `maihoc.schoolEnglish.sceneHeight` dependency from grade runtimes that still used it.
- Removed stale resize CSS ownership and added one canonical invariant: no resize/divider/workspace-close strip in Learn, Play, or Test.
- No new versioned runtime JS/CSS files were created.

## 2026-10-02 — 12-grade canonical frame audit
- Promoted mode ownership from Grade-1-only `data-g1-mode` to shared `data-mse-mode` for Grades 1–12.
- Removed scene progress/yellow bottom strip DOM and sceneBar runtime writes from all 12 grades.
- Play hides the legacy interaction surface for all grades; Learn/Test use the same main holder.
- Standardized one Sage floating geometry/alignment across Grades 1–12; Sage hidden only in Test.
- Added generic in-world answer choices for Grades 2–12 until a grade-specific answer-carrier renderer is assigned.
## Release v493 — Generic 12-grade UX frame
- Replaced grade-specific frame ownership with one canonical Learn / Play / Test shell for Grades 1–12.
- Removed scene progress/divider strip from all 12 grade HTML files, not merely hidden with CSS.
- Play no longer renders the legacy interaction panel as a bottom pane; it remains only as hidden runtime data/controller DOM.
- Learn and Test use the same main holder geometry; only content changes by mode.
- One Sage instance and one centered Sage geometry for all grades; visible in Learn/Play and hidden in Test.
- Added a single generic mode owner in `maihoc-game-ux.js`; no versioned runtime JS/CSS files were created.



## v494 — Generic MainScreen UX consolidation
- One permanent School English page frame for Grades 1–12.
- Learn, Play, and Test use the exact same MainScreen geometry; only MainScreen content changes.
- Sage is one component owned by MainScreen: visible in Learn/Play, hidden in Test.
- Removed legacy shared UX patch stack (v460–v493 CSS blocks) and replaced it with one canonical frame section plus a contained Play-content section.
- No bottom workspace/divider/resizer surface.
- Grade 1 controls are anchored bottom-left inside Game World; Sage bottom-right.
- Answer carrier text wraps; no ellipsis.

## 2026-10-02 — Generic MainScreen visual repair
- Play scene now fills 100% of the shared MainScreen; removed the inherited 65vh cap that created the blank white lower box.
- Desktop responsive-nav hamburger is no longer created; mobile hamburger exists only at <=900px.
- Removed School English sidebar resizer runtime entirely from the canonical frame.
- Learn, Play and Test continue to share the same MainScreen dimensions and outer frame; only MainScreen content changes.

## 2026-10-02 — MainScreen Play visual ownership cleanup
- Removed Grade 1 generic world-journey and generic engine-target layers from the visible Play renderer; fish carriers are the sole visible answer renderer.
- Forced the legacy interaction/question controller surface to remain non-visual during Play.
- Consolidated the Play question into one card (skill + prompt + audio/action).
- Separated character and control anchors so the character remains fully inside the Game World.
- Standardized Sage inset inside MainScreen and suppressed redundant scene caption/status during normal Play.

## 2026-10-02 — Shared Grade Page Footer
- Added one permanent copyright footer to the Grade 1–12 School English frame.
- Footer is identical in Learn, Play Level, and Practice Test because modes share the same page shell.
- MainScreen remains the only interchangeable content region.
- Footer text: © 2026 M-AI Học. All rights reserved.


## 2026-10-02 — Shared Grade footer audit
- Removed the canonical-frame rule that hid every footer.
- Fixed the 100dvh/overflow-hidden shell clipping that kept the Grade footer below the visible page.
- Grade pages may scroll vertically so the shared copyright footer remains reachable after MainScreen.
- Prevented the global site-shell footer injector from hijacking the School English copyright footer.
- Footer remains shared CSS/page-frame UI for Grades 1–12 and all Learn/Play/Test modes.

## 2026-10-02 — Viewport-fit Grade page frame
- Grade page is locked to the current `100dvh`; the page itself does not scroll on desktop, iPad, or iPhone.
- MainScreen consumes the remaining workspace between the level header and copyright footer.
- Footer stays visible inside the viewport.
- Play never scrolls; long Learn/Test documents scroll only inside MainScreen.
- Left level list may scroll internally without moving the page.

## 2026-10-02 — Learn/Test MainScreen fill audit
- Fixed Learn/Test document surfaces so authored content fills the shared MainScreen instead of ending at intrinsic content height and leaving a large blank lower region.
- Removed the effective Knowledge max-width inside the canonical frame; Learn/Test now use the full shared screen width.
- Kept scrolling inside the Learn/Test document surface only; the Grade page remains viewport-fixed.

## 2026-10-02 — Shared Grade frame breadcrumb + Grade 1 movement repair
- Gave the shared breadcrumb its own grid row between the global header and Grade workspace; it no longer overlaps/crops the Grade title or left rail.
- Kept breadcrumb single-line, compact, and viewport-fit across desktop/tablet heights.
- Restored Grade 1 horizontal movement authority: character `left` now resolves from the movement runtime's `--g1-player-x` instead of a fixed CSS left anchor.
- Left/Right buttons, keyboard arrows/A-D, and auto-catch can now visibly reposition the character while CSS continues to own only the vertical anchor and visual sizing.

## 2026-10-02 — v503 MainScreen internal alignment
- Centered Grade 1 Play controller horizontally; character now has an independent higher vertical anchor while JS retains horizontal movement ownership.
- Restored the visible rainbow ring around collapsed Sage by separating ring padding from the inner avatar art.
- Learn/Test document surfaces now fill the complete MainScreen; tabs remain fixed and only the content body scrolls, eliminating the lower white dead area.

## 2026-10-02 — v504 compact Journey / game playfield separation
- Removed redundant Journey intro block (MY JOURNEY / Learn & Play English / explanatory copy) from the shared grade workspace.
- Removed redundant LEARN & PLAY section label while retaining the three mode buttons.
- Returned the recovered vertical space to the Level Map.
- Kept the game controller centered at the bottom as a HUD and raised the Grade 1 character into a separate playfield band so the HUD cannot cover it.

## 2026-10-02 — v505 liquid Game World
- Made Grade 1 Play answers, controls, character and Sage liquid inside MainScreen using container-relative sizing/anchors.
- All answer carriers remain inside the scene when width narrows; answer text/audio are preserved.
- Controller is centered relative to Game World at every width.
- Character vertical clearance scales with scene height instead of jumping upward on narrow layouts.
- Sage remains visible inside MainScreen in Learn/Play on narrow layouts.
- Left/right movement now persists facing direction: moving left flips the character; moving right restores normal orientation.

## 2026-10-02 — v508 Grade 1 reference-frame correction
- Reverted the v506/v507 mistake that allowed generic component rules to override the tested Grade 1 Play design.
- Grade 1 is now explicitly the visual/reference implementation.
- Shared frame inheritance is one-way: Grade 1 -> Grades 2–12.
- Generic Grade 2–12 frame selectors explicitly exclude `.grade-1`.
- Grades 2–12 expose replaceable world / engine / character / answer-holder hooks without changing Grade 1.

## 2026-10-02 — Clean world-object artwork
- World scenery objects are now artwork-only: transparent container, no colored tile, no border, no card shadow.
- Shared world renderer marks all generated scenery props as `world-object-art`; the rule applies across grades/worlds.
- A soft transparent drop-shadow is retained so objects read cleanly against the scene, matching the character-art treatment.

## 2026-10-02 — Shared MainScreen fill + persistent character facing
- Fixed Learn/Test full-height ownership at the actual runtime surface (`#stimulus.lesson-container`), so the content panel fills MainScreen instead of ending at intrinsic content height.
- Kept Learn/Test scrolling inside MainScreen only; no page-level scroll introduced.
- Raised the Grade 1 reference character into a dedicated playfield band above the centered controller.
- Made left/right facing persistent with `data-facing` plus runtime artwork transform, so question rerenders/class resets cannot erase the flip direction.
- Changes live in canonical shared CSS and current movement JS; no per-page CSS fork was added.

## 2026-10-02 — v517 narrow liquid reflow
- No desktop/frame redesign.
- On narrow MainScreen only, Grade 1 answer holders reflow from a horizontal row to a vertical column without dropping carrier, collectible object, text, or audio.
- Sage moves from the right safe edge to the left safe edge on narrow MainScreen so it remains fully visible.

## 2026-10-03 — Grade 1 reference cloned as Sample Kit for Grades 2–12
- Grade 1 remains unchanged as the visual control/reference.
- Added sample world, character, answer-holder and letter-catch descriptors under the canonical `assets/js/game/.../samples/` libraries.
- Grades 2–12 load the Sample Kit; their own curriculum/question banks remain grade-specific.
- Shared Grade 1 visual selectors now also accept `.mse-sample-g1`, so the same geometry can be tested without pretending Grades 2–12 are Grade 1.
- Fixed a pre-existing missing statement terminator in Grades 2–5 `engine/game.js` that prevented those grade runtimes from parsing; no curriculum content was changed.
