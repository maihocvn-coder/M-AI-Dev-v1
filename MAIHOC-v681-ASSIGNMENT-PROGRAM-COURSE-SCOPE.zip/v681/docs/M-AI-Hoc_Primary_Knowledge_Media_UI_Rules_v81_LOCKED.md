# M-AI Học Primary Knowledge Media + UI Rules v81 — LOCKED

1. Knowledge tab order is **Vocabulary → Phonics → Sentence Patterns** for Grades 1–5.
2. All three Knowledge skills use the same typography scale and card template. A skill may have different learning components, but must not silently increase base text size.
3. A lesson with an explicit `studentView.phoneme` MUST include a pronunciation teaching video whose content is verified to teach that exact phoneme.
4. A lesson without an explicit phoneme MUST NOT receive a phoneme video merely because the skill is called Phonics/Pronunciation. Stress, rhythm, intonation, spelling focus, and broad sound-focus lessons require their own verified media or no video.
5. Video label, target, and learner instruction must agree. Never embed a generic pronunciation video under a specific phoneme label.
6. If a video is removed, remove all video-specific headings/instructions/placeholders that would otherwise point to missing media.
7. Accent notation must be honest. Curriculum `/ɒ/` is a British-English LOT vowel, so its embedded lesson is explicitly labelled British English; do not silently substitute American `/ɑ/`.
8. Every YouTube iframe uses `referrerPolicy=strict-origin-when-cross-origin` and must be tested from an HTTP localhost server, not `file://`.
