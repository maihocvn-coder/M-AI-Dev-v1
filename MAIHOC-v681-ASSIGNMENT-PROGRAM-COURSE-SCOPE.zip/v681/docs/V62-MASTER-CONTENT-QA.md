# M-AI Học v62 Master Content QA

{
  "version": "v62",
  "framework": "Curriculum → Knowledge → Question Bank → Game/Station/Reward → Sage → QA",
  "skills": [
    "Vocabulary",
    "Pronunciation",
    "Grammar",
    "Speaking",
    "Reading",
    "Listening",
    "Writing"
  ],
  "questionTypes": [
    "MCQ",
    "Multi-select",
    "Drag & Drop",
    "Order/Sequence",
    "Text Input",
    "Record/Speak"
  ],
  "audio": {
    "vocabulary": "English TTS enabled",
    "listening": "English TTS stimulus; transcript hidden before answer",
    "phoneme": "Isolated phoneme playback blocked unless verified Creative Commons asset is supplied; word-level TTS allowed"
  },
  "grades": {
    "1": {
      "units": 16,
      "perSkill": 10,
      "questions": 1120,
      "lessons": 112
    },
    "2": {
      "units": 16,
      "perSkill": 10,
      "questions": 1120,
      "lessons": 112
    },
    "3": {
      "units": 20,
      "perSkill": 12,
      "questions": 1680,
      "lessons": 140
    },
    "4": {
      "units": 20,
      "perSkill": 12,
      "questions": 1680,
      "lessons": 140
    },
    "5": {
      "units": 20,
      "perSkill": 12,
      "questions": 1680,
      "lessons": 140
    },
    "6": {
      "units": 12,
      "perSkill": 14,
      "questions": 1176,
      "lessons": 84
    },
    "7": {
      "units": 12,
      "perSkill": 14,
      "questions": 1176,
      "lessons": 84
    },
    "8": {
      "units": 12,
      "perSkill": 14,
      "questions": 1176,
      "lessons": 84
    },
    "9": {
      "units": 12,
      "perSkill": 14,
      "questions": 1176,
      "lessons": 84
    },
    "10": {
      "units": 10,
      "perSkill": 16,
      "questions": 1120,
      "lessons": 70
    },
    "11": {
      "units": 10,
      "perSkill": 16,
      "questions": 1120,
      "lessons": 70
    },
    "12": {
      "units": 10,
      "perSkill": 16,
      "questions": 1120,
      "lessons": 70
    }
  }
}

## Release gates
- Curriculum map alignment required.
- Knowledge and bank share the same LO/content target.
- Every question has three Sage hints and explanation.
- Vocabulary/listening have TTS hooks.
- Isolated phoneme audio is not synthesized with ordinary TTS; only verified CC assets may be published.
- Original M-AI wording; no textbook question copying.
- Runtime syntax, JSON integrity, bank counts and link presence are validated by tools/qa-v62.py.
