# v248 Pre-Live Data & Relationship Hardening

## Canonical identity graph
User IDs are immutable keys. Family access uses `familyRelationships(parentId, childId)`. Class membership uses `enrollments(studentId, classId)`. Display names/emails are attributes, never joins.

## Read models
`MAIHOC_READ.studentRecord`, `childDashboard`, and `teacherRoster` compose assignments, submissions, grades and attendance without page-level joins.

## Storage boundary
`MAIHOC_DATA` now exposes `setAdapter()`. LocalStorage is the local/demo adapter only. Production should provide an authenticated server/API adapter; domain services and pages must not change when the adapter changes.

## Referential integrity
`MAIHOC_RELATIONS.validate()` checks family links, enrollments and submission references. Run it before/after migrations and deployment.

## Data lifecycle
User learning records must use immutable IDs and soft-delete/archive. Code rollback never rolls back protected learning data.
