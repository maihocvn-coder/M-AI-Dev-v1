# v31 Grades 1–12 Game Build

Grade 6 game shell is the shared visual/interaction template. Curriculum scope comes from M-AI Học Smart Game Engine Design v26. Product text, questions, examples, scenes and coaching are independently authored. No textbook passages, artwork, recordings or page layouts are copied.

Primary: playful concrete action. Grades 6–9: mixed adventure/scenario. Grades 10–12: role/evidence/synthesis while preserving play.

Every objective question has answer choices, immediate evaluation in Learn & Play, Vietnamese Sage coaching, retry, and a linked Knowledge lesson. Test-pool items remain hint-free in Practice Test mode.
