# V67 Primary Knowledge
Grades 1–5 use exactly three Knowledge/progress tracks: Phonics, Vocabulary, Sentence Patterns.
Level display titles are taken from Curriculum Truth Table FINAL v18. Animal names are not appended to level names.
Vocabulary: all Truth Table vocabulary + 5 age-appropriate enrichment words, audio button, Vietnamese meaning.
Phonics: target, explanation, model words, mouth/pronunciation video/search, contrast practice. Isolated phonemes are not synthesized with TTS.
Sentence Patterns: target/use → listen/mimic → substitute → natural response. Grades 4–5 include microphone record/replay.
Sage reveals learning steps progressively.
