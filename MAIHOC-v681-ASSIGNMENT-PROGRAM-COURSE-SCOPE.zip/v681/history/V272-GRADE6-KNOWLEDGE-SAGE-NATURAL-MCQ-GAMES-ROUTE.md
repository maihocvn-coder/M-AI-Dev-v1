# v272 Grade 6 Knowledge Sage — Natural Language, MCQ-only Quiz, Sage Games Route

- Baseline: v271.
- Knowledge Sage Hỏi thêm no longer interpolates raw concept headings into generic templates. Concept headings are normalized semantically (e.g. `Present Continuous là gì?` -> `Present Continuous`; `Possessive case dùng để làm gì?` -> `Possessive case`) before natural suggested questions are built.
- Natural-language audit covers all 356 Knowledge Sage concepts / 1,139 generated suggested questions.
- Knowledge Sage Quiz nhanh is MCQ-only. Removed textarea/free-text transfer fallback. Every concept resolves to an MCQ; existing authored quick checks are preferred, otherwise a same-concept MCQ is built from approved Knowledge records.
- Chơi với Sage is route-only: no embedded Build & Say / mini challenge. It explains that earned coins can be used for Sage games and provides `🎮 Mở Sage Games` with Grade/Unit/Skill/LO/concept context handoff.
- Question Sage and canonical Question Bank are not rewritten in v272.

QA: v272 Knowledge Sage gate PASS; 356 concepts; 1,139 suggested questions; 0 natural-template failures; runtime contract PASS (12 levels, 7 skills, 1,680 questions); v267 question quality PASS; v270 whole-item semantic PASS; v269 Knowledge Sage PASS; v268 runtime flow PASS; 142 JS files, 0 syntax errors.
