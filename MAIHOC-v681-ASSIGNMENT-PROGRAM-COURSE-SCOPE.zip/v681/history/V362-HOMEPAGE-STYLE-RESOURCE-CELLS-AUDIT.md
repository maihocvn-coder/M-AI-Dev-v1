# v362 — Homepage-style resource cells

- Homepage Grade 1–12 carousel changed from automatic infinite marquee to manual left/right arrow navigation.
- Removed duplicated Grade 1–12 cards used by the former infinite marquee.
- Teacher Learning Library M-AI discovery area now uses compact homepage-style cards, one card per top-level resource collection.
- Current top-level M-AI collections: M-AI School English and M-AI CEFR.
- Left sidebar remains a simple navigation list; no slider is placed in the sidebar.
- Existing full preview/copy/assign/editor behavior remains delegated to Resource Studio.
