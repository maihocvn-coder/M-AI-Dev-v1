# v534 — Knowledge label removal + canonical three-choice row

- Removed the redundant Knowledge/Kiến thức pill above the Grade 1 Knowledge tabs by hiding `.question-head` in Knowledge mode; it is restored outside Knowledge.
- Grade 1 canonical question bank audit: 960 MCQ items, all exactly 3 choices; no correct answer index >= 3.
- Game UI Answer Holder renderer now renders exactly the first 3 canonical choices and sets `--mse-answer-count: 3`.
- Canonical Play CSS fixes Answer Holder to exactly 3 columns × 1 row at every measured MainScreen width. Liquid behavior changes component sizing/gaps, not row count.
