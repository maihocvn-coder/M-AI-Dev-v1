# V325 Natural Bilingual Completion Audit

## Scope
Continues v324 mixed-language audit. All 138 v324 candidates were dispositioned page-by-page. School English learning content remains protected; UI translation engine remains active.

## Results
- v324 candidates reviewed: **138**
- Non-School-English UI candidates normalized into canonical natural VI/EN pairs: **109**
- School English learning-content candidates deliberately protected: **29**
- Unresolved candidates from the v324 list: **0**
- Old non-protected candidate strings still present in their source pages: **0**
- HTML pages: **378**
- HTML pages loading v325 i18n engine: **378**
- School English non-HTML learning/runtime assets compared against v324: **199**
- Changed School English non-HTML learning/runtime assets: **0**
- JS syntax: PASS (`node --check` engine + catalog)

## Natural-language rule
Every repaired UI phrase has a canonical Vietnamese sentence and a canonical English sentence. Mixed source phrases such as Vietnamese instructions containing English system vocabulary were rewritten as natural Vietnamese first, then paired with natural English. Educational example text is preserved where it is the object being taught.

## Role ownership
Organization browsing remains a Management-level capability. It is not rendered as an Organization Admin home function.

## Browser limitation
This is a source/static/runtime-contract audit. No claim of Chromium click-through PASS is made.
