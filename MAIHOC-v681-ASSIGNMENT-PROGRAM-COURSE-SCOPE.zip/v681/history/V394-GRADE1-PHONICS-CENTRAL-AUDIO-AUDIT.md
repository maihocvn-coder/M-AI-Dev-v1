# v394 — Grade 1 Phonics + Central Phoneme Audio Audit

- Normalized all 16 Grade 1 phonics lessons from doubled letter display (`Bb`, `Cc`, etc.) to explicit letter→sound contracts (`b → /b/`, `c → /k/`, etc.).
- Added `letterTarget`, `itemTargetPhoneme`, `phonemeKey`, and stable `targetKey` to all Grade 1 phonics questions.
- Knowledge renderer displays `Letter c → /k/` and a dedicated isolated-phoneme speaker.
- Regenerated Grade 1 Knowledge Sage phonics content around letter-sound correspondence; removed `Phonics của bài là Cc`-style coaching.
- All isolated phoneme audio is centralized in `MAIHOC_PHONEME_AUDIO`; no Grade 1 lesson/question/Sage owns an audio URL.
- Added University of Hamburg exact source records required by Grade 1: /k g f m n h l w/ in addition to existing /b d t æ ɪ e ʌ/ records.
- `/ɒ/` uses an exact-/ɒ/ verified fallback because Hamburg publishes no audio for its low-back /ɑ/ table row.
- Super Admin `/admin/phoneme-library/` can upload/activate M-AI-owned audio by phoneme. Runtime then uses the owned file everywhere automatically, with the external source retained only as fallback.
- Stable Super Admin override key remains v344 so future M-AI audio replacement does not require content regeneration.

QA gate: 16/16 phonics lessons and 320/320 phonics questions resolve to normalized letter + phoneme + centralized registry key; JavaScript syntax checks pass.
