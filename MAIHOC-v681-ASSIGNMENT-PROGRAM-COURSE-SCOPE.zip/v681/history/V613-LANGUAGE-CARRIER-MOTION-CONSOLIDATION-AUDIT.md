# V613 Language + Carrier Motion Consolidation Audit

## Language authority
- Canonical UI-language storage key: `maihoc.ui.language`.
- Removed `state.lang` from shared School English state creation and persistence.
- Replaced remaining Grade 2–12 runtime `state.lang` reads with the canonical UI-language getter.
- Removed versioned language-key fallback reads from the i18n runtime and question-report runtime.
- Static audit: zero `state.lang` references and zero `maihoc.ui.language.v*` references in executable source.

## Carrier motion authority
- Added one shared carrier-motion registry in `assets/js/game/ui/game-ui-runtime.js`.
- Supported motion vocabulary: still, wiggle, hover, flutter, drift, dart, circle, hop, crawl, climb, flee.
- Species capability map is separate from grade/level policy.
- Grade 1 policy is hard constrained to `wiggle` only. Species capabilities cannot override the Grade 1 policy.
- Each rendered carrier receives one `data-motion` selected by the shared motion controller.
- Replaced the previous unconditional carrier-hover animation authority with motion-specific selectors/keyframes in the canonical School English CSS.
- Entry/world travel and caught/removal lifecycle remain separate from idle carrier motion.

## Validation
- `node --check` passed for shared modified JS and all Grade 2–12 engine game files.
- ZIP integrity checked after packaging.
