# v380 Grade 1 Continue + Audio Visibility Repair

Root causes verified in v379:
1. Audio-choice data was valid (`audioPrompt` present), but CSS `body.g1-scene-choices #stimulus{display:none!important}` hid the question-level Listen control whenever visual scene choices were active.
2. Continue/resume could still reach an invalid/empty current queue state. v380 adds an emergency playable queue fallback after resume restoration so a Continue entry cannot render an empty interaction merely because a stale/incompatible snapshot failed restoration.

Repairs:
- audio stimulus receives `g1-audio-stimulus` and remains visible in scene-choice mode.
- question-level `▶ Nghe` is therefore visible while answer choices remain below and visual choices remain in the game scene.
- resume/start has a final valid-current-question guard and Grade 1 bank fallback.
- cache bust bumped to v380.

Audit:
- 160/160 `Nghe và chọn...` items have `audioPrompt`.
- each audioPrompt exactly matches the indexed correct option.
- JS syntax passes.
- Chromium headless was attempted but did not complete startup in this container; no browser-E2E claim is made.
