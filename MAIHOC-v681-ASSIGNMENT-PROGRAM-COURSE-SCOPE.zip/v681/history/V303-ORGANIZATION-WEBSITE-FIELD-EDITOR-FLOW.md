# v303 Organization Website Field Editor

- Organization Admin edits only template-defined fields; no HTML/script/layout styling editor.
- Media fields accept image, YouTube, Vimeo, or direct video URLs and auto-render a safe preview/embed.
- External URL media works for all plans. Hosted uploads remain a paid/storage capability.
- Management Admin/Super Admin can add approved 2-, 3-, or 4-card content rows and change row structure.
- Organization Admin fills each card's media URL, title, text, and button/link fields.
- Draft, Preview Draft, and Published views use the same content object; publish still requires preview of the current draft.
- Management controls remain hidden from Organization Admin.
