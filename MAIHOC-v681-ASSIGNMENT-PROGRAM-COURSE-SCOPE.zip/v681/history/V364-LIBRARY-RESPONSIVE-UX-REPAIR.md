# v364 Library Responsive UX Repair
- Promo cards increased from 82px to ~123px minimum height.
- School English promo now describes games around MOET learning objectives and Global Success themes and includes a Sage badge.
- CEFR promo includes Quiz and Worksheet visual badges.
- Fixed M-AI catalog grid collapsing into the editor's second column; catalog now spans the full main Library width.
- + Create now opens a resource-type chooser even while browsing the canonical M-AI Library, then moves creation into the owned library flow.
- Teacher top navigation removes Availability (available from teacher home/workspace) and collapses Announcements + My Teaching Hours into More below 1280px.
- Preserved resource table header filtering and source-scoped catalog behavior.
