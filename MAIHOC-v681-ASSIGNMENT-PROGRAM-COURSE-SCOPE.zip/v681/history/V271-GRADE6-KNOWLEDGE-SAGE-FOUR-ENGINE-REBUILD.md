# v271 Grade 6 Knowledge Sage — Four Engine Rebuild

- Baseline: v270.
- Fixed root cause: Knowledge `play` was routed to `quiz`, and Knowledge actions shared one generic renderer.
- Four distinct Knowledge engines: Teach, Explore/Ask, Quick Quiz, Mini Play.
- Teach: progressive hints with concept-bound explanation/example/notice/common mistake.
- Explore: concept-specific suggested questions plus free ask field.
- Quick Quiz: interactive MCQ when available plus transfer-production check.
- Mini Play: skill-specific activity; not routed through quiz.
- Restored `Mở Sage Games` CTA with Grade/Unit/Skill/LO/concept context handoff.
- Sage Games Hub consumes Knowledge context and displays the originating learning context.
- Knowledge concept changes reset hint/quiz/play/explore state and stop pronunciation audio.
- Question Sage core from pronunciation binding through Question play is byte-identical to v270.

QA: `qa-grade6-knowledge-sage-interactions-v271.js` PASS; v259 runtime contract PASS; v268 runtime flow PASS; v267 Question Quality PASS; v270 whole-item semantic PASS; v269 Knowledge Sage content gate PASS; 141 JS files syntax PASS.
