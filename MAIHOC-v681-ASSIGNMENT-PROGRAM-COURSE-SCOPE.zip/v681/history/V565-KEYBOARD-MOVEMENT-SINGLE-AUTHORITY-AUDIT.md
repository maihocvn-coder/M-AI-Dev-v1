# V565 — Keyboard movement single-authority audit

## Finding
Grade 1 loaded only `assets/js/game/character/character-movement.js`; the sample character file is not loaded by `play.html`.
There was no second ArrowRight handler elsewhere in the Grade 1 runtime.

The ArrowLeft and ArrowRight key recognition conditions were symmetric, but keyboard and on-screen controller still used separate execution paths:
- controller: `move(-6)` / `move(6)`
- keyboard: `move(-5)` / `move(5)`

That duplication means a working on-screen right control did not prove the keyboard was exercising the same action path. The reliable repair is to remove the duplicated movement dispatch.

## Repair
Added one `performAction(action)` authority.
Both pointer/controller input and keyboard input now call exactly the same function:
- left -> `performAction('left')`
- right -> `performAction('right')`
- jump -> `performAction('jump')`

Keyboard recognition still accepts `event.key`, `event.code`, and legacy keyCode/which fallbacks for ArrowLeft/ArrowRight/ArrowUp plus A/D/W/Space.

No curriculum, question, reward, Sage, layout, or answer-holder behavior changed.
