# V530 — True Character/Controller Rows + Measured Liquid UI

Baseline: v529 full game runtime consolidation.

## Audit finding
- Character and controller were not rows; both were absolutely positioned in `#scene` using competing `bottom` offsets.
- `character-movement.js` also created the controller, violating ownership (movement + UI creation in one module).
- Answer Holder and Sage responsive rules existed, but relied on MainScreen container queries while the page shell itself changes topology; the expected reflow could therefore fail to trigger at the visible viewport size.

## Consolidation
- `game/ui/game-ui-runtime.js` now owns creation/mounting of `.mse-character-row`, `.mse-controller-row`, and the controller UI.
- `game/character/character-movement.js` no longer creates or positions the controller; it only binds movement behavior to the UI-owned controls.
- Character is mounted into a dedicated Character Row.
- Controller is mounted into a dedicated Controller Row.
- Removed old character/controller `bottom`-offset geometry authority.
- Removed MainScreen width/height container-query responsive authorities.
- Game UI now measures the actual `.mse-main-screen` width with one `ResizeObserver` and sets exactly one state: `wide`, `medium`, `compact`, `narrow`, or `phone`.
- Answer Holder and Sage consume that single measured state.
- <=720 actual MainScreen width: Answer Holder = 2 columns.
- <=560 actual MainScreen width: Answer Holder = 1 vertical column.
- Sage shrinks/repositions from the same measured MainScreen state.

## Ownership
UI owns layout and controls. Character owns movement/animation. No duplicate responsive JS authority was added.
