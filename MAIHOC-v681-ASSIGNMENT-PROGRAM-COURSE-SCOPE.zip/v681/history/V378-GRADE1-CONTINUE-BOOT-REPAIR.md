# v378 Grade 1 Continue / boot repair

- Audited Student Home Continue URL and Grade 1 engine startup.
- Root reliability issue: Grade 1 play.html still loaded `game.js?v=376` even after v377 runtime changes, allowing browsers/local hosts to reuse an older cached runtime. The screenshot state (static Level 01 header, empty level map, dead controls) is consistent with the Grade 1 runtime not completing boot.
- Cache-busted Grade 1 game CSS, bank data, lesson data, Sage data, and game runtime to v378.
- Hardened resume restoration: invalid/stale queue IDs cannot leave the game with an empty queue; it falls back to a valid queue and question 1.
- Added boot recovery: if runtime initialization throws, the page no longer remains silently dead; level navigation is rebuilt where possible and a Reload Game action is shown.
- Fixed Student Home Grade 1 Continue clamp to allow all 16 Grade 1 levels (previous shared homepage code capped Continue at 12).
- Continue remains `resume=1`, restoring exact queue/question/index when the saved snapshot is valid.
