# v328 Deep Grade Runtime Audit

## Trigger
Grade 3 screenshot showed the Level Play shell but no question/prompt/options. User reported all four activity buttons did not load. This regression appeared after recent UI/i18n work, while game runtime had worked previously.

## Root causes found
1. **All 12 generated `bank-data.js` files now publish the canonical bank as `window.MAIHOC_BANK_DATA`.**
2. `game.js` still expected legacy grade-specific globals (`MAIHOC_G6_BANK`, `MAIHOC_G7_BANK`, etc.). Grades 1–6 were especially wrong because Grades 1–5 also referenced `MAIHOC_G6_BANK`.
3. Grades 1–5 canonical banks contained questions but no `levels[]` runtime metadata, while `game.js` requires `bank.levels` for title/theme/navigation/obstacles.
4. Grades 6–12 currently contain only `pool:"practice"`; Test mode filtered for `pool:"test"`, producing an empty queue.
5. The initial no-mode landing must be an orientation/guide screen, not Question 1/Vocabulary. The shared entry controller is retained and standardized for all grades.

## Repairs
- All Grade 1–12 `game.js`: canonical runtime binding is now `window.MAIHOC_BANK_DATA`.
- Removed remaining direct legacy `window.MAIHOC_G*_BANK.levels` references in the game runtimes.
- Grades 1–5: generated `levels[]` runtime metadata from each grade's existing `curriculum-map.json`; canonical question content was not rewritten.
- Test mode: uses reserved `test` pool when a bank has one; otherwise uses the canonical practice bank as a test source so the Test button cannot open an empty activity.
- New shared `maihoc-grade-entry-v328.js` gives every Grade an initial guide/orientation screen consistent with the Grade 6 flow. It does not show a Vocabulary question until the learner selects an activity.
- All 12 Grade play pages reference the v328 entry controller.

## Deep structural checks
- Grade 1: 16 levels, 960 questions; Unit 1 Practice and Test queues non-empty.
- Grade 2: 16 levels, 960 questions; Unit 1 Practice and Test queues non-empty.
- Grade 3: 20 levels, 1200 questions; Unit 1 Practice and Test queues non-empty.
- Grade 4: 20 levels, 1200 questions; Unit 1 Practice and Test queues non-empty.
- Grade 5: 20 levels, 1200 questions; Unit 1 Practice and Test queues non-empty.
- Grade 6: 12 levels, 1680 questions; Test uses practice fallback because no reserved test pool exists.
- Grades 7–9: 12 levels / 840 questions each; Test fallback non-empty.
- Grades 10–12: 10 levels / 700 questions each; Test fallback non-empty.
- Every curriculum unit represented by questions has corresponding runtime level metadata.
- All 12 `game.js` files pass `node --check`.
- Shared v328 entry controller passes `node --check`.

## Content safety
This repair changes runtime wiring/metadata only. Existing question prompts, answers, Sage coaching, Knowledge content, LOs and curriculum targets were not translated or rewritten by the repair.

## Browser limitation
A headless Chromium attempt in this environment did not complete, so this report does **not** claim browser click-through PASS. Runtime contracts and data queues were audited statically/programmatically.
