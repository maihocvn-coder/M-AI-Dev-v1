# v324 Natural Bilingual UI Audit

Scope: all site UI, including School English shell/UI. Protected: School English authored learning content (Knowledge, questions/answers, explanations, Sage teaching/coaching, curriculum/LOs, transcripts/resources).

## Screenshot-driven repairs
- Brand tagline: Mình và AI cùng học. ↔ Learning together with AI.
- Initial free capacity card: normalized complete VI/EN fragments; no mixed `Tối đa ... classes/teachers/students` target.
- Super Admin Guide and Organizational Admin Guide: bilingual titles and role-guide labels.
- Dynamic role/status/filter vocabulary: Independent, super admin/admin/teacher/parent/student, all, Scope, Department, Role, Organization, Individual, plan filters, search prompt.
- Management Admin function-card titles: bilingual catalog coverage added.
- Review Queue Vietnamese label changed to `Sản phẩm đợi duyệt`.
- Full Page Preview Vietnamese label changed to `Phóng to`.
- Student wallet card source normalized to natural Vietnamese, with canonical EN pair: `Ví & Phần thưởng` ↔ `Wallet & Rewards`, `Xu` ↔ `Coins`, and a fully monolingual sentence in each locale.
- Mixed management guidance sentence normalized to complete Vietnamese and complete English pair.
- Sample seed names normalized away from realistic demo names in shared `maihoc-*` JS fixtures.

## Structural checks
- HTML pages: 378
- HTML pages loading v324 i18n engine: 378
- JS syntax: PASS for v324 engine and catalog.
- School English learning content remains protected by the existing protected-content boundary; this release targets UI strings, not authored learning content.

## Natural-language residual audit
A conservative source scanner still reports 138 mixed-language candidates. These are intentionally NOT declared clean. They include page titles, technical prototype/help copy, and some mixed legacy authoring/admin descriptions. See `/mnt/data/V324-MIXED-LANGUAGE-SOURCE-AUDIT.csv` for page-by-page review.

This means v324 fixes the screenshot-reported defects and improves the bilingual grouping, but the natural-language whole-site cleanup is not yet honestly at zero residual candidates.
