# v262 Grade 6 — Phoneme Speaker Repair

## Goal
Keep every pronunciation interaction inside M-AI Hoc. No external-page links. Speaker buttons must play the target sound rather than a syllable such as "sa", "sha", "tha".

## Grade 6 consonant scope
Curriculum targets found in lesson-data.js: /s z/, /b p/, /t d/, /s ʃ/, /θ ð/. No extra consonant is introduced.

## Delivery contract
- Knowledge, Question and Sage share `window.MAIHOC_PHONEME_AUDIO`.
- `/p b t d/`: phonetic-sample recordings identified by source history as the consonant itself.
- `/s z ʃ θ ð/`: isolated in-app continuous consonant rendering; no appended /a/ vowel.
- Vowels keep the existing IPA sample path.
- UI is speaker-only (`🔊` / `⏸`); no `window.open`, source-only button, or outbound learner link.
- Starting a new phoneme stops the previous one.

## Source review
Wikimedia Commons IPA metadata/file histories were used to verify phoneme identity. Sounds American / American English Sounds articulation descriptions were used as an English pronunciation cross-check. Source pages are research/provenance only and are not opened by the student UI.

## QA gates
1. Registry contains every Grade 6 consonant target.
2. No source-only/external-link UX remains.
3. No TTS of IPA symbols.
4. `game.js` Knowledge and Question controls use the shared registry.
5. JavaScript syntax and package dependency scans pass.
