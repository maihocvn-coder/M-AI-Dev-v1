const fs=require('fs'),vm=require('vm');let fail=[];const game=fs.readFileSync('student/my-school-english/grade6/engine/game.js','utf8');const phon=fs.readFileSync('assets/js/maihoc-phoneme-audio.js','utf8');const sage=fs.readFileSync('assets/js/game/sage/sage-runtime.js','utf8');
for(const token of ['knowledgeSectionId','conceptId','loId','maihoc:knowledgechange'])if(!game.includes(token))fail.push('knowledge context missing '+token);
for(const token of ['kctx','kcoach','knowledgeView','maihoc:knowledgechange'])if(!sage.includes(token))fail.push('knowledge Sage missing '+token);
for(const p of ['p','b','t','d','s','z','ʃ','θ','ð'])if(!phon.includes("'"+p+"':"))fail.push('phoneme registry missing '+p);
if(!phon.includes("a.onerror")||!phon.includes("Audio unavailable"))fail.push('audio load failure is not surfaced');
if(!game.includes("MAIHOC_PHONEME_AUDIO?.has(key)"))fail.push('Knowledge can render dead phoneme button');
if(!game.includes("window.MAIHOC_KNOWLEDGE_CONTEXT=null"))fail.push('question mode does not clear Knowledge context');
console.log(JSON.stringify({gate:'v260',failures:fail},null,2));process.exit(fail.length?1:0);
