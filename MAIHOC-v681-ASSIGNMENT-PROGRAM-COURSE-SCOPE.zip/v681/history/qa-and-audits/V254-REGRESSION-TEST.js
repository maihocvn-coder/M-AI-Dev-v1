const fs=require('fs'),path=require('path'),assert=require('assert');
const root=__dirname;
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
// Entry flow: all grade homes and legacy unit redirects must not auto-start play.
for(let g=1;g<=12;g++){
 const home=read(`student/my-school-english/grade${g}/home.html`);
 assert(!/engine\/play\.html\?level=\d+&mode=play/.test(home),`G${g} home auto-starts play`);
 const play=read(`student/my-school-english/grade${g}/engine/play.html`);
 assert(play.includes('maihoc-grade-entry-v253.js?v=254'),`G${g} missing shared entry`);
 assert(play.includes('maihoc-pronunciation-flow-v254.js'),`G${g} missing pronunciation controller`);
}
const entry=read('assets/js/maihoc-grade-entry-v253.js');
assert(entry.includes('CHƯA CÓ CÂU HỎI'),'orientation must suppress question counter');
assert(entry.includes("sage.dataset.collapsed='false'"),'Sage must be visible on orientation');
assert(entry.includes("p.delete('mode')"),'level selection must not auto-launch activity');
// Pronunciation separation: phoneme -> isolated source; word -> TTS. No IPA is spoken by TTS.
const pron=read('assets/js/maihoc-pronunciation-flow-v254.js');
assert(pron.includes("kind==='phoneme'?playPhoneme(value):playWord(value)"),'audio pipelines not separated');
assert(pron.includes("MAIHOC_PHONEME_AUDIO?.play"),'phoneme must use isolated source');
assert(pron.includes("MAIHOC_TTS?.speak"),'word must use word speech pipeline');
const ph=read('assets/js/maihoc-phoneme-audio.js');
for(const p of ['s','z','t','d','ɑː','æ']) assert(ph.includes(`'${p}':`),`missing isolated mapping ${p}`);
// Sage pronunciation hint must not use the reported meta prompt and quick quiz must expose both audio types.
const sage=read('assets/js/game/sage/sage-runtime.js');
assert(sage.includes('Nghe riêng âm'),'missing concrete pronunciation hint');
assert(sage.includes('data-sage-phoneme'),'quick/hint missing phoneme audio');
assert(sage.includes('data-sage-word'),'quick/hint missing word audio');
assert(!sage.includes('Để phân biệt đáp án phát âm, em nên làm gì?'),'reported meta hint still hardcoded');
console.log(JSON.stringify({version:254,entryFlow:'PASS',sageVisibleOrientation:'PASS',pronunciationHintNonMeta:'PASS',phonemeWordAudioSeparated:'PASS',zAudioMapped:'PASS',quickQuizDualAudio:'PASS',gradesChecked:12}));
