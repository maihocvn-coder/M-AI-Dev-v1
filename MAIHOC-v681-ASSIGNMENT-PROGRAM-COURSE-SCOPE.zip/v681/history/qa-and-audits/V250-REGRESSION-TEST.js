const fs=require('fs'),vm=require('vm');
class ET{constructor(){this.m={}}addEventListener(t,f){(this.m[t]??=[]).push(f)}removeEventListener(){}dispatchEvent(e){(this.m[e.type]||[]).forEach(f=>f(e));return true}}
class CE{constructor(type,o={}){this.type=type;this.detail=o.detail}}
const store=new Map();const localStorage={getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k)};
const ctx={window:{},localStorage,EventTarget:ET,CustomEvent:CE,console,Date,JSON,setTimeout,clearTimeout};ctx.window=ctx;vm.createContext(ctx);
function load(f){vm.runInContext(fs.readFileSync(f,'utf8'),ctx,{filename:f})}
load(__dirname+'/assets/js/maihoc-data-core-v245.js');
let r=ctx.MAIHOC_DATA.upsert('courses',{id:'c1',name:'A'});const rev=r._rev;ctx.MAIHOC_DATA.upsert('courses',{id:'c1',name:'B'},{expectedRevision:rev});let conflict=false;try{ctx.MAIHOC_DATA.upsert('courses',{id:'c1',name:'STALE'},{expectedRevision:rev})}catch(e){conflict=e.code==='MAIHOC_REVISION_CONFLICT'}if(!conflict||ctx.MAIHOC_DATA.get('courses','c1').name!=='B')throw Error('concurrency failed');
ctx.MAIHOC_CONFIG={environment:'production'};ctx.fetch=async()=>({ok:false,json:async()=>({})});load(__dirname+'/assets/js/maihoc-auth-context-v250.js');
(async()=>{let closed=false;ctx.MAIHOC_AUTH.setProvider({get:async()=>({verified:false,roles:['super_admin']})});try{await ctx.MAIHOC_AUTH.context()}catch(e){closed=e.code==='MAIHOC_AUTH_UNVERIFIED'}if(!closed)throw Error('auth fail-closed failed');
ctx.MAIHOC_AUTH.setProvider({get:async()=>({verified:true,roles:['super_admin'],userId:'u-super'})});load(__dirname+'/assets/js/maihoc-infrastructure-v250.js');let payload=null;ctx.MAIHOC_INFRA.setProvider({status:async()=>({configured:true}),requestBackup:async x=>(payload=x,{ok:true}),requestRestoreDrill:async x=>({ok:true})});await ctx.MAIHOC_INFRA.requestBackup({reason:'test'});if(!payload||payload.reason!=='test'||'data' in payload)throw Error('backup contract failed');console.log(JSON.stringify({concurrency:'PASS',authFailClosed:'PASS',backupBoundary:'PASS'}));})().catch(e=>{console.error(e);process.exit(1)});
