const fs=require('fs'),vm=require('vm');
const game=fs.readFileSync('student/my-school-english/grade6/engine/game.js','utf8');
const pron=fs.readFileSync('assets/js/maihoc-pronunciation-flow-v254.js','utf8');
const lesson=fs.readFileSync('student/my-school-english/grade6/engine/lesson-data.js','utf8');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(lesson,ctx);const lessons=ctx.window.MAIHOC_G6_LESSONS;
const fails=[];
function need(ok,msg){if(!ok)fails.push(msg)}
need(/function navigateUnit\(nextUnit\)/.test(game),'missing navigateUnit');
need(/state\.mode=previousMode;state\.skill=previousSkill/.test(game),'unit navigation does not preserve mode+skill');
need(/state\.topicFilter=previousMode==='practice'\?previousSkill:null/.test(game),'practice skill not preserved');
need(/if\(previousMode==='knowledge'\) knowledge\(previousSkill\)/.test(game),'knowledge skill not restored');
need(!/b\.onclick=\(\)=>\{state\.unit=l\.unit;state\.index=0;state\.mode='play'/.test(game),'legacy level reset to play remains');
need(/MAIHOC_IS_QUESTION_ACTIVE/.test(game)&&/MAIHOC_IS_QUESTION_ACTIVE/.test(pron),'question-active pronunciation guard missing');
need(/question:null/.test(game),'welcome does not clear question decorators');
need(/maihoc:stop-audio/.test(game),'welcome/unit transition does not stop audio');
const gs=lessons.filter(x=>x.skill==='Grammar');need(gs.length===12,'expected 12 grammar lessons');
for(const g of gs){const ex=g.studentView?.examples||[];need(ex.length>=4,`U${g.level} grammar has ${ex.length} examples`);for(const e of ex)need(typeof e==='string'&&/[.!?]$/.test(e.trim()),`U${g.level} incomplete grammar example: ${e}`)}
need(/Ví dụ · Examples/.test(game),'Grammar Examples block not rendered');
if(fails.length){console.error(JSON.stringify({status:'FAIL',fails},null,2));process.exit(1)}
console.log(JSON.stringify({status:'PASS',unitTransitions:'preserve mode + skill',welcomePronunciationLeak:'guarded',grammarLessons:gs.length,grammarExamples:gs.reduce((n,g)=>n+g.studentView.examples.length,0)},null,2));
