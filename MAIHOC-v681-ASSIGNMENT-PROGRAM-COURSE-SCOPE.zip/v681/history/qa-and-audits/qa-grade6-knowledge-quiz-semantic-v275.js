const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname, dataFile=root+'/student/my-school-english/grade6/engine/sage-knowledge-data.js', masterFile=root+'/assets/js/game/sage/sage-runtime.js';
const c={window:{}};vm.createContext(c);vm.runInContext(fs.readFileSync(dataFile,'utf8'),c);const data=c.window.MAIHOC_G6_SAGE_KNOWLEDGE_V275;assert.equal(data.length,356);
const master=fs.readFileSync(masterFile,'utf8');
assert(!master.includes('class="sage-free-ask"'),'KNOWLEDGE_FREE_TEXT_ASK still rendered');
assert(!master.includes('id="kAskInput"'),'kAskInput still rendered');
assert(!master.includes("kNeighbors(d).filter(x=>x.anotherExample"),'neighbor-example distractor fallback still present');
assert(master.includes('verifiedGrammarMCQ'),'verified grammar MCQ engine missing');
assert(master.includes('validateKnowledgeMCQ'),'MCQ structural validator missing');
assert(master.includes('chưa được phát hành'),'fail-closed UX missing');
for(const d of data){if(d.quickCheck){assert(Array.isArray(d.quickCheck.options)&&d.quickCheck.options.length>=2,`options ${d.conceptId}`);assert(Number.isInteger(d.quickCheck.answer),`answer ${d.conceptId}`);const o=d.quickCheck.options.map(x=>String(x).trim().toLowerCase());assert.equal(new Set(o).size,o.length,`duplicate option ${d.conceptId}`)}}
const badNotices=data.filter(d=>/là gì\?[, ]/i.test(d.notice||''));assert.equal(badNotices.length,0,'question-form concept leaked into feedback/notice: '+badNotices.map(x=>x.conceptId));
// Explicit regression for the screenshot defect: exactly one option must be Present Continuous in the definition quiz.
const pc=/prompt:'Câu nào nói về một hành động đang xảy ra ngay lúc nói\?'[\s\S]*?options:\['Mai talks to her new classmate every day\.','Mai is talking to her new classmate now\.','Mai talked to her new classmate yesterday\.'\][\s\S]*?answer:1/;assert(pc.test(master),'Present Continuous semantic-distinction MCQ regression');
console.log(JSON.stringify({concepts:data.length,authoredQuickChecks:data.filter(x=>x.quickCheck).length,freeTextAsk:false,neighborFallback:false,presentContinuousRegression:'PASS',status:'PASS'},null,2));
