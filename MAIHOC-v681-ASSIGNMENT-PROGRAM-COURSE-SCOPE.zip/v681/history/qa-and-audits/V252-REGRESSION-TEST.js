const fs=require('fs'),vm=require('vm'),assert=require('assert');
function storage(){let d={};return{getItem:k=>d[k]??null,setItem:(k,v)=>d[k]=String(v),removeItem:k=>delete d[k],clear:()=>d={}}}
const ctx={window:{},localStorage:storage(),sessionStorage:storage(),console,Date,JSON,Math,URLSearchParams,location:{search:'',pathname:'/'},CustomEvent:function(){}};ctx.window=ctx;vm.createContext(ctx);
// scope persistence
vm.runInContext(fs.readFileSync(__dirname+'/assets/js/maihoc-scope-access.js','utf8'),ctx);ctx.localStorage.setItem('maihoc.demo.session',JSON.stringify({userId:'u-admin',activeRole:'admin',organizationId:'org-sunshine'}));
let c=ctx.MAIHOC_SCOPE.courses()[0]; assert(c); let r=ctx.MAIHOC_SCOPE.updateCourse(c.id,{name:'Regression Course'});assert(r&&ctx.MAIHOC_SCOPE.courses().find(x=>x.id===c.id).name==='Regression Course');
ctx.MAIHOC_SCOPE.updateCourse(c.id,{status:'archived'});assert.equal(ctx.MAIHOC_SCOPE.courses().find(x=>x.id===c.id).status,'archived');
// calendar + makeup invariant
vm.runInContext(fs.readFileSync(__dirname+'/assets/js/maihoc-calendar.js','utf8'),ctx);vm.runInContext(fs.readFileSync(__dirname+'/assets/js/maihoc-v252-flow-fixes.js','utf8'),ctx);
ctx.MAIHOC_CAL.upsertSession({id:'src',classId:'g6a',className:'English 6A',start:'2026-09-20T10:00',end:'2026-09-20T11:00',status:'cancelled_today'});
assert.equal(ctx.MAIHOC_SESSION_FLOW.validateMakeup({id:'m1',classId:'g6a',status:'makeup'}).ok,false);
assert.equal(ctx.MAIHOC_SESSION_FLOW.validateMakeup({id:'m1',classId:'g7b',status:'makeup',makeupForSessionId:'src'}).ok,false);
ctx.MAIHOC_SESSION_FLOW.saveSession({id:'m1',classId:'g6a',className:'English 6A',start:'2026-09-30T10:00',end:'2026-09-30T11:00',status:'makeup',makeupForSessionId:'src'});
assert.equal(ctx.MAIHOC_CAL.load().sessions.find(x=>x.id==='m1').makeupForSessionId,'src');
// resource taxonomy
const rs=ctx.MAIHOC_SCOPE.resources();assert(rs.find(x=>x.id==='mai-school-english'&&x.name==='M-AI School English'&&x.category==='Game Books'));assert(rs.find(x=>x.id==='mai-question-bank'&&x.category==='Question Banks'));assert(rs.find(x=>x.id==='mai-ws'&&x.category==='Worksheets'));
console.log(JSON.stringify({courseSave:'PASS',courseArchive:'PASS',makeupRequiredSource:'PASS',makeupSameClass:'PASS',makeupPersistence:'PASS',resourceTaxonomy:'PASS'}));
