const fs=require('fs'),path=require('path'),root=__dirname;
const html=fs.readFileSync(path.join(root,'organization/demo/home.html'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/maihoc-organization-website-v310.js'),'utf8');
const home=fs.readFileSync(path.join(root,'assets/js/maihoc-admin-home-v299.js'),'utf8');
const checks={
 one_header:(html.match(/<header class="hero"/g)||[]).length===1,
 exactly_three_runtime:/slice\(0,3\)/.test(js)&&/while\(boxes\.length<3\)/.test(js),
 no_layout_selector:!html.includes('2 / 3 / 4 Boxes')&&!js.includes('openFeatured')&&!js.includes('Number of boxes'),
 no_generic_content_row:!html.includes('Add Content Row')&&!js.includes('Add Content Row'),
 three_box_grid:/grid-template-columns:repeat\(3,1fr\)/.test(html),
 header_image_drag:/openHeader/.test(js)&&/bindCrop/.test(js)&&/positionX/.test(js)&&/positionY/.test(js),
 box_image_video:/Media type/.test(js)&&/YouTube, Vimeo/.test(js)&&/boxCrop/.test(js),
 about_edit:/openAbout/.test(js)&&/editAbout/.test(html),
 contact_edit:/openContact/.test(js)&&/editContact/.test(html),
 org_identity_prominent:/YOUR ORGANIZATION/.test(home)&&/M-AI Học Website/.test(home),
 org_open_edit:/Open Website/.test(home)&&/Edit Website/.test(home),
 org_name_inline_edit:/Edit Organization/.test(home)&&/orgIdentityNameInput/.test(home),
 org_external_website:/External website/.test(home)&&/orgExternalInput/.test(home),
 org_rename_confirmation:/Organization name changed/.test(home)
};
const fail=Object.entries(checks).filter(([,v])=>!v).map(([k])=>k);
console.log(JSON.stringify({checks,pass:Object.keys(checks).length-fail.length,total:Object.keys(checks).length,fail},null,2));
process.exit(fail.length?1:0);
