from pathlib import Path
from bs4 import BeautifulSoup
import json,re,subprocess
root=Path(__file__).parent
html=list(root.rglob('*.html'))
empty_buttons=[]; empty_links=[]; missing=[]
for p in html:
    try:s=BeautifulSoup(p.read_text(errors='ignore'),'html.parser')
    except:continue
    for b in s.find_all('button'):
        label=' '.join(b.stripped_strings) or b.get('aria-label') or b.get('title')
        if not label: empty_buttons.append(str(p.relative_to(root)))
    for a in s.find_all('a'):
        label=' '.join(a.stripped_strings) or a.get('aria-label') or a.get('title')
        if not label: empty_links.append(str(p.relative_to(root)))
        h=(a.get('href') or '').strip()
        if h and not h.startswith(('#','http:','https:','mailto:','tel:','javascript:','data:')):
            target=(p.parent/h.split('#')[0].split('?')[0]).resolve()
            if not target.exists(): missing.append([str(p.relative_to(root)),h])
# contract checks
home=(root/'assets/js/maihoc-admin-home-v299.js').read_text()
shell=(root/'assets/js/maihoc-site-shell.js').read_text()
web=(root/'organization/demo/home.html').read_text()
gov=(root/'assets/js/maihoc-admin-governance-v282.js').read_text()
checks={
 'org_admin_has_no_org_selector': "(r==='management_admin'||r==='super_admin')?orgSelector()" in home,
 'compact_org_admin_nav': "label:'Home'" in shell and "label:'More'" in shell,
 'website_home_card': "id:'org.website'" in gov,
 'settings_home_card': "id:'org.settings'" in gov,
 'website_draft_publish': "Save Draft" in web and "Preview Draft" in web and "Publish" in web,
 'website_2_3_4_rows': "[2,3,4]" in web and "Add Content Row" in web,
 'website_media_auto_embed': all(x in web for x in ['youtubeEmbed','vimeoEmbed','mediaKind']),
 'website_edit_buttons': 'data-edit="programHeader"' in web and 'data-rowbox' in web,
 'school_english_rename_complete': not any('My School English' in p.read_text(errors='ignore') for p in root.rglob('*') if p.is_file() and p.suffix.lower() in {'.html','.js','.css'}),
}
report={'version':'v307','html_pages':len(html),'empty_buttons':len(empty_buttons),'empty_links':len(empty_links),'missing_local_links':len(missing),'contract_checks':checks,'examples':{'empty_buttons':empty_buttons[:10],'empty_links':empty_links[:10],'missing':missing[:20]}}
(root/'V307-ORGANIZATION-ADMIN-WEBSITE-AUDIT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
(root/'V307-ORGANIZATION-ADMIN-WEBSITE-AUDIT.md').write_text('# V307 Organization Admin + Website Audit\n\n'+ '\n'.join([f'- {k}: {"PASS" if v else "FAIL"}' for k,v in checks.items()])+f'\n- HTML pages scanned: {len(html)}\n- Empty buttons: {len(empty_buttons)}\n- Empty links: {len(empty_links)}\n- Missing local href targets: {len(missing)}\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
if not all(checks.values()): raise SystemExit(2)
