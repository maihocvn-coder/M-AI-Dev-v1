const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync('student/my-school-english/grade6/engine/sage-knowledge-data.js','utf8');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(src,ctx);const data=ctx.window.MAIHOC_G6_SAGE_KNOWLEDGE_V273||[];
const errors=[];let utterances=0,questions=0;
const bad=[
 [/là gì\s+là gì/i,'NESTED_DEFINITION'],[/dùng để làm gì\s+là gì/i,'NESTED_PURPOSE'],[/khi nào[^?]*dùng[^?]*[“\"]?[^?]*(là gì|dùng để làm gì)\?/i,'QUESTION_AS_NOUN'],[/target grammar|target structure|target language|the rule\b(?!s)|the structure above/i,'META_LANGUAGE'],[/Khi dùng lỗi dễ gặp/i,'UNNATURAL_LABEL_INSERTION'],[/Áp dụng bước này trực tiếp vào passage/i,'GENERIC_READING_EXAMPLE'],[/Phần này cần phục vụ đúng mục đích/i,'GENERIC_WRITING_NOTICE']
];
for(const d of data){
 if(!d.semantic?.canonicalConcept||!d.semantic?.conceptType||!d.semantic?.semanticIntent)errors.push([d.conceptId,'MISSING_SEMANTIC_RECORD']);
 if(!Array.isArray(d.exploreQuestions)||d.exploreQuestions.length<3)errors.push([d.conceptId,'MISSING_EXPLORE_QUESTIONS']);
 const texts=[d.explain,d.anotherExample,d.notice,...(d.exploreQuestions||[]),(d.commonMistake||{}).explanation,(d.quickCheck||{}).prompt,(d.quickCheck||{}).feedback].filter(Boolean);
 utterances+=texts.length;questions+=(d.exploreQuestions||[]).length;
 for(const t of texts)for(const [rx,code] of bad)if(rx.test(t))errors.push([d.conceptId,code,t]);
 for(const q of d.exploreQuestions||[]){if(!/[?？.!]$/.test(q))errors.push([d.conceptId,'PROMPT_PUNCTUATION',q]);if((q.match(/\?/g)||[]).length>1)errors.push([d.conceptId,'NESTED_QUESTION_MARK',q]);}
}
const js=fs.readFileSync('assets/js/game/sage/sage-runtime.js','utf8');
if(/function cleanConcept/.test(js))errors.push(['runtime','LEGACY_CLEANCONCEPT_PRESENT']);
if(/\$\{title\}|conceptTitle/.test(js.slice(js.indexOf('function semanticConcept'),js.indexOf('function knowledgeView'))))errors.push(['runtime','DISPLAY_TITLE_GENERATION_PRESENT']);
if(/<textarea|type=['"]?text[^>]*kQuiz/i.test(js.slice(js.indexOf('function kQuiz'),js.indexOf('function kPlay'))))errors.push(['runtime','KNOWLEDGE_QUIZ_NOT_MCQ_ONLY']);
if(!/Mở Sage Games/.test(js.slice(js.indexOf('function kPlay'),js.indexOf('function knowledgeView'))))errors.push(['runtime','SAGE_GAMES_CTA_MISSING']);
console.log(JSON.stringify({status:errors.length?'FAIL':'PASS',concepts:data.length,utterances,exploreQuestions:questions,errors:errors.slice(0,30)},null,2));process.exit(errors.length?1:0);
