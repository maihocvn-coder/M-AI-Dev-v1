const fs=require('fs'),path=require('path');
const ROOT=__dirname;
function walk(d,out=[]){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p,out);else if(e.name.endsWith('.html'))out.push(p)}return out}
const groups=[
 ['super_admin',/^admin\/(super-admin|admin-control|features|recovery-center|subscription|appearance|template-ui|role-feature-access|authoring-access|extension-studio|page-access|platform-catalog|product-curriculum|tts)\//],
 ['management_admin',/^admin\/(management-admin|analytics|management-payroll|platform-people|platform-classes|platform-resources|organizations|content-release|live-operations|global-calendar)\//],
 ['curriculum_admin',/^admin\/(curriculum-admin|content-audit|content-studio|curriculum-team|learning-objectives|question-bank|content-editor|content-import|content|game-setup|worksheet-bank)\//],
 ['curriculum_designer',/^admin\/curriculum-designer\//],
 ['organization_admin',/^admin\/(organization|organization-analytics|organization-website|people|courses|classes|resources|calendar|payroll|settings|programs)\//],
 ['teacher',/^teacher\//],['parent',/^parent\//],['student',/^student\//],['shared',/^account\//]
];
const ownerOf=r=>{if(/^admin\/reports\/home\.html$/.test(r))return 'curriculum_admin';if(/^admin\/reports\/(attendance|teacher-hours)\.html$/.test(r))return 'organization_admin';if(/^admin\/(announcements|notifications|my-space|portal)\//.test(r))return 'shared';for(const [o,rx] of groups)if(rx.test(r))return o;return r.startsWith('admin/')?'unclassified_admin':'shared'};
const files=walk(ROOT).map(p=>path.relative(ROOT,p).replace(/\\/g,'/'));
const findings=[],inventory=[];
const contamination={
 super_admin:[/\bmy courses\b/i,/\bmy students\b/i,/\bmy child\b/i],
 management_admin:[/\bmy courses\b/i,/\bmy students\b/i,/\bmy child\b/i],
 curriculum_admin:[/\bmy child\b/i],
 organization_admin:[/\bplatform performance\b/i,/\ball organizations\b/i,/\bglobal subscription/i],
 teacher:[/\ball organizations\b/i,/\bplatform payroll\b/i,/\bcontent release\b/i],
 parent:[/\bplatform payroll\b/i,/\bcontent audit\b/i],
 student:[/\borganization payroll\b/i,/\bcontent audit\b/i]
};
for(const rel of files){const owner=ownerOf(rel),html=fs.readFileSync(path.join(ROOT,rel),'utf8');const title=(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)||[])[1]?.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim()||'';const h1=(html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)||[])[1]?.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim()||'';inventory.push({route:rel,owner,title,h1});if(owner==='unclassified_admin')findings.push({severity:'REVIEW',code:'UNCLASSIFIED_ADMIN_PAGE',route:rel});for(const rx of contamination[owner]||[])if(rx.test(title+' '+h1))findings.push({severity:'FAIL',code:'ROLE_SEMANTIC_CONTAMINATION',route:rel,owner,pattern:String(rx),title,h1});

}
// Registry route ownership collisions across different sections are hard failures unless same owner family and query-view reuse.
const gov=fs.readFileSync(path.join(ROOT,'assets/js/maihoc-admin-governance-v282.js'),'utf8');
const rows=[...gov.matchAll(/\{id:'([^']+)',section:'([^']+)',label:'([^']+)',icon:'[^']*',href:'([^']+)'/g)].map(m=>({id:m[1],section:m[2],label:m[3],href:m[4]}));
const by={};for(const x of rows){const k=x.href.split('?')[0];(by[k]??=[]).push(x)}for(const [href,a] of Object.entries(by)){const secs=[...new Set(a.map(x=>x.section))];if(secs.length>1)findings.push({severity:'FAIL',code:'CROSS_SECTION_ROUTE_REUSE',href,sections:secs,functions:a.map(x=>x.id)})}
const report={version:'v286',audit:'Role–Page–Flow Isolation Audit',rules:['one active role = one role workspace','manage down without silently switching role','switch sideways for personal roles','page owner + purpose + scope + actions + guide + return path must agree','shared components allowed; shared role identity is not','direct URL must retain page contract','cross-section registry route reuse is a hard failure'],counts:{html:files.length,inventory:inventory.length,fail:findings.filter(x=>x.severity==='FAIL').length,review:findings.filter(x=>x.severity==='REVIEW').length},findings,inventory};
fs.writeFileSync(path.join(ROOT,'V286-ROLE-PAGE-FLOW-ISOLATION-AUDIT.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report.counts));if(report.counts.fail)process.exitCode=2;
