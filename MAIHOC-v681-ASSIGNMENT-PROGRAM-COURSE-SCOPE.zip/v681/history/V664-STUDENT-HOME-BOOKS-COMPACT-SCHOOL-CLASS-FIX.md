# v664 — Student Home books + compact School English + class card repair

- Fixed Grade Book carousel boot failure: inline carousel code had accidentally been placed inside a `<script src=...>` element, so browsers ignored it.
- Removed stale `shotLevel` write that could stop the Student Home data bootstrap before class rendering.
- Kept one canonical Student Home: `student/home/home.html`.
- Replaced oversized School English marketing copy on logged-in Student Home with compact product header + red FREE stamp + Continue / All Grades actions.
- Grade 1–12 books now render one at a time with previous/next arrows and canonical character artwork; each book links to that Grade's Knowledge entry.
- Class card now renders available class name, teacher, next session, room/link and class count from existing student/class storage records; if no class exists, it shows an explicit empty state instead of remaining on “Checking…”.
- Did not alter public homepage demo, gameplay, movement, worlds, question content, Sage, or canonical Student Home route.

Static QA: extracted inline JS passed `node --check`; malformed external-script/inline-script boundary repaired; no `shotLevel` reference remains in Student Home.
