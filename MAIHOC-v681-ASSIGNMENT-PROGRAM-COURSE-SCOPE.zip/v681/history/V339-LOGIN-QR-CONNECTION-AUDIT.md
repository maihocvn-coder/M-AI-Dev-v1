# v339 Login + My QR Connection Audit

## Changes
- Login/register script now resolves form controls explicitly with `getElementById`; it no longer depends on browser-generated globals for element IDs.
- Existing demo login accounts and role-onboarding registration are preserved.
- Profile & Avatar now includes **Mã QR của tôi · My QR code**.
- QR reuses the existing M-AI QR generator and encodes a direct Connections URL with `?connect=...`.
- Opening a scanned link automatically opens the Add/Connect relationship chooser.
- Choices: **Học sinh của tôi**, **Giáo viên / gia sư của tôi**, **Bố mẹ / phụ huynh của tôi**, **Trung tâm / tổ chức của tôi**, **Bạn của tôi**.
- Friend connections use the existing peer path. Managed relationships create a pending request; the live backend should require acceptance before privacy/management permissions are granted.

## Validation
- Login inline JS syntax: PASS.
- Settings inline JS syntax: PASS.
- `maihoc-relationships.js`: PASS.
- Connections controller: PASS.
- Static flow assertions for login binding, Profile QR, direct QR route, and all five relationship choices: PASS.
- ZIP integrity: PASS.

No real browser click-through was claimed in this audit.
