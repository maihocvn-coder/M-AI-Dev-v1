# v370 — Grade 1 direct Level start

- Grade landing/orientation remains the single entry screen.
- Clicking **Play Level** now launches the selected level directly at question 1.
- Removed the second in-engine welcome/landing step for URLs launched with `start=1`.
- Default selected level remains Level 1, so a fresh Grade 1 visit → Play Level → Level 1 Question 1.
- Level Map can still select another level before Play Level.
- Knowledge/Practice/Test entry behavior remains unchanged.
