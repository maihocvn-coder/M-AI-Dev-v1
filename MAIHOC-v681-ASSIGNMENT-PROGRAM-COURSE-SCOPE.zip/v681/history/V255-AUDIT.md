# v255 audit

- Initial Level Play no longer opens on a blank Vocabulary question. All 12 grade engines use a welcome/orientation state first.
- Grade 6 question renderer no longer exposes the audited comparative teaching rule before the learner answers. Four leaking stimuli were moved to non-rendered `teachingNote`.
- IPA audio and word audio remain separate pipelines.
- The previous Wikimedia consonant demonstration mapping was removed because the samples can sound syllabic (for example /t/ perceived as “ta”).
- Approved vowel mapping is preserved.
- Consonant IPA playback now fails closed unless `MAIHOC_APPROVED_CONSONANT_AUDIO` supplies an explicitly reviewed isolated asset. It never falls back to TTS or the old demonstration mapping.
