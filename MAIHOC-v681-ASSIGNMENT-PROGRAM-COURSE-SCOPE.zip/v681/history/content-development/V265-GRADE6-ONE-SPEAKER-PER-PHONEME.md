# v265 Grade 6 — One speaker per phoneme

Knowledge Pronunciation now renders one audio control per phoneme row. Example words are text only because the approved phoneme recording already includes its example sequence. Individual example-word TTS/audio controls were removed from both the reference row and sound-group display. Question/Sage flows are unchanged.
