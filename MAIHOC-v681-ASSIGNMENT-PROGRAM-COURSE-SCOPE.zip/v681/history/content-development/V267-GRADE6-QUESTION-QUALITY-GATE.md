# V267 Grade 6 Question Quality Gate

Canonical Question Bank audit before activity rendering.

Hard checks implemented in `qa-grade6-question-quality-v267.js`:
- RESPONSE_FORM_MISMATCH
- META_QUESTION
- UNRESOLVED_META_REFERENCE
- MISSING_REQUIRED_CONTEXT
- ANSWER_LEAK
- AMBIGUOUS_ANSWER
- NO_CORRECT_ANSWER
- SKILL_TASK_MISMATCH

The gate audits all 1,680 Grade 6 canonical questions. V267 detected and repaired 40 prompts that claimed the choices were sentences while the choices were phrases/forms. The repair changes the prompt contract only; LO, options and correct answer are preserved.

Specific regression: G6U5-GRA-03/10/13/20 no longer say “Choose the sentence” for `some water / a water / some waters / a some water` choices.

Meta/unresolved-reference patterns such as “the rule”, “target grammar”, “target structure”, “grammar point”, “correct pattern”, and “intended form” are hard failures.

Release result after canonical repair: PASS, 0 hard failures under the implemented deterministic checks.
