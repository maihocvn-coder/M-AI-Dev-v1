# v673 Public Homepage i18n cleanup
- Public homepage defaults to English.
- Added EN / VI switch in public top navigation next to Log in / Sign up.
- Uses canonical `maihoc.ui.language` localStorage key.
- Removed the retired duplicate detailed Organization section.
- Updated homepage Teacher copy to current assign-only Learning Library flow (no teacher worksheet/test creation claim).
- Updated Organization homepage copy to Programs/Courses terminology.
- Authenticated language control remains in Profile; this public navigation switch is index-only.
