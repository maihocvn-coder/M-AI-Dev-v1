# M-AI Học v289 — Master Role + Subscription Flow

## Authority
Super Admin = govern platform. Management Admin = run business. Curriculum Admin = govern educational content. Organization Admin = run one organization. Academic Manager = academic oversight. Teacher/Parent/Student = personal workspaces.

Admins may create subordinate roles only from delegable permissions within their own scope. Reporting hierarchy is not permission hierarchy.

## Organization plans
- Starter: 3 Organization Admin seats; no Custom Staff Roles.
- Growth: 10 Organization Admin seats; Custom Staff Roles enabled.
- Pro: 20 Organization Admin seats; Custom Staff Roles enabled.
- Custom: configurable.
Management Admin may apply organization-specific entitlement overrides. Super Admin may configure the entire engine and all plan definitions.

## Access formula
ACCESS = role permission × scope × effective entitlement.

## Subscription
Free Launch = enforcement OFF. Architecture still supports plans/overrides. Individual: Public, Free, Plus/Family, Teacher Pro. Organization: Starter, Growth, Pro, Custom. Live classes / extra AI / storage / seats can be add-ons.

## Restore
Management Restore Center = ordinary content/resource/config revision restore. Super Admin System Recovery = emergency platform/config/migration recovery.
