# v656 Homepage + Student Home
- Public homepage hierarchy: Hero → M-AI School English → embedded real 10-question demo → How it works → other roles.
- Removed redundant hero mascot/game preview.
- Homepage demo reuses Grade 6 canonical School English runtime, forces Cat + Jump & Catch, excludes Pronunciation/Phonics, and selects only valid Vocabulary/Grammar/Listening/Reading items with Sage coaching contracts.
- Demo mode does not write last-played state.
- Sage remains the canonical in-game Sage panel.
- Public and Student mobile layouts recompose to one full-width section/card per row; no squeezed desktop cards.
- Public and Student navigation collapse to hamburger on phone.
- Student role home is now student/home.html and prioritizes M-AI School English before My Programs, Me & Sage, Wallet/Rewards.
