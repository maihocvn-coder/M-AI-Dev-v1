# V560 — Compact Feedback + Answer Holder Idle Motion

- Restores feedback to a compact centered card: max 360 px wide, ~78 px minimum height.
- Keeps neutral translucent navy glass so feedback remains legible across different game worlds without covering the scene.
- Adds a reusable `.mh-answer-holder-visual` contract for answer-holder artwork.
- Grade 1 fish now uses that generic visual class and receives a subtle continuous swim/hover motion.
- Motion preserves the fish's facing direction and uses only small translate/rotate changes so the answer target does not wander away from its answer badge.
- Future answer-holder artwork should use `.mh-answer-holder-visual`; no fish-specific animation engine is required.
- `prefers-reduced-motion` disables the idle animation.
- No changes to question data, answer logic, rewards, Sage, movement controls, or MainScreen liquid measurement.
