# v569 — Liquid profile/media/game chrome refinement

- Moved VN/EN language control into the shared profile menu; it no longer occupies persistent header space.
- Added canonical proportional media rules in `assets/css/maihoc-responsive.css` so homepage visual/media elements scale with their containers across medium/narrow/phone states.
- Reflowed homepage feature strip 5 → 3 → 2 → 1 columns to prevent clipped imagery/text.
- On compact School English game layouts, all chrome above Adventure Bag yields to the site curtain handle: persistent brand/profile/breadcrumb/level title are hidden and site navigation opens as an overlay.
- Mobile School English side control is hamburger-only; “Học & Chơi” remains an accessible title/meaning, not visible text.
- No new responsive stylesheet or responsive JS authority was added.
