# V291 Promotion Functional Repair

Promotion controls now have explicit behavior for Save Draft, Save & Activate, Cancel, Edit, Pause/Activate, Duplicate, History, Archive, campaign equivalents, and Super Admin Governance Save. Promotion data persists in localStorage under v291 with migration fallback from v290. Edits create revisions; duplicates create Draft records; archive is soft status change; history reads audit records; governance remains Super Admin-only.

Whole-site control audit inventory is in V291-FUNCTIONAL-CONTROL-AUDIT.json. Static evidence is not treated as browser proof.
