# v388 Grade 1 Continue + Semantic Asset Audit

- Student Home **Continue Playing** now always opens the saved Grade/Level in `mode=play` directly. It no longer restores a stale Knowledge/Practice/Test mode.
- Grade 1 resume starts at Question 1 and suppresses the welcome/orientation card.
- Hardened question-change initialization so listeners are not called with an undefined question before the question UI is rendered.
- Audited all **63 distinct Vocabulary option labels** currently used by the Grade 1 bank. Every one now has an explicit local semantic SVG asset.
- `desk` now uses a purpose-built desk drawing (not the chair emoji). `door` uses a door visual (not sparkle fallback).
- Vocabulary game cards use one consistent local SVG visual system and stable text→asset slug binding.
- No Grade 1 vocabulary option in the current bank depends on the generic sparkle fallback.

Audited labels: Lucy, Nick, Wendy, apple, bag, ball, bananas, bell, bike, book, bus, cake, can, car, cat, chicken, chips, clocks, cup, desk, dog, door, duck, face, father, fish, foot, football, garden, gate, girl, goat, hair, hand, hat, head, horse, lake, leaf, lemons, locks, mango, milk, monkey, mops, mother, mouse, noodles, nuts, pen, pencil, pots, red, running, sun, teddy bear, tiger, top, truck, turtle, washing, water, window
