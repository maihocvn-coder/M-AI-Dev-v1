# v266 Grade 6 Pronunciation Source-Words Render Audit

- Unified vowel + consonant Knowledge renderer contract.
- Every Grade 6 phoneme target in Units 1–9 must resolve to source audio + source example words.
- Complete source example list is rendered; renderer does not invent or substitute words.
- Exactly one speaker per phoneme reference row; no per-word speakers; button does not repeat IPA.
- Hamburg source aliases preserve curriculum notation: /iː/ ↔ Hamburg /i:/ row, /e/ ↔ Hamburg front-vowel /e/ row, /əʊ/ ↔ Hamburg American /oʊ/ row.
- /ɑː/ uses a separate source explicitly publishing /ɑː/ audio with examples car, start, father because Hamburg's /ɑ/ row exposes no audio URL.
- Units 10–12 are prosody (stress/rhythm/intonation), not phoneme rows.
