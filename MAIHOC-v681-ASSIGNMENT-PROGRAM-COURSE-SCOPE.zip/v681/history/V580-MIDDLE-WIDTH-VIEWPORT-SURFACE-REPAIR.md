# v580 — Middle Width Viewport Surface Repair

## Symptom
At a middle browser width, the Grade 1 game rendered inside a narrow ~desktop-journey-width strip on the left while the rest of the viewport stayed blank. Full desktop and phone endpoints worked.

## Root cause
The compact/tablet profile correctly converted the game workspace to one logical cell, but the workspace itself could still participate as an intrinsic-width item in the legacy desktop shell. The legacy School English shell owns a 300–410px journey column and uses `display: contents` for the game page wrapper. During the transition envelope this allowed the compact game cell to inherit a narrow containing width even though its internal grid was one column.

## Repair
The canonical responsive authority now treats tablet/phone Play workspace as the viewport surface:
- `.layout` is fixed to `inset: 0`
- width is `100vw`, height is `100dvh`
- no max-width/intrinsic-width constraint
- Level Map remains an off-canvas drawer
- breadcrumb/curtain and Học & Chơi controls remain floating HUD
- Game/MainScreen receives the full compact viewport width

No question, curriculum, Sage, reward, movement, audio, or game-engine logic changed.
