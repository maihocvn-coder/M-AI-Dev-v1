# V300 Rename + Subscription Plan UX Audit

## Global rename
- Canonical display name: **M-AI School English**.
- Replaced visible/source-data occurrences of `My School English` and uppercase variants across HTML, JS, JSON, PHP, Markdown, text and data files.
- Route/folder identifiers such as `student/my-school-english/...` were intentionally preserved so existing links do not break.
- Remaining old display-name files: 0.

## Subscription plan UX
- Organization Plans and Individual Plans now use the same table/action pattern.
- Every plan exposes **Edit** and **Publish**.
- Edit opens a detailed plan editor with numeric fields and feature checkboxes.
- **Save Draft** persists edits as draft.
- **Publish** publishes the current edited definition.
- Student and Parent paid/future plans remain modeled but OFF by default.
- Organization assignment/override remains separate from plan-definition editing.
- Plan draft saves, publishes and organization overrides write audit history.
- Existing v289/v241 subscription state is read as migration fallback.

## Checks
- Subscription JS syntax: PASS.
- Subscription inline JS syntax: PASS.
- Broken relative href/src targets on subscription page: 0.
