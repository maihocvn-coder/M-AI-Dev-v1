# v676 — Teacher Library visual preview + Open viewer

- Replaced text-only hover placeholder with lazy-loaded visual material preview.
- Game/worksheet/test cards now render their canonical material URL inside the hover preview when a real viewer exists.
- Open now launches the same canonical material in a large teacher preview viewer.
- Teacher preview adds preview=1 and teacherPreview=1; it does not create/copy the material.
- Assign remains a separate canonical assignment flow.
- CEFR entries no longer loop back into Teacher Library. Until a canonical student-facing CEFR viewer exists, the UI states that explicitly rather than inventing a fake preview.
