# V392 — Grade 1 Question Sage regeneration

Scope: all 960 Grade 1 question records.

## Root causes fixed
1. Question Sage could render stale Knowledge Sage because `MAIHOC_KNOWLEDGE_CONTEXT` survived after leaving Learn.
2. Grade 1 Sage bank had no per-question `sageCoach` contract; the shared panel therefore fell back to generic or LO-level coaching.
3. Runtime had no hard invariant preventing a stale question from a previous Level being rendered under the newly selected Level title.

## Regeneration contract
Every Grade 1 question now owns:
- three question-bound hints;
- `sageCoach.binding = question-id`;
- exact `questionId`;
- tested distinction;
- question-bound Ask More prompts/answers;
- no unrelated lesson example injection.

Closed-choice hints explicitly bind to the choices on the current question. Audio-choice Vocabulary coaching tells the learner how to compare the actual audio and actual options without revealing the answer. Phonics coaching distinguishes letter recognition from verified phoneme work. Sentence Pattern coaching is tied to the current prompt/options.

## Runtime gates
- In Grade 1, an active question always takes precedence over stale Knowledge context.
- `maihoc:questionchange` clears Grade 1 Knowledge context.
- `render()` clears Knowledge context outside Learn.
- If `current().unit !== state.unit`, the queue is rebuilt from the active Level before rendering.

## Automated audit
- Grade 1 questions checked: 960
- questionId binding failures: 0
- empty `//` Sage output: 0
- closed-choice Hint 2 option-binding failures: 0
- JS syntax checks: PASS
