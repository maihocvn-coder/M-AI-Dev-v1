# V270 Grade 6 Whole-Item Semantic Audit

## Scope
Canonical Grade 6 Question Bank: 1,680 items. Baseline: v269.

## Audit flow
Structure → Prompt/Answer Contract → Entity & Referent Consistency → Scenario Coherence → Natural English → Answer Integrity → Distractor Quality → Sage Consistency → LO/Knowledge Alignment → Repair → Re-audit.

## New hard gates
- ENTITY_ROLE_MISMATCH
- STALE_TEMPLATE_CONTEXT
- DECORATIVE_CONTEXT
- META_OR_UNRESOLVED_REFERENCE
- UNNATURAL_KEYED_ANSWER
- GENERIC_SAGE_COACHING
- AMBIGUOUS_ANSWER (existing gate retained)

## Repairs
- Repaired all 240 Grade 6 Grammar prompts that used generic `fits the situation` templates to unit-grounded, entity-neutral contexts unless a real entity relationship is explicitly established.
- G6U2-GRA-01 now establishes Lan/Nam relationship explicitly: Lan shows Nam her bedroom; Nam identifies Lan's room.
- Replaced generic Grammar Sage stock hints with unit/target-specific coaching.
- Removed obvious synthetic garbage distractors (e.g. `nows`, `todays`, `energys`, `houseworks`, `switchess`) and re-ran duplicate/ambiguity checks.
- Synced canonical and runtime question-bank copies and regenerated `engine/bank-data.js`.

## Regression results
- Whole-item semantic gate v270: PASS, 1,680 items, 0 hard failures.
- Question Quality Gate v267: PASS, 1,680 items, 0 hard failures.
- Knowledge Sage v269: PASS, 84 lessons / 356 concepts / 0 hard failures.
- Runtime flow v268: PASS.
- Runtime contract v259: PASS, 12 levels / 7 skills / 1,680 questions.
- JS syntax: PASS.

## Limitation
These are deterministic/static/runtime-contract checks. No claim of browser click E2E or acoustic audio verification is made by this audit.
