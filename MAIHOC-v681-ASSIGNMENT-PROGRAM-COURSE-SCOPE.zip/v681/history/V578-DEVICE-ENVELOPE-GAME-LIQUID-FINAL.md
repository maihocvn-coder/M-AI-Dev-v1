# V578 — Device-envelope game liquid final

## Flow decision

One responsive authority remains: `assets/js/maihoc-responsive.js` + `assets/css/maihoc-responsive.css`.

Game uses three viewport envelopes, based on the live viewport rather than user-agent detection:

- Desktop: normal wide landscape workspace; Journey/sidebar and title row may remain visible.
- Tablet: iPad-sized / compact / near-square viewport; all chrome above Adventure Bag collapses to floating controls; game occupies the full remaining viewport.
- Phone: handset-width viewport; same game-first frame as tablet with phone component sizing.

## Geometry

Compact tablet/phone flow:

1. Site header row reserves 0 height.
2. Breadcrumb/title/footer reserve 0 height.
3. Hamburger and curtain arrow float above the game and do not participate in layout.
4. Adventure Bag remains the first persistent game HUD row.
5. Question + answer holders grow from the top.
6. World is the flexible middle region.
7. Character + controller are one bottom HUD stack.
8. Controller hugs the bottom safe edge; character stands immediately above the controller row.
9. Sage remains an independent bottom-right floating HUD.

Desktop flow is unchanged: the two-column Journey + MainScreen shell remains available and the bottom HUD stays at the bottom of MainScreen.

## Root cause fixed

The previous compact layout changed `.layout` to `display:block` while `.game-shell` still had `height:100%`. That allowed hidden/preceding shell content and the 100%-height game to combine into a page taller than the visible viewport. The bottom HUD was correctly anchored to the game bottom, but that bottom was below the screen, so the character/controller appeared clipped or missing.

V578 replaces that compact layout with a one-cell grid whose game shell is exactly the available viewport cell.

## QA targets

- 1600×900 desktop: desktop shell, character/controller at game bottom.
- 1366×1024 / 1024×1366 iPad-class: game-first compact frame, no title/breadcrumb height, bottom HUD visible.
- 390×844 phone-class: game-first compact frame, bottom HUD visible, Sage floating.
- Near-square resized desktop windows up to iPad-class envelope use the compact game-first frame rather than stretching desktop geometry.
