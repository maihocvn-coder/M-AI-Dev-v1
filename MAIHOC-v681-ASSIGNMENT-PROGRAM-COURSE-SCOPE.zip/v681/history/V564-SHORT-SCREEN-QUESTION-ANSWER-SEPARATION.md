# V564 — Short-screen question/answer separation

- Enlarges Grade 1 fish answer-holder artwork without enlarging the answer payload.
- Establishes separate vertical bands for question and answer holders.
- On short/medium MainScreen heights, question moves upward while answer lane remains below it.
- Prevents question card from overlapping fish/answer payloads during liquid height reduction.
- No question-bank, reward, Sage, movement, mode, or curriculum changes.
