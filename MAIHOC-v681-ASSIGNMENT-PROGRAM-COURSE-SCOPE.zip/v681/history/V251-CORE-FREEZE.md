# v251 Core Freeze Hardening
Added mutation gateway with production fail-closed behavior, server-authoritative wallet/subscription contracts, idempotent wallet commands, extension capability preflight/runtime API, and production DB/API contract. Local/demo adapters remain for localhost QA only.
Backend launch requirements remain: durable server DB, server-side authorization on every mutation, real payment provider/webhooks, automated backup/PITR, restore drills, secrets management, TLS/CSP and monitoring.
