# V314 VI/EN UI Translation Repair Audit

## Purpose
Repair v313 where the language selector changed state but much of the visible UI did not translate.

## Implementation
- VI remains the default UI language.
- VI/EN preference persists in localStorage (`maihoc.ui.language.v314`).
- Translation now applies to exact-match UI text nodes, not only bare buttons/links/options.
- Dynamic DOM additions are re-audited by the guarded MutationObserver.
- Learning/resource/authored content remains outside the translation layer.

## Protected-content gate
Compared 287 JSON/MD/TXT/CSV files against v313: **0 changed**.

Protected selectors include resource, learning content, Knowledge, question/options/answers, explanations, Sage, curriculum/LO, transcripts, authored website content, code/pre/textarea/contenteditable. Learning-resource/content routes also protect main content.

## Static regression checks
- HTML pages carrying v314 i18n runtime: **378/378**
- Default VI: PASS
- Exact UI text-node translation: PASS
- VI/EN persistence: PASS
- Protected content unchanged: PASS
- JS syntax (`node --check`): PASS

## Important limitation
This is a static/runtime-code audit. No Playwright/browser package is installed in the current execution environment, so this report does not claim a real-browser click test. The release should be manually smoke-tested through login and at least Student, Teacher, Organization Admin, and Super Admin pages.
