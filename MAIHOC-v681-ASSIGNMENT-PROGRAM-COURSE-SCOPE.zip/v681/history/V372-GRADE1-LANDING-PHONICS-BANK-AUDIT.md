# v372 Grade 1 landing + phonics bank semantic repair

- Restored the Grade 6-style orientation landing for every external Grade 1 game entry, including Student Home links that already carry `?level=1&mode=play`.
- Internal Level Map clicks still bypass the orientation landing and open the selected level's first question directly.
- Audited all 960 Grade 1 bank records for answer-index validity and duplicate choices.
- Audited all Phonics items whose prompt claims an initial letter against the keyed correct answer.
- Found 40 false initial-letter items: all Unit 5 `Ii` practice/test items and all Unit 6 `Ee` practice/test items.
- Repaired Unit 5 to test the short /ɪ/ sound (chicken/chips/fish/milk) instead of falsely claiming those words begin with I.
- Repaired Unit 6 to test /e/ (bell/pen/pencil/red) instead of falsely claiming those words begin with E.
- Updated tested distinction, Sage hints, explanation, revision/version, canonical question bank, engine bank JSON, and runtime `bank-data.js` together.
- Automated validation after repair: 960 items, zero invalid answer indexes, zero duplicate-option items, zero remaining initial-letter mismatches.
