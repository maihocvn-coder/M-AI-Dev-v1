# v669
- Homepage hero embeds the actual canonical Grade 1 play page in public preview mode.
- Public preview bypass is narrowly limited to Grade 1 play.html with preview=1.
- Preview mode hides authenticated shell/rail while retaining the canonical game runtime, world, carriers, movement/controller and Sage.
- Removed standalone Sage homepage section and integrated Sage AI Learning Companion content into For Students.
