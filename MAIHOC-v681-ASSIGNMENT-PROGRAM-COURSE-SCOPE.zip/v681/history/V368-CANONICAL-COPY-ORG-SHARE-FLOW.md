# v368 — Canonical Copy → My Library → Organization Share

- Removed canonical `Open in new tab` from School English full preview.
- Canonical M-AI resources have one acquisition route: `Copy to My Library`.
- Removed `Copy to Organization Library` and `Assign as-is` actions from canonical resource surfaces in Resource Studio.
- Copy button hover/focus explains: `You must copy before you can assign or edit.`
- Organization Admin / Super Admin My Library cards/rows expose an `Organization Library` checkbox.
- Checking shares the same My Library resource by reference (`sharedOrganizationIds`) instead of creating a second copy.
- Unchecking removes the reference from Organization Library.
- Organization Library includes legacy organization-owned resources plus My Library resources explicitly shared to the active organization.
- Teacher and Admin resource pages cache-busted to v368.
