# V354 — All Resource Surfaces Audit

## Goal
Ensure the M-AI CEFR canonical resources are available everywhere the platform exposes the canonical Resource Library, alongside M-AI School English.

## Canonical CEFR inventory verified
- M-AI CEFR Question Bank: 420 questions
- M-AI CEFR Level Tests: 7 tests (Pre-A1, A1, A2, B1, B2, C1, C2), 20 questions per level test
- M-AI CEFR Worksheets: 70 worksheets (10 per CEFR level), 10 questions per worksheet
- M-AI School English Question Bank remains a separate canonical bank.

## Resource surfaces audited and repaired
1. Super/Management Admin → Learning Resources
   - M-AI School English and M-AI CEFR collections are both present.
   - Question Banks, Tests and Worksheets can be filtered to M-AI CEFR.
2. Organization Admin → Resources
   - Loads CEFR canonical data before Resource Studio.
   - Platform source now exposes M-AI CEFR Question Bank, all 7 CEFR tests and all 70 CEFR worksheets.
3. Teacher → Resources
   - Loads the same CEFR canonical data before Resource Studio.
   - Platform source exposes the same CEFR bank/tests/worksheets.
4. Super Admin → Platform Resources
   - Loads CEFR canonical data and lists the CEFR resources under Question Banks / Tests / Worksheets.
5. Admin → Question Bank
   - Added an explicit route to the M-AI CEFR canonical bank in Learning Resources so the second bank is discoverable.

## Naming
- User-facing collection name is `M-AI School English`; the internal identifier `gamebook-mse` is not used as the visible collection label in the active Learning Resources UI.
- School bank is `M-AI School English Question Bank`.
- CEFR bank is `M-AI CEFR Question Bank`.

## Shared resource registry repair
`maihoc-scope-access.js` now merges the CEFR canonical tests and worksheets into the platform resource registry whenever the CEFR canonical data assets are loaded. This also repairs existing localStorage installations: missing canonical CEFR resources are re-added rather than relying on a fresh browser profile.

## Preview / routing repair
- CEFR tests and worksheets have meaningful canonical previews in Resource Studio.
- Teacher CEFR actions route to the unified Test Builder / Worksheet Builder.
- Admin CEFR bank navigation routes to Learning Resources rather than a non-existent admin CEFR page.

## Verification performed
- JS syntax: PASS (`maihoc-scope-access.js`, `maihoc-resource-studio-v209.js`, `learning-resources-v301.js`).
- Canonical data counts: PASS (420 questions, 7 tests, 70 worksheets; 10 worksheets at every CEFR level).
- Shared scope registry with mocked storage: PASS (1 CEFR bank, 7 CEFR tests, 70 CEFR worksheets; School English bank name correct).
- CEFR data assets included on all four canonical Resource Library surfaces: PASS.
- ZIP integrity: checked at release packaging.

## Limitation
No browser automation runtime was available for a full click-through E2E test, so this release does not claim browser E2E verification.
