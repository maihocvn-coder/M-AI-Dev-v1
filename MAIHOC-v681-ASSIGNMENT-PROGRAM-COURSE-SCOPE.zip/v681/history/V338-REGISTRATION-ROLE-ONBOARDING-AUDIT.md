# v338 Registration Role Onboarding Audit

- Registration now uses four visual role cards: Student, Teacher & Tutor, Parent, Organization.
- Signup selects one primary role only; copy explains that additional roles can be added/switched later.
- Homepage audience CTAs deep-link to registration with role preselected via `?role=...#register`.
- Organization is an onboarding intent, not a stored peer role: local demo records `primaryRole: admin` and `createOrganization: true`.
- Existing login flow and demo account flow retained.
- Static role/link assertions: PASS.
