# v478 Grade 1 Unit 1 — Restore Game World

Scope is intentionally narrow.
- Question remains inside Game World; legacy #interaction is runtime-only and removed from layout.
- Removed obsolete game-screen resize divider from Grade 1 DOM/layout.
- Restored Sage as a floating Game World control and overlay.
- Kept existing question bank, fish answer carriers, Adventure Bag, coins, reward/mastery, Learn and navigation.
- Kept only the new player character + movement layer from the prototype.
