# V606 — Character Action Progression / Controls Audit

## Audit before change
- `character-movement.js` was the active keyboard authority, but only exposed left/right/jump.
- `game-config.js` selected engine/world/character but had no level-level action contract.
- `game-ui-runtime.js` hard-coded Left / JUMP / Right controls, so controls could not follow a level's allowed actions.
- There was no persistent keyboard help affordance or action-combination guide.

## Consolidation / replacement
- Kept one character movement authority: `assets/js/game/character/character-movement.js`.
- Replaced hard-coded control contents in `game-ui-runtime.js` with an empty canonical control mount; the character authority now renders controls from level config.
- Extended the existing canonical controls CSS block in place; no version-specific override stylesheet was added.
- Added `enabledActions` to canonical `MAIHOC_GAME_CONFIG.get()` with a gradual 12-level progression. Saved/assigned config may override it later per Unit.

## Character capability library
`walk, jump, fly, climb, swim, dive, carry, push, swing`.
The character can own all capabilities while each level enables only a subset.

## Default gradual progression
1 walk+jump; 2 walk+fly; 3 walk+climb; 4 swim+dive; 5 walk+carry; 6 walk+swing; 7 walk+jump+climb; 8 walk+fly+carry; 9 swim+dive+carry; 10 walk+jump+push+carry; 11 walk+jump+climb+carry; 12 mixed.

## Keyboard / help
- Horizontal: Left/Right or A/D.
- Contextual primary vertical key: Up/Space/W performs the level's jump, fly, or climb action.
- Dive: Down/S. Carry: C. Push: P. Swing: G.
- Held horizontal input remains active during jump, so Up+Right and Up+Left are real combined inputs.
- A separated `⌨ ?` button opens the current level's Controls Guide. It is outside the action-button group to reduce accidental opening while pressing Jump.
- The guide only lists actions enabled for the current level.
