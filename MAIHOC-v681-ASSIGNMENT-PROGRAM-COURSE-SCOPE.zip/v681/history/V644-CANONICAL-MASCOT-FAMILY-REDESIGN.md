# v644 Canonical Mascot Family Redesign

## Scope
Redesign the built-in Grade 2–12 characters in code so they belong to the exact same visual family as the canonical Grade 1 cat. No image generation and no alternate generic chibi renderer.

## Canonical style contract
- 120x140 SVG viewBox, matching Grade 1 cat.
- Same warm dark outline (#74411f), navy eyes (#173a58), flat fills, simple limbs, friendly expression.
- Species identity is carried by silhouette and markings rather than a shared bean-shaped body.
- Grade 1 cat SVG is retained as the reference implementation.

## Unique identity features
- G1 Cat: triangle ears, whiskers, curled tail.
- G2 Bunny: very long upright ears, pink inner ears, cotton tail.
- G3 Otter: round ears, cream muzzle/belly, broad swimming tail.
- G4 Red Panda: pointed ears, white face mask, striped ring tail.
- G5 Panda: black ears, black eye patches, black legs.
- G6 Corgi: oversized upright ears, white facial blaze, short legs.
- G7 Penguin: flippers, white bib, orange beak/feet.
- G8 Fox: tall pointed ears, angular white muzzle, white tail tip.
- G9 Monkey: large round ears, tan face, curled tail.
- G10 Koala: large fluffy ears, dark oval nose.
- G11 Bear: compact round ears, broad tan muzzle, stockier stance.
- G12 Capybara: small high ears, long rectangular muzzle, tailless silhouette.

## Authority cleanup
The previous generic `chibi(id)` renderer was removed. Built-in characters now resolve through one `builtins` character renderer map. Admin custom uploaded characters still resolve through the existing registry image path.
