# v643 — Grade Character Library + Admin Assignment

- One shared character library for School English gameplay.
- Grade defaults: G1 Cat, G2 Bunny, G3 Otter, G4 Red Panda, G5 Panda, G6 Corgi, G7 Penguin, G8 Fox, G9 Monkey, G10 Koala, G11 Bear, G12 Capybara.
- Grade 1 Cat preserves the existing canonical cat SVG.
- Other characters use the same rounded chibi visual language.
- Gameplay no longer hard-codes cat artwork: character-movement resolves `characterId` from `MAIHOC_GAME_CONFIG.resolve(context)` and renders through `MAIHOC_GRADE_CHARACTER`.
- Admin Game Setup remains the selection authority: saved `characterId` overrides grade default and repaint occurs on `maihoc-game-setup-change`.
- Character choice does not alter movement/contact/reaction algorithms.
