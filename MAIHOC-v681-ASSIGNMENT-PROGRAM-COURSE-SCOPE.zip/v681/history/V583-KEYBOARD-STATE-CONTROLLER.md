# V583 — Keyboard State Controller

- Replaced one-shot window keyboard action handling with one canonical document capture-phase keyboard state controller.
- Arrow keys are normalized primarily by `event.code`, with standards and legacy key-name fallbacks (`ArrowRight` / `Right`, etc.).
- Left/right use held-key state plus `requestAnimationFrame`; keyup clears state.
- Horizontal movement is now allowed while jump animation is active, enabling diagonal jump/fly movement.
- On-screen controller still uses the existing `performAction()` authority.
- Input, textarea, select, and contenteditable targets remain exempt.
- Blur/hidden page clears held state to prevent stuck movement.
