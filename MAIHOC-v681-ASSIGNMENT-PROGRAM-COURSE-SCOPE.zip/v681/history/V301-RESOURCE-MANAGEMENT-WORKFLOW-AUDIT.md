# V301 Resource Management Workflow Audit

## Implemented
- Resource Browser now opens as the active workspace (cards hidden) with breadcrumb/header and Back to Resource Library.
- Browser defaults to All filters and renders real canonical M-AI School English question-bank records.
- Canonical question export is enriched from grade question-bank JSON files, including prompt/stimulus, choices, answer, explanations, Sage hints/Sage Coach, audio/media refs, LO, status, revision and source.
- Resource table includes checkbox, Preview, Name/Content, Location, Type, Items, Status, Updated and 3-dot Actions.
- Multi-select Download supports Excel-readable XLS, JSON, CSV, JS script and human-review HTML.
- Preview exposes full question data and direct Edit / Approve / Download actions.
- Bulk flow is Find → Show actual resources → Select → Download or Update → Replace Existing/Create New → Validate & Compare → Confirm → Snapshot → History/Restore.
- Replace keeps selected resources missing from the incoming file unchanged; no silent deletion.
- Update requires a reason and creates history snapshots.
- JSON and CSV re-import are supported; pasted JSON script is supported.
- M-AI School English remains a Game Book collection and all active site/source naming uses M-AI School English.
- Existing per-type sample files remain wired for Worksheets, Tests, Slides, Games, Learning Materials, Game Books and Workbooks; Question Banks use real canonical sample questions.

## QA
- `node --check admin/learning-resources/learning-resources-v301.js` passes.
- Resource page references v301 controller and full canonical resource index.
- Legacy visible `My School English` name is absent from active site/source files; only the historical v300 audit note contains the old phrase as documentation.
