# v348 — M-AI CEFR Level Tests

- Renamed canonical School English bank to **M-AI School English Question Bank**.
- Added 7 canonical ready-made M-AI CEFR level checks under Teacher → Tests: Pre-A1, A1, A2, B1, B2, C1, C2.
- Each test contains exactly 20 questions from the same CEFR level in the M-AI CEFR Question Bank.
- Current level-check mix: Vocabulary, Grammar, Reading and Integrated Communication.
- Tests are labelled indicative and are not represented as official CEFR certification.
- Added 140 level-specific approved level-check questions to the CEFR bank so the tests do not reuse the earlier generic seed items across levels.
- Internal QA metadata remains hidden from user-facing test cards.
