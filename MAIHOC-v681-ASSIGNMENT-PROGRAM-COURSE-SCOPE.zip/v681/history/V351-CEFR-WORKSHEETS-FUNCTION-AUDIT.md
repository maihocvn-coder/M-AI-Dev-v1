# v351 CEFR Worksheets + Create Worksheet Functional Audit

- Added 70 premade M-AI CEFR worksheets: 10 per level (Pre-A1, A1, A2, B1, B2, C1, C2).
- Every premade worksheet contains exactly 10 canonical M-AI CEFR question references.
- Every level includes W01–W10 once: Classic Practice, Picture Practice, Match & Sort, Vocabulary Builder, Pronunciation Lab, Grammar Builder, Reading Explorer, Listening Mission, Writing Workshop, Mixed Skills/Test Style.
- Worksheet Library loads the premade CEFR set alongside existing School English premade resources and teacher-created worksheets.
- Create New Worksheet is now one unified flow with two curriculum sources:
  - M-AI School English Question Bank: Grade → Unit → Learning Objective.
  - M-AI CEFR Question Bank: Level → Skill → Content Target.
- Teacher selects curriculum, not individual questions. The builder resolves 10 questions from the canonical bank.
- Added template W01–W10 picker, theme, title, time, Generate, Preview, Save, Assign, Print, Cancel.
- QA metadata is not rendered in learner/teacher worksheet question cards.
- Static validation: 70 worksheets; 10/level; 10 unique question IDs/worksheet; all question IDs resolve; W01–W10 coverage/level PASS.
- JavaScript syntax check PASS.
- ZIP integrity PASS after packaging.
- Browser click-through was not run in this environment; do not treat static/runtime syntax checks as browser E2E proof.
