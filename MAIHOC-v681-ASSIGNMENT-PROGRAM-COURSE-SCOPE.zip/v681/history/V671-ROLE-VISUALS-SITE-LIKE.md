# v671 Role visuals
- Rebuilt public role visuals to resemble the actual M-AI Học product UI instead of generic promo cards.
- Student: Sage coaching inside a question card.
- Teacher: Worksheet Library preview with a worksheet and Assign action, based on Teacher Workspace terminology.
- Parent: current learning, assigned work, latest score and recent activity.
- Organization: Teacher Management dashboard with teachers/classes/students and activity status.
- No role backend/runtime behavior changed; homepage visual/promo only.
