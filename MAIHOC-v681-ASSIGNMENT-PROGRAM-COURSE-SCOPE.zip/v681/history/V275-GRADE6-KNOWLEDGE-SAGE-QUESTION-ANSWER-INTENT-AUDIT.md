# v275 Grade 6 Knowledge Sage — Question/Answer Intent Audit

- Replaced positional/generic Hỏi thêm answers with explicit `exploreQA` records.
- Each record contains `question`, `intent`, and `answer`.
- Runtime renders the answer attached to the selected semantic question; it no longer maps Grammar questions to a generic `[explain, explain, example, notice]` array.
- Intent gate covers DEFINITION, WHEN_TO_USE, FORM, EXAMPLE, COMMON_MISTAKES, CONTRAST, MEANING, PRONUNCIATION, LISTENING_FOCUS, READING_DETAIL, SPEAKING_MODEL, WRITING_MODEL, and USE.
- COMMON_MISTAKES Grammar answers must contain a concrete wrong form and correction.
- Regression: “Em thường mắc lỗi gì khi dùng Present Simple?” now lists concrete Present Simple errors and corrections.
- Knowledge Quiz remains semantic/fail-closed from v274. Free-text Knowledge Ask remains removed. Question Sage and Question Bank are not rewritten.
