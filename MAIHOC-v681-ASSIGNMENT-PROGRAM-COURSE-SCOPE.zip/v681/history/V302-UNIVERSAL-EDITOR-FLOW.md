# M-AI Học v302 — Universal Editor

All resource edit entry points use one editor shell with Visual / Content Editor, Script Editor, and Preview.

Resource editor fields include identity, curriculum mapping, question/content, stimulus, choices, correct answer, explanations, Sage steps, full Sage Coach JSON, question type, difficulty, engine, pool, knowledge target, status, audio/phoneme media, image/media, and YouTube embed.

Visual and Script modes edit the same working object. Switching away from Script parses JSON and repopulates Visual fields. Visual edits continuously regenerate the JSON representation.

Workflow: Edit → Visual/Script → Validate → Preview → Save Draft / Save & Review / Publish. Publish writes the governed override used by the current local package and creates Resource History snapshots. Resource Audit Edit and Preview→Edit are routed to the same editor.

Media uploads are represented as data URLs in the browser-local governed override so they can be previewed immediately in the local package. Server-side canonical-file writes remain a deployment/backend responsibility; the editor does not falsely claim direct filesystem writes from a static browser page.
