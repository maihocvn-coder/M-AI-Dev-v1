# V291 Functional Control Audit

Visible control ≠ completed function. PASS requires action, state change, persistence/rollback where applicable, permission/scope, and reload behavior.

- version: v291
- scope: whole-site actionable button static audit
- html_pages: 372
- buttons_total: 530
- action_buttons: 188
- wired_static: 124
- review_required: 64
- note: Static evidence only. Browser execution was attempted but environment blocked Chromium navigation; REVIEW_REQUIRED is not automatically a broken button.

Promotion flow controls were repaired and source-verified in v291. Browser interaction execution was attempted with Chromium but blocked by the execution environment, so this report does not claim whole-site browser PASS.
