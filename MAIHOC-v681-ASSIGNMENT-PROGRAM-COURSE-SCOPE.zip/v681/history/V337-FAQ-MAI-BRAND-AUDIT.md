# v337 FAQ / M-AI brand audit

- FAQ heading updated to “Một vài câu hỏi quan trọng · M-AI School English”.
- Global Success questions now refer specifically to M-AI School English.
- Added “M-AI có các học liệu khác không?” with free + optional paid expansion answer.
- General ecosystem wording in the FAQ uses “M-AI”, not “M-AI Học”.
- No `M-AI Học` / `M‑AI Học` remains inside the FAQ section.
- This patch intentionally targets the FAQ wording requested; other public-site brand copy is unchanged.
