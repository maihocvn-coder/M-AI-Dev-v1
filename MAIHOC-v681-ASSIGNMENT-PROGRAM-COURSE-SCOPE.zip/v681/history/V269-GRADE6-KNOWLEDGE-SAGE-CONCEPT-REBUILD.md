# v269 Grade 6 Knowledge Sage Concept Rebuild

- Baseline: v268.
- Scope: Knowledge Sage only; Question Sage tail preserved byte-for-byte.
- Replaced Unit/Skill-level Knowledge Sage bank with 356 concept-level records across 84 lessons and 7 skills.
- Binding key: gradeId + unitId + skill + loId + knowledgeSectionId + conceptId.
- Knowledge renderer can bind Sage to individual concept containers via click/focus.
- Knowledge Sage actions: Explain, Another Example, Notice, Common Mistake when applicable, Quick Check.
- Anti-meta gate rejects unresolved/meta coaching and exact Question Bank prompt reuse.
- Question Sage content/runtime functions from pronunciationHint onward are unchanged from v268.

QA:
- Knowledge Sage: 356 concepts, 84 lessons, 7 skills, 0 hard failures.
- Question Quality Gate: 1,680 questions, 0 hard failures.
- Runtime flow: PASS.
- Runtime contract: 12 levels, 7 skills, 1,680 questions PASS.
- JS syntax: 139 files, 0 failures.
