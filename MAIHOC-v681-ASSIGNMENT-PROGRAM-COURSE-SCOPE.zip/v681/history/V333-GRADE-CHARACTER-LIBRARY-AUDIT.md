# v333 Grade Character Library Audit

## Scope
- Public `index.html` M-AI School English 12-grade carousel.
- Logged-in `student/my-school-english/home.html` 12-grade selector.
- Reuse the exact chibi character renderer and canonical Grade 1–12 default mascots from the game system; no emoji stand-ins.

## Canonical grade characters
1 Bunny; 2 Cat; 3 Otter; 4 Red Panda; 5 Panda; 6 Corgi; 7 Penguin; 8 Fox; 9 Monkey; 10 Koala; 11 Bear; 12 Capybara.

## Implementation
- Added `assets/js/game/character/grade-character-library.js`, extracted from the same `chibi()` SVG renderer used by `maihoc-game-world.js`.
- `maihoc-game-world.js` now exposes its exact chibi renderer as `window.MAIHOC_GAME_CHIBI` for parity/reuse.
- Public homepage keeps its existing book/card design and adds the correct game character to every Grade card. The carousel contains a duplicated 12-card set for seamless scrolling, so 24 rendered cards/characters is expected.
- Logged-in 12-grade selector now uses the same book/card visual design and one correct game character per Grade.
- Logged-in links continue to open the corresponding Grade Level 1 game.

## Static validation
- Shared grade-character JS syntax: PASS (`node --check`).
- Game-world JS syntax after export: PASS (`node --check`).
- Public homepage: 24 grade cards / 24 character slots (12 grades duplicated for carousel): PASS.
- Logged-in selector: 12 grade cards / 12 character slots: PASS.
- Both pages load shared v333 character renderer: PASS.

No browser click-through is claimed in this audit.
