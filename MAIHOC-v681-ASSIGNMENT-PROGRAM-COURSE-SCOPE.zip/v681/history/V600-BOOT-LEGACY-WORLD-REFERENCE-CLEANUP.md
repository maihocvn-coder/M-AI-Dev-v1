# V600 — Boot / Legacy World Reference Cleanup

Audit result: v599 removed the legacy `#landmark` scenery node from School English play HTML, but the canonical controller and grade engine copies still executed `$('landmark').textContent = l.landmark` during `theme()`. That null dereference occurred inside the Grade 1 boot try/catch and produced the visible fallback “Game cần tải lại để tiếp tục.”

Cleanup:
- Removed the obsolete legacy `#landmark` write at its source from the canonical School English controller.
- Removed the same stale legacy-world write from grade engine copies so no grade can reintroduce the removed world dependency.
- Did not add CSS, hide an element, recreate a compatibility landmark, or add a fallback patch.
- Playground park remains the single world renderer.

QA:
- No remaining `$('landmark')`, `id="landmark"`, or `world-journey` references in active School English game JS/HTML.
- Canonical controller, world transition, and character movement pass `node --check`.
