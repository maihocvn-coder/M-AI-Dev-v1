# v668 — Homepage right-column canonical Grade 1 demo

- Restores the homepage hero to a two-column layout.
- Places the Grade 1 game demo in the right hero column rather than as a full-width block below the copy.
- Removes the `id="demo"` collision with legacy `#demo` section CSS that was adding large padding/height and obscuring the iframe.
- Keeps the public preview pointed at the canonical Grade 1 game-view copy/runtime; no separate cat/carrier/controller/Sage implementation is introduced.
- Responsive fallback stacks the demo below the hero copy only on narrower screens.
