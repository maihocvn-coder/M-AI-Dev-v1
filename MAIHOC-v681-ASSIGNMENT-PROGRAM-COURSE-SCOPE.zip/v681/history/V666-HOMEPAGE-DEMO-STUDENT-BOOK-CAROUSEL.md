# v666

- Homepage standalone demo now renders the canonical Grade 1 Cat from the shared character library and fills most of the hero preview card.
- Demo keeps 5 curated questions, carriers, Jump controls and Sage coaching.
- Student Home grade chooser now uses a multi-book horizontal carousel matching the public index School English carousel: all 12 Grade books are rendered, clickable, scrollable, with arrows.
- Release notes remain under history/.
