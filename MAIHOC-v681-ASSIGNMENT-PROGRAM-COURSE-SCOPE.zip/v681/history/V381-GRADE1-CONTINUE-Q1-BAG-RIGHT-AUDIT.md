# v381 Grade 1 Continue Q1 + Bag Right Audit

## Root causes addressed
1. Student Home Continue was using stale exact-session resume snapshots (queueIds/questionId/index). This made Continue depend on historical shuffled queues. v381 makes the Continue URL's requested Level authoritative and opens Question 1 of that Level immediately.
2. Adventure Bag CSS contained contradictory historical positioning rules. The v375 collapsed rule explicitly set `right:auto`, which moved the collapsed bag to the left even though earlier canonical rules placed it on the right. v381 adds a final authoritative Grade 1 rule: expanded and collapsed bag are always top-right.

## Contract
- Student Home Continue Level N -> `play.html?level=N&mode=play&start=1&resume=1&question=1`.
- `resume=1` bypasses Welcome and starts at index 0 of a freshly valid Level N play queue.
- Level Map remains interactive.
- Bag is always right aligned, collapsed or expanded.

## Validation
- `node --check` on Grade 1 game.js.
- Verified Level 2 canonical bank has 30 playable items and non-empty prompts/options.
- Browser Chromium launch was attempted but did not complete in this container, so no browser-E2E claim is made.
