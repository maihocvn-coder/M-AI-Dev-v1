# M-AI Học v252 — Flow Hardening

- Session status adds Make-up Session. A make-up must reference an eligible cancelled/missed session in the same class using `makeupForSessionId`.
- Teacher Hours secondary row actions collapse under a compact overflow menu.
- Platform resource taxonomy separates M-AI School English (Game Book), M-AI School English Question Bank, and Worksheets. Canonical resources are preview-first and read-only; admins can save to My Library or Organization Library before editing.
- Grade 6 opens with an orientation state when no explicit mode is requested.
- Sage uses interactive diagnostic multiple-choice hints, item-bound Ask More choices, and a different same-target question for Quick Quiz.
- Save Course and Archive Course verify persistence. Class Create syntax defect found by whole-package inline-script audit was fixed.
- Shared `MAIHOC_ACTION_AUDIT` registry provides the contract for future button/action verification.
