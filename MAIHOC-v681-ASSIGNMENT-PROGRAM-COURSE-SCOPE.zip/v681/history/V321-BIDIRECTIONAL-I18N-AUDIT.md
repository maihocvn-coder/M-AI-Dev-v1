# V321 bidirectional language-switch repair audit

- HTML pages: 378
- Pages loading v321 engine: 147/378
- Pages loading v321 catalog: 147/378
- Canonical catalog merged before reverse lookup: PASS
- Homepage canonical pairs present: PASS
- Default locale remains VI: PASS
- VI -> EN -> VI lookup architecture: PASS (REV built after full catalog merge; keys, VI values, and EN values all indexed)
- School English/game non-HTML learning assets changed vs v320: 0
- JS syntax: PASS (engine + catalog)

## Root cause fixed
V320 built the reverse lookup table before merging the v320 canonical bilingual catalog. As a result, catalog-only Vietnamese phrases displayed on pages such as index.html could not be resolved back to their English pair when EN was selected. V321 merges the full catalog first and only then builds the reverse lookup.

## Homepage
Added canonical VI/EN pairs for landing-page UI and marketing/explanatory copy. The embedded sample learning question/answers and proper names are not translated.

## Limitation
This environment did not run a real browser click-through. This audit verifies source wiring, lookup order, catalog coverage for the homepage, syntax, and protected non-HTML learning assets.
