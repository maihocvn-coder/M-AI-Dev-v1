# V579 — Middle-width game cell repair

## Root cause
V578 had two responsive state systems that disagreed between 1101–1366px: the global page state was still `wide`, while the game envelope was already `tablet`. The tablet rule converted `.layout` to one grid cell, but the journey `<aside>` was only converted to a drawer by the global `medium/narrow/phone` state. At middle widths the aside therefore occupied the only grid cell and pushed `<main>` into a second implicit row that was clipped, producing the empty game area.

## Replacement
The game envelope is now authoritative for School English game-shell structure. Whenever `data-mh-game-profile` is `tablet` or `phone`:
- the journey aside is a fixed off-canvas drawer regardless of global page width state;
- the game main is explicitly grid row 1 / column 1 and fills the viewport cell;
- the hamburger is enabled by the same game profile;
- desktop profile remains unchanged.

No new stylesheet/versioned CSS file was added. The canonical `assets/css/maihoc-responsive.css` rule was replaced/extended in place.
