# v363 Compact Promo + Resource Table UX

- M-AI promotion reduced to compact non-sticky carousel strip.
- Promotion remains at the top of every Learning Library view.
- Clicking School English or CEFR scopes the table to that source only.
- Canonical table columns: Preview → Source → Type → Level → Focus → Title → actions.
- Type, Level, Focus filter directly from table header dropdowns; Title sorts from header.
- Results grouped by resource Type.
- Row/preview click opens full preview; three-dot menu contains actions.
- M-AI canonical actions: Full Preview, Assign, Copy to My Library; Organization Admin also gets Copy to Organization Library.
- No browser E2E was run; JavaScript syntax and ZIP integrity were checked.
