# V558 — Sage launcher, single save action, calm feedback glass

- Collapsed Sage launcher is fixed to 64x64 so it cannot grow beyond its navigation/game footprint.
- Character/Sage editor exposes one primary action only: Save Character & Sage.
- In popup mode that single save action saves/syncs and then closes the popup.
- Feedback keeps the centered overlay contract but uses neutral M-AI navy glass at 30% opacity, stronger backdrop blur, lighter border/shadow, and a less oversized 540px maximum width.
- No curriculum/question-bank/reward/controller changes.
