# v594 — School English Content Authority Contract

## Scope
Architecture only. No Knowledge, Question, Sage, Engine, World, Character, reward, learner-progress, or wallet content was rewritten.

## Canonical authority
- All migrated consumers resolve School English through `MAIHOC_CONTENT.get("schoolEnglish")` or the logical alias `MAISCHOOLENGLISH`.
- `assets/js/game/core/school-english-data.js` is the single release resolver/control-plane authority.
- V1 wraps the existing loaded `MAIHOC_BANK_DATA`, `MAIHOC_G6_LESSONS`, and existing Sage data without mutating them.
- V1 is frozen and cannot be replaced through `registerRelease`.
- Physical release selection is not owned by Game/Grade consumers.

## Control-plane contract
- `registerRelease(version, provider)` registers a future physical release.
- `activate("schoolEnglish", version)` changes the production pointer only when the release status is `released`.
- `setPreview("schoolEnglish", version)` provides a separate preview pointer; it does not change production.
- Admin UI and V2 content are intentionally deferred to the next phase.

## Compatibility
`MAIHOC_SCHOOL_ENGLISH_DATA` remains available as a compatibility facade, but now resolves through the canonical authority. The shared School English controller no longer falls back directly to `window.MAIHOC_BANK_DATA`.

## Boundaries
Engine, World, Character, learner progress, wallet, and attempt history remain outside content releases.
