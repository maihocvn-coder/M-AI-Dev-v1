# M-AI Học v308 — Impersonation Isolation Audit

This release fixes privilege leakage while impersonating another role.

- Effective identity is now target user + target role + target organization across Scope, ACL, Governance, page access and site navigation.
- Super Admin actor privileges do not leak into the impersonated UI/function registry.
- Direct admin URL access is centrally guarded on all admin HTML pages.
- Organization Admin impersonation cannot access Super Admin, Management Admin or Curriculum Admin functions.
- Curriculum Designer, Curriculum Admin, Management Admin, Teacher, Parent and Student impersonation are regression-tested.
- Ending impersonation restores the actor session.
- Existing v307 organization website/navigation/resource contracts were rerun.

Automated QA files: `V308-IMPERSONATION-REGRESSION-TEST.js`, `V308-IMPERSONATION-PAGE-ACCESS-TEST.js`, `V308-IMPERSONATION-AUDIT.json`.
