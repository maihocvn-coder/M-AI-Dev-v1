# V553 — Sage stable size + quiet navigation

- Removed the active-tab underline from Sage navigation.
- Active Sage tool now uses a subtle translucent background with stronger text.
- Expanded Sage has one stable target size: 430 × 440 px, constrained only when MainScreen itself is smaller.
- Sage body owns vertical scrolling; changing Hint / Ask More / Quick Quiz / Play with Sage no longer changes panel height.
- Navigation remains two rows × two columns.
- No Sage content, question data, controller, or database changes.
