# V557 — Right Arrow Keyboard Repair

- Base: v556.
- Scope: character keyboard input only.
- Replaced fragile `e.key`-only arrow matching with normalized `key` + `code` + legacy keyCode fallback.
- ArrowLeft/A = move left; ArrowRight/D = move right; ArrowUp/W/Space = jump.
- Removed `stopImmediatePropagation()` so the character handler does not monopolize the keyboard event.
- No changes to content, questions, Sage, feedback, reward, or layout.
