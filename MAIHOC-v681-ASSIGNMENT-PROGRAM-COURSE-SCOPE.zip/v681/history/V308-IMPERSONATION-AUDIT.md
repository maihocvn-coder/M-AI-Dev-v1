# V308 Impersonation Audit

## Rule
While impersonation is active, effective user, role, organization, navigation, governance functions, ACL decisions, page access and authoring permissions use the target identity. The actor Super Admin authority is not inherited into the impersonated view. Ending impersonation restores the actor session.

## Automated results
- 7 target roles tested: Management Admin, Curriculum Admin, Curriculum Designer, Organization Admin, Teacher, Parent, Student.
- Effective role consistency tested across Scope, Governance and ACL.
- Privileged-function leakage tests passed.
- Script-publish leakage tests passed.
- 19 direct-page access cases passed.
- Every admin HTML page has the central page-access guard.
- Existing v307 whole-site button/link/content contracts rerun.

## Security-sensitive behavior
Impersonation never converts the underlying actor account. End Impersonation restores Super Admin. Sensitive financial/security operations remain separately protected by the impersonation guard.
