# V586 — Refined Language Audit / Human Review Queue

Baseline: v585. Production UI/content remains unchanged.

- Refined the static language manifest using semantic HTML/control context rather than visible-language guessing.
- Reduced false UNKNOWN/Human Review items from 3,508 to 19.
- Classified 2,635 UI nodes, 628 support nodes, and 240 proper/metadata nodes; 19 remain genuinely unresolved for Human Audit.
- Human Audit remains authorized for Super Admin / Management Admin.
- Updated the read-only runtime detector to report semantic confidence and `humanReviewNeeded` without mutating the page.
- Updated Admin Language Audit Center to show the refined queue.
- Diagnosed Student Home source: canonical i18n is loaded, but large portions of HTML and runtime-generated JS UI are hard-coded and lack stable semantic keys. No conversion was performed in this release.

Next gate: migrate approved UI/support surfaces from the v586 manifest, beginning with role homes, then runtime-test VI → EN → VI.
