# V614 Game Configuration + Character Reaction Audit

- Extended the existing Game Registry; no second config store was created.
- Super Admin Game Setup now publishes carrier selection, per-unit carrier idle movement, and reaction choices through the existing `R.set()` authority.
- `MAIHOC_GAME_CONFIG.get()` resolves those published values for runtime.
- Added one shared Character Reaction Runtime. Learning/game events are separate from animation implementation.
- Events: `answercorrect`, `answerwrong`, `charactermiss`, `characterbump`, `levelcomplete`.
- Reaction resolver avoids recently repeated reactions and returns to normal character state after a short reaction.
- Grade 1 defaults remain Jump & Catch + Wiggle, but Super Admin can publish a different carrier/motion/reaction configuration without editing runtime JS.
