# M-AI Học v286 — Role–Page–Flow Isolation Audit

## Purpose
Prevent role/page contamination across the whole site, not only Analytics. A higher authority may manage lower scopes, but a page must keep the identity, purpose, data scope, actions, guide, and return path of the function that opened it.

## Core rule
**One active role = one role workspace. Manage down; switch sideways.**

Administrative authority: Super Admin → Management Admin → Curriculum Admin → Organizational Admin. Personal/specialist workspaces such as Curriculum Designer, Teacher, Parent and Student are entered through their own active role, not silently inherited as a homepage section.

## Audit chain
For every route and every entry point audit:

`Active Role → Home Section → Function → Route → Page Owner → Page Purpose → Data Scope → Actions → Guide → Save/Cancel/Back → Return Context`

A route fails when any link in that chain belongs to another role context without an explicit manage-down, preview, or impersonation state.

## Site-wide audit groups
1. Super Administration
2. Management Administration
3. Curriculum Administration
4. Curriculum Designer
5. Organization Administration
6. Teacher
7. Parent
8. Student
9. Shared/account/system pages
10. Cross-role transitions

## Hard gates
- Page owner is declared/classifiable.
- Breadcrumb, title/hero, terminology, filters and actions agree with page owner.
- Data scope agrees with page purpose.
- Home card, navigation, quick access, guide, notification and drill-down routes do not silently switch workspace.
- A shared component may be reused, but a shared role identity may not.
- Admin manage-down retains the admin actor identity in audit history.
- Teacher/Parent/Student personal work requires Switch Role; admin management of their records does not.
- Direct URLs retain page contract and permission/scope checks.
- Cross-section reuse of the same route is a hard failure unless it is intentionally the same owner/workspace.
- Save/Cancel/Back must return to the same role context.

## v286 repairs
- Split **Management Payroll & Rates** from **Organization Payroll**. Management now has a platform/workforce payroll page; Organization Payroll remains organization-scoped.
- Split **Super Admin Control** from the Management `People & Teams` destination.
- Added a runtime page-contract registry (`maihoc-role-page-contract-v286.js`) that records page owner/scope and warns when an incompatible active role opens a role-owned page.
- Added an executable whole-site audit (`qa-role-page-flow-isolation-v286.js`) and machine-readable inventory/report (`V286-ROLE-PAGE-FLOW-ISOLATION-AUDIT.json`).
- Expanded ownership classification for Super, Management, Curriculum, Organization, Teacher, Parent, Student and shared pages.

## Required future release gate
Run the v286 audit whenever a route, homepage card, navigation item, Guide link, role, permission, analytics page, payroll page, CRUD page, or drill-down flow changes. A release is blocked on role semantic contamination, unclassified admin pages, or cross-section route reuse.
