# v654 — Question Content + Audio Contract Audit

## Root cause
Game Play rendered only `q.prompt` in the floating world question. `q.stimulus` existed in the canonical bank but was only rendered in the document interaction panel, which is hidden in Play mode. Therefore sentence-completion questions lost the sentence.

## Canonical repair
- World question now renders `instruction` and `stimulus` as separate fields.
- Listening keeps transcript/stimulus text hidden but exposes Play Audio.
- Phonics/Pronunciation detects verified isolated IPA targets from canonical target fields, stimulus, or prompt and mounts `MAIHOC_PHONEME_AUDIO`.
- Phonics and Pronunciation answer carriers expose choice audio; audio clicks never submit the answer.
- Controller now uses the same phoneme/audio-source resolution.
- Contract validator rejects completion items without stimulus and Listening items without an audio source before they enter a 10-question queue.

## Static data audit
- Parsed bank records: 22015 grade/question records across available G1–G12 bank JSON files.
- Missing completion stimulus under the new contract: 0.
- Missing Listening audio source under the new contract: 0.
- Pronunciation questions about stress/rhythm/intonation are not falsely rejected merely because they do not contain an IPA token; choice audio is now available for Pronunciation carriers.

## Rendering contract
`instruction` = what the learner should do. `stimulus` = the sentence/passage/context to act on. `audio stimulus` = what must be heard. These are no longer collapsed into one prompt field.

## Scope
No changes to Jump/contact geometry, reward lifecycle, world composition, mascot artwork, Sage authority, or curriculum content.
