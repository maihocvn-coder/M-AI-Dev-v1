# V358 — Sage Avatar + Meta Pronunciation Question Audit

- Deleted 585 meta/abstract pronunciation questions from canonical School English banks.
- Mirrored cleaned banks into data/school-english.
- Regenerated/filtered runtime bank-data.js derivatives so deleted items cannot still appear in game/practice/test runtime.
- Fixed Grades 7–12 Sage script references: pages referenced non-existent grade-specific master files; all now use the existing universal maihoc-sage-grade6-master.js?v=358.
- Sage universal master renders the selected Sage through student/assets/character-renderer.js; collapsed button and panel avatar are both populated.

## Removed by grade
- Grade 6: 60
- Grade 7: 115
- Grade 8: 115
- Grade 9: 115
- Grade 10: 90
- Grade 11: 35
- Grade 12: 55

## QA rule
Reject pronunciation items that ask learners to identify internal linguistic labels/patterns such as “target sound”, “highlighted part”, stress-pattern labels, rhythm labels, or intonation-pattern labels instead of performing a natural listening/recognition/use task.

No replacement questions were invented in this patch; the flagged items were deleted as requested.