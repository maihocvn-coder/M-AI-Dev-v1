# V570 — Measured Game Fit Geometry

## Purpose
Replace fixed/percentage short-screen game positioning with measured MainScreen fit geometry.

## Canonical ownership
- `assets/css/maihoc-responsive.css`: the only liquid/reflow CSS authority.
- `assets/js/maihoc-responsive.js`: the only size measurement / fit-state authority.
- `assets/css/maischoolenglish.css`: component appearance only; all `data-mse-layout`, `data-mse-height`, compact-site, and curtain responsive selectors were removed.

## Game fit contract
The runtime measures the live MainScreen and protected elements, then sets canonical CSS variables:
- `--mse-question-top`
- `--mse-answer-top`
- `--mse-character-h`
- `--mse-bottom-stack-h`
- `--mse-bottom-safe`
- `--mse-sage-bottom`

Protected order:
1. Adventure Bag
2. Question
3. minimum 14px question→answers gap
4. Answer holders
5. flexible world band
6. Character
7. Controller
8. bottom safe area

Character/controller are bottom-anchored. Sage is anchored above the controller. If the measured frame cannot fit, site chrome is asked to collapse before protected gameplay is allowed to clip. Only after flexible space is exhausted may character height reduce, with a floor.

## Replacement cleanup
Removed historical MainScreen `data-mse-layout` / `data-mse-height` geometry rules and the old V566 curtain ownership from `maischoolenglish.css`. No new version-specific override file was added.
