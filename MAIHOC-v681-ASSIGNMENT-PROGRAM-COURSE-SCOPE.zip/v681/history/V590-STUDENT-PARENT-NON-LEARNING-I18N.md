# v590 — Student + Parent Non-Learning i18n Migration

- Baseline: v589.
- Continued the canonical non-learning language audit/enforcement workflow.
- Student general-management surfaces now have **0 static migration-required non-learning candidates** in the v590 audit.
- Parent general-management surfaces now have **0 static migration-required non-learning candidates** in the v590 audit.
- Added 127 Student and 29 Parent canonical VI/EN visible-text pairs to the existing canonical i18n catalog; no second i18n runtime was created.
- Tightened audit scope to exclude `student/worksheets/` as learning/assessment content, preventing English questions and answers from being misreported as UI language leakage.
- Games, engines, units, question/content/worksheet/CEFR banks remain outside this management/general-page migration.
- Whole-site remaining static migration-required candidates: **693 across 105 pages**. Remaining work is concentrated in Teacher, Account, Admin and a small Public/general set.
- `node --check` passed for the canonical i18n runtime and catalog.
- Static/source audit verified; browser VI→EN→VI runtime verification is not claimed.
