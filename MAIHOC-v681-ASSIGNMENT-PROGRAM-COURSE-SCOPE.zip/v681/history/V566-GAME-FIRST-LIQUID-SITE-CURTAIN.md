# V566 — Game-first liquid site curtain

- Short-height, phone, and tablet School English surfaces collapse the global site header to a 34px curtain rail.
- A centered chevron opens the complete site navigation as an overlay; it does not consume permanent game height.
- Breadcrumb is hidden while the compact curtain is active.
- Full navigation is restored inside the opened curtain and closes after navigation/outside click.
- Short-screen Grade 1 question geometry no longer uses the previous 14px extreme top position; question and answer lane retain separate readable bands.
- Gameplay invariants remain: three answer holders, Sage HUD, character and controller stay available.
- No curriculum, question-bank, reward, Sage tutoring, or movement logic changed.
