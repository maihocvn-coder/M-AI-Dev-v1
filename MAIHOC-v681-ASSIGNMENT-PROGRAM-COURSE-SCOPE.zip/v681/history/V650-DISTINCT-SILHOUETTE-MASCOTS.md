# v650 — Distinct Silhouette Mascots

Canonical rule: species identity first, cute second, shared M-AI illustration language third. G1 Cat remains the style-language reference, not a body template.

Default assignments:
G1 Cat; G2 Bunny; G3 Duckling; G4 Frog; G5 Fancy Poodle; G6 Otter; G7 Tiger; G8 Raccoon; G9 Alpaca; G10 Peacock; G11 Deer; G12 Snow Leopard.

Each built-in owns independent SVG anatomy and a signature silhouette. Admin remains able to override character per grade/unit through the existing Character Library/Game Setup authority.

No movement/contact/jump implementation was changed in this release.
