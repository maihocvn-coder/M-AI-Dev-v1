# V615 — Fantasy Action / Asset Config Consolidation

## Rule
Characters and carriers are visual/game identities, not real-world capability gates. Any character can be assigned any registered action; any carrier can be assigned any registered motion.

## Changes
- Removed carrier species capability filtering from the canonical carrier-motion resolver.
- Removed the Grade 1 runtime hard-lock to wiggle. Grade 1 still defaults to wiggle through config, but Super Admin can override it.
- Added Character Actions to the existing Super Admin Game Setup authority. Grade 1 defaults to Walk + Jump, but any action may be selected for any character.
- Added per-carrier motion overrides. A Grade/Unit can use a default carrier motion and override Butterfly, Bee, Bird, etc. independently.
- Expanded registered carrier motions and character action assets.
- No biological compatibility validation is used. Runtime validation is technical only: the selected action/motion must have a registered implementation/fallback.

## Authority flow
Grade/Unit context -> MAIHOC_GAME_CONFIG -> MAIHOC_GAME_REGISTRY published config -> shared Character/Carrier runtime.

The Grade/Unit does not need species-specific gameplay logic. Super Admin changes published config without editing curriculum/question code.
