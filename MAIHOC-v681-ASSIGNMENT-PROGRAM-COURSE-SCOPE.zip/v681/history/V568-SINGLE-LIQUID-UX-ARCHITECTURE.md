# V568 — Single Liquid UX Architecture

## Purpose
Replace the consolidated legacy responsive rules with one coherent liquid authority for the whole M-AI Học site.

## Canonical authorities
- `assets/css/maihoc-responsive.css` — the only viewport/container reflow CSS authority.
- `assets/js/maihoc-responsive.js` — the only runtime that measures viewport/MainScreen and emits liquid states.

## State contract
Site: `wide | medium | narrow | phone` plus `tall | medium | short`.
Game MainScreen: `wide | medium | narrow | phone` plus `tall | medium | short` measured from the actual MainScreen after site chrome has reflowed.

## UX order
- Standard pages: context → primary content/action → secondary content → management/detail.
- Tablet: multi-column becomes 2/1 column; tables remain scrollable when needed.
- Phone: one-column app layout; tables become cards; editors stack; modals become full-width sheets; action bars remain reachable.
- Site navigation: full/More on roomy layouts; one curtain overlay on compact/short layouts.
- Game: site chrome yields first; journey rail becomes drawer; question, 3 answers, character/controller and Sage remain gameplay priorities.

## Cleanup
- Removed legacy width/height `@media` logic from the canonical responsive file rather than layering another override.
- No viewport width/height media query remains anywhere in the project.
- No responsive measurement JS remains outside `maihoc-responsive.js`.
- Accessibility (`prefers-reduced-motion`) and print media remain in the canonical file and are not liquid authorities.
