# v387 Grade 1 Single Shell + Letter Catch

Canonical contract: one Grade 1 shell, one Letter Catch engine, 16 content units. Unit-specific game labels are retired. All unit redirects enter the same engine/play.html shell. Legacy question engine metadata may describe learning item behavior but cannot select a different Grade 1 Play mechanic.
