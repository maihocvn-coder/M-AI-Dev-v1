# V575 — Content-Anchored Character Geometry

- Replaced bottom-anchored character stack placement with content-anchored placement.
- Character/controller stack target is now derived from the live answer bottom plus a gap proportional to the live character artwork.
- MainScreen bottom is only a safety clamp; extra MainScreen height no longer becomes extra empty space above the character.
- Actual overlap still triggers compact site chrome.
- Moved live Play MainScreen/scene height ownership out of `maischoolenglish.css` and into canonical `maihoc-responsive.css`.
- No new stylesheet or version override block was added.
