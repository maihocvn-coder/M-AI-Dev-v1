# v263 Grade 6 English Phoneme Audio Audit

- Rejected v262 acoustic assets after user test reported /t/ and /d/ still sounding like “ta/da”.
- Removed all Grade 6 consonant Wikimedia generic IPA recordings.
- Removed WebAudio synthetic fricatives.
- New source: University of Hamburg “All English phonemes” English-learning table.
- Exact Grade 6 mapping: /p/ p.mp3; /b/ b.mp3; /t/ t.mp3; /d/ d.mp3; /s/ s.mp3; /z/ z.mp3; /ʃ/ sh.mp3; /θ/ thing.mp3; /ð/ there.mp3.
- No external navigation in the student UI. All playback remains behind the M-AI Học speaker button.
- Knowledge, Question and Sage continue to share MAIHOC_PHONEME_AUDIO.
- This build does not claim acoustic E2E verification; the source mapping is verified from the university page, but the build environment cannot audition audio.
