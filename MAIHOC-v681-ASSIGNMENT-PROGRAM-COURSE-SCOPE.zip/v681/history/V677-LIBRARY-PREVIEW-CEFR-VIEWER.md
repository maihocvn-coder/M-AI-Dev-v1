# v677 — Library preview + CEFR viewer
- Hover preview is visual image-style artwork only; no live question UI inside hover cards.
- Assignment label changed from “Whole course” to “All students”.
- CEFR synthetic placeholder materials removed from the Learning Library.
- CEFR Library cards now resolve to existing canonical CEFR worksheet and level-test data.
- Added read-only CEFR material viewer for Open; no authoring/copying behavior added.
