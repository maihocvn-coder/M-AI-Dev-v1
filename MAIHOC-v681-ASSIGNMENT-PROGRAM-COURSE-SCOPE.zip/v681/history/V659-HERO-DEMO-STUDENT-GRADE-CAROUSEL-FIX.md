# v659 — Hero Demo + Student Grade Carousel Fix

- Fixes homepage embedded demo shell leakage: `homeDemo=1` now suppresses the global site header/breadcrumb before the game presentation mounts.
- Strengthens canonical School English demo CSS to hide site-shell artifacts and remove shell padding.
- Fixes the actual routed Student Home (`student/home/home.html`), not the unused parallel file.
- Replaces the old fake game screenshot on Student Home with a one-at-a-time clickable Grade 1–12 book carousel.
- Carousel opens on the student's active grade (Grade 6 fallback), with previous/next arrows and direct Knowledge links.
- `student/home.html` now redirects to the canonical `student/home/home.html` so there is only one Student Home authority.
- Does not change Jump/contact, question bank, Sage, world, or mascot behavior.
