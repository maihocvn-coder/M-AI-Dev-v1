# v645 Curriculum-driven tiled worlds

- Source: Curriculum Truth Table v7
- Unit profiles: 170
- Reusable base world themes: 26
- G1U1 preserves Playground Hero as visual reference.
- Runtime selection: context -> World Profile -> Game Config -> World Registry -> World Transition.
- Admin-published world remains higher priority than recommended Unit world.
- All non-reference worlds use seamless horizontal tiles with shared edge/path contract and age/topic profile metadata.
