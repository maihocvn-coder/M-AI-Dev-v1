# v667 — Canonical Grade 1 Homepage Game Preview

- Removed the invented standalone homepage mini-game implementation.
- Homepage preview now mounts a public-safe clone of the actual Grade 1 game DOM and canonical runtime.
- Uses the same Grade 1 world, carriers, Cat, targeted Jump/contact behavior, controller, Sage runtime, question renderer, audio and game CSS.
- Preview is full-width/wide instead of a narrow portrait-like card.
- Public preview strips account/access redirect scripts only; gameplay authorities remain canonical.
- The authenticated Grade 1 source page itself was not changed.
