# V390 Grade 1 Sage + Game Routing Semantic Audit

Scope: all 16 Grade 1 levels, 960 question records, three Grade 1 skills, Sage pronunciation/phonics behavior, and post-progress skill routing.

## Root causes repaired
1. Shared Sage treated every Phonics item as an isolated-phoneme task. Grade 1 Units 1–8 often have letter/whole-word targets and no verified isolated phoneme, causing `//` and dead audio controls.
2. Pronunciation resolver ignored explicit IPA embedded in `phonicsTarget`, so later Grade 1 units could also lose a legitimate target.
3. Progress skill selection explicitly changed `state.mode` from `play` to `practice`, which intentionally removed the Letter Catch game scene.
4. Units 5–6 contained semantically impossible prompts asking for words beginning with I/E even though the canonical model words contain the target vowel medially.

## Repairs
- Initial-letter questions use a Grade-1 letter-recognition Sage path with playable whole-word buttons; no fabricated IPA.
- Missing-phoneme questions never render `//` and never render a dead isolated-phoneme button.
- Explicit `/.../` in `phonicsTarget` is recognized. An isolated button is rendered only when the verified phoneme registry has that audio; otherwise Sage uses whole-word examples and states that isolated audio is unavailable.
- Units 5–6 prompts now test the vowel sound through the canonical model words (`fish`, `pen`) rather than falsely asking for initial I/E.
- Progress → Vocabulary / Phonics / Sentence Patterns now keeps `mode='play'`; the selected skill filters the Letter Catch queue instead of switching to the plain Practice renderer.
- Both callback routes (`MAIHOC_PROGRESS_UI.show` and `maihoc:choose-skill`) follow the same Play-mode contract.

## Automated gates
`qa-grade1-v390.js` checks 960 Grade 1 questions, minimum practice coverage for 16 × 3 skill routes, initial-letter semantic correctness, Sage no-phoneme/audio guards, explicit IPA resolution, and both skill-selection routing paths.
