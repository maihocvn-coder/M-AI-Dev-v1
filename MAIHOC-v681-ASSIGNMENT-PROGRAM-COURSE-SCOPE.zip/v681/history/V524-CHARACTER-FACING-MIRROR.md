# v524 — Character facing mirror correction

Baseline: v523.

Scope only: correct the Grade 1/reference sample cat facing orientation.

- Facing right: mirror artwork so the tail is on the character’s left side.
- Facing left: use the opposite orientation.
- Updated both the Grade 1 movement authority and the shared sample-cat used by Grades 2–12.
- Updated the matching canonical CSS facing selectors so CSS and runtime do not fight.
- No geometry, controller, world, answer-holder, Sage, content, or navigation changes.
