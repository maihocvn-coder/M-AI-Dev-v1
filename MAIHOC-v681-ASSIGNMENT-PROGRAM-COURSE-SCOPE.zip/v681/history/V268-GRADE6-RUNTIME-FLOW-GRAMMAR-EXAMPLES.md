# v268 Grade 6 Runtime Flow + Grammar Examples

- Start/welcome clears question decoration and audio ownership; pronunciation decoration is gated to an active question.
- Unit navigation preserves current mode + skill rather than resetting to Play/Welcome.
- Knowledge Pronunciation -> destination Unit Pronunciation; Knowledge Grammar -> destination Unit Grammar; Practice skill -> same Practice skill; Play -> Play; Test -> Test.
- Added `studentView.examples[]` to all 12 Grade 6 Grammar lessons and visible `Ví dụ · Examples` rendering.
- 48 independently-authored grammar examples (4 per Unit), separate from assessment questions.
- QA: runtime flow PASS; legacy runtime contract updated for preserve-context navigation and PASS; Question Quality Gate 1,680 items PASS; JS syntax PASS.
