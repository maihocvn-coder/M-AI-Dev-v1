# v330 Question Report Function Audit

## Root cause
All Grade 1–12 play pages rendered `#report` (Báo câu hỏi này / Report this question), but no shared or grade runtime registered a click handler for that control. The button therefore had no action.

## Repair
- Added shared `assets/js/maihoc-question-report-v330.js`.
- Loaded it on all 12 Grade play pages.
- The control now opens a real report dialog.
- Report reasons: incorrect answer/explanation, unclear/missing information, audio issue, image/display issue, other.
- Optional detail note.
- Captures grade, level, mode, page, current question id/skill/prompt/options/answer when available.
- Stores reports in `localStorage` key `maihoc.question.reports.v330` and dispatches `maihoc:questionreported` for later Admin/report-service integration.
- Dialog supports VI/EN UI copy and does not modify learning content.

## Grade coverage
- Grade 1: report button present = PASS; report controller loaded = PASS
- Grade 2: report button present = PASS; report controller loaded = PASS
- Grade 3: report button present = PASS; report controller loaded = PASS
- Grade 4: report button present = PASS; report controller loaded = PASS
- Grade 5: report button present = PASS; report controller loaded = PASS
- Grade 6: report button present = PASS; report controller loaded = PASS
- Grade 7: report button present = PASS; report controller loaded = PASS
- Grade 8: report button present = PASS; report controller loaded = PASS
- Grade 9: report button present = PASS; report controller loaded = PASS
- Grade 10: report button present = PASS; report controller loaded = PASS
- Grade 11: report button present = PASS; report controller loaded = PASS
- Grade 12: report button present = PASS; report controller loaded = PASS

## Static checks
- Shared controller `node --check`: PASS.
- 12/12 Grade play pages contain the report button: PASS.
- 12/12 Grade play pages load the shared report controller: PASS.

## Browser limitation
No claim of browser click-through PASS is made here; this release was verified by source/runtime-contract checks in the current environment.
