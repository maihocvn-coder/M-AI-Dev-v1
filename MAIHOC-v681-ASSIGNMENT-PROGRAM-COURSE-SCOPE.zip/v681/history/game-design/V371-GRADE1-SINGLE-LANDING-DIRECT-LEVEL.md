# v371 — Grade 1 single landing + direct level flow

- The Grade 1 game orientation/instruction is shown only on the first bare engine entry.
- Clicking Play Level starts the current level immediately.
- Clicking any Level Map item starts Question 1 of that level immediately.
- Removed per-level instruction/welcome interception.
- Explicit level/mode/start URLs bypass the orientation landing.
