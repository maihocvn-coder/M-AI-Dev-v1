# v261 Grade 6 English Phoneme Source Repair

- Removed v260 Wikimedia consonant substitutions that could sound like syllabic demonstrations instead of the intended isolated English consonant.
- Canonical provenance is University of Iowa Sounds of Speech — American English (`/main/english`, legacy `#english`).
- Grade 6 consonant identities are locked separately: /p b t d s z ʃ ʒ θ ð/.
- No cross-language substitution: Spanish/German recordings are not used for Grade 6 English simply because the IPA symbol matches.
- Knowledge, Question and Sage share `MAIHOC_PHONEME_AUDIO`.
- Correctness-first behavior: if a reviewed local English isolated recording has not been packaged, the control opens the authoritative English source instead of playing a wrong audio substitute.
- `assets/audio/phonemes/en-US/README.md` defines the approval/install contract for local files.
- v261 QA rejects the old incorrect consonant mappings and checks the shared registry renderer contract.

Limitation: the build environment could not retrieve University of Iowa binary audio files, so this release does not falsely package or relabel third-party consonant recordings as Iowa assets. Local isolated consonant playback becomes enabled only after the actual reviewed English recordings are added to the manifest.
