# v681 Assignment Program/Course Scope
- Replaced legacy Assignment editor with canonical Program (optional) -> Course (required) -> Module (optional) flow.
- Removed Class from Assignment UI.
- Program and Course are dropdowns backed by canonical learning workflow data.
- Courses may be standalone with no Program.
- Program selection filters Course options.
- Assignment edit supports All students or Selected students, Available date, Due date.
- Assignment list displays actual Program/Course/Module/recipient/due scope instead of legacy Scope not set.
- Added update/remove methods to canonical learning workflow assignment authority.
- Course creation now supports No program / Standalone course.
