# v327 Grade activity-button runtime repair

## Reproduced root cause
The grade-entry/orientation script replaces `#interaction.innerHTML` when a Grade play page is opened without an explicit `mode`. The persistent left-rail buttons were still bound by `game.js` to start a mode in-place. That in-place runtime expects elements such as `#prompt`, `#stimulus`, and `#answers` from the normal interaction DOM, but the orientation screen had replaced those nodes. Result: the button visually clicked but the requested activity did not load (and could throw a runtime null-element error).

## Repair
`assets/js/maihoc-grade-entry-v253.js` now owns the four left-rail activity buttons while the orientation screen is active. Clicking Learn, 10-Question Practice, Play Level, or Practice Test navigates to the same Grade/Level with an explicit `mode` and `start=1`. On the new URL, the orientation installer intentionally does not replace the interaction runtime, so the normal Grade engine can load the selected activity.

The same routing contract already existed for the four orientation-screen activity buttons; v327 makes the persistent left rail use that same contract.

## Scope audit
- 12/12 Grade `engine/play.html` pages load the shared grade-entry script.
- 12/12 have the persistent `#modes` rail.
- Shared fix therefore applies Grades 1–12 without editing learning content.
- No question bank, Knowledge, Sage teaching content, curriculum, or School English learning data was changed.
- JavaScript syntax check: PASS.

## Expected navigation contract
For selected level N:
- Learn -> `?level=N&mode=knowledge&start=1`
- 10-Question Practice -> `?level=N&mode=practice&start=1`
- Play Level -> `?level=N&mode=play&start=1`
- Practice Test -> `?level=N&mode=test&start=1`

Browser click-through was not claimed in this audit; this is a source/runtime-contract repair and static verification.
