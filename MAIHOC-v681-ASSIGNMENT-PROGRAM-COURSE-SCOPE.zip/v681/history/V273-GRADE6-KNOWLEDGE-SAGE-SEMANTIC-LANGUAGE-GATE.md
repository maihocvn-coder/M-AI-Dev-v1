# v273 — Grade 6 Knowledge Sage Semantic Language Gate

## Purpose
Remove display-title/template concatenation from Knowledge Sage and audit final rendered language across all Grade 6 Knowledge Sage concepts.

## Architecture
Each of the 356 Knowledge Sage concepts now carries a semantic record:
- `canonicalConcept`
- `conceptType`
- `semanticIntent`
- explicit `exploreQuestions[]`

The Knowledge Sage runtime reads these semantic records. It no longer strips a display heading at runtime and inserts that heading into generic question templates.

## Repairs
- Definition headings such as `Present Continuous là gì?` are represented semantically as `Present Continuous / grammar_concept / definition`.
- Purpose headings such as `Possessive case dùng để làm gì?` are represented as a concept plus `purpose` intent.
- Generic grammar labels such as `Khẳng định`, `Phủ định`, `Câu hỏi`, `Dấu hiệu`, and `Lỗi dễ gặp` are resolved against the actual grammar target for that Unit.
- Listening focus, Reading step, Speaking step, and Writing step labels are treated as task/strategy steps rather than noun phrases.
- Removed generic generated coaching such as `Khi dùng lỗi dễ gặp...`, `Áp dụng bước này trực tiếp vào passage...`, and `Phần này cần phục vụ đúng mục đích...`.

## Release gates
- 356 semantic records required.
- Audit final Knowledge Sage utterances, not only source labels.
- Reject nested question constructions and unresolved/meta language.
- Knowledge Quick Quiz remains MCQ-only.
- `Chơi với Sage` remains a route-only CTA to Sage Games.
- Question Sage section is frozen byte-for-byte against v272.

## QA
- Knowledge Sage semantic language: PASS — 356 concepts, 2,306 audited utterances, 1,082 Explore prompts, 0 hard failures.
- Knowledge Sage interaction contract: PASS.
- Knowledge Sage concept/binding gate: PASS — 356 concepts.
- Question Quality Gate: PASS — 1,680 questions, 0 hard failures.
- Whole-item semantic gate: PASS — 1,680 questions, 0 hard failures.
- Runtime contract: PASS — 12 levels, 7 skills, 1,680 questions.
- Runtime flow: PASS.
- JavaScript syntax: PASS.
