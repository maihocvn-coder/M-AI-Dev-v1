# v341 — QR Lookup / Username-Email Fallback Audit

- QR is lookup/prefill only; it never creates a synthetic user.
- A scanned QR must resolve to an existing account before the canonical Add / Connect Person form opens.
- If QR lookup fails, UI directs the user to username/email search.
- Username/email search resolves an existing account and opens the same canonical form.
- Removed the separate user-facing Connection Code lookup block to avoid a parallel connection path.
- All saves continue through MAIHOC_CONNECT_PERSON and MAIHOC_REL.
- Static JS syntax and flow checks: PASS.
- Browser click-through was not run.
