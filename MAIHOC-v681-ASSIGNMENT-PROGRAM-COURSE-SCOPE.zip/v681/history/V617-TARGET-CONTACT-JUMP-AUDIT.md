# v617 Target-contact jump audit

- Removed the unused `assets/js/game/character/samples/sample-cat.js` runtime. No student play page loaded it.
- Removed fixed-height targeted jump and the old rectangle-contact watcher from the active character controller.
- A selected carrier is now the jump target. The character catch point (upper body/head area) follows a parabola to the carrier visual target point.
- The carrier target is re-read every animation frame, so wiggle/flutter/hover movement is followed rather than sampled once.
- At the contact frame the visual points coincide, then and only then is the canonical hidden answer button submitted.
- Targeted Grade 1 jumps do not have a miss branch: choosing/targeting a carrier guarantees visual contact.
- Correct contact follows the existing `maihoc:answercorrect` flow and continues. Wrong contact follows the existing `maihoc:answerwrong` event, so Character Reaction Runtime owns the wrong-answer emotion and the learner retries.
- Keyboard Jump targets the nearest active carrier; clicking a carrier targets that exact carrier.
- Generic no-target jump remains only when no active carrier exists.
