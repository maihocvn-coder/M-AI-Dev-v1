# v653 Cute Mascot Reassignment

G1 Cat; G2 Bunny; G3 Duckling; G4 Frog; G5 Fancy Poodle; G6 City Corgi; G7 Tiger; G8 Raccoon; G9 Red Panda; G10 Penguin; G11 Koala; G12 Snow Leopard.

Replaced Otter/Alpaca/Peacock/Deer. G6 City Quest now uses a City Corgi rather than an otter. Character art only; movement/contact/world runtime unchanged. Admin Character Library remains selectable authority.
