# M-AI Học v652 — Matrix-Driven Unit Worlds

## Authority rule
- Grade = visual identity only (palette, shape language, lighting, density/maturity).
- Unit = actual place (setting, landmarks, props, indoor/outdoor composition, 8-tile journey).
- Source: `MAIHOC-Unit-World-Composition-Matrix-G1-G12.xlsx` (170 Grade/Unit rows).

## Runtime
- `unit-world-composition.js`: canonical 170-row Unit World composition data.
- `world-profile-registry.js`: stable Unit World IDs + Grade visual themes.
- `world-registry.js`: resolves exact matrix composition; no title-keyword world inference.
- `world-transition.js`: renders the matrix tile journey and semantic place props.
- `maischoolenglish.css`: semantic indoor/outdoor scenery and place primitives.

## Examples
- G1 U3: Street Market World — gate → fruit → vegetables → bakery → flowers → toy/general stall → square → exit.
- G1 U6: Classroom World — door/cubbies → desks → board → teacher area → reading corner → learning station → display wall → windows.
- G2 U6: Farm World — gate → barn → animal yard → field → orchard → pond → tractor shed → farmhouse.

## Preserved contracts
- Shared World Runtime only.
- Character, movement, Jump/contact and answer lifecycle unchanged.
- Admin may still override by selecting another stable `world.gXX.uYY` asset; the selected Unit World's own composition follows it.
