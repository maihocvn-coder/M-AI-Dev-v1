# V290 Promotion / Coupon / Discount Flow

Management Admin operates coupons and discount campaigns; Super Admin governs limits and availability.

- Coupons target one or more subscription plans including Organization Custom.
- Coupon types: percent, fixed, free subscription, trial extension, custom benefit.
- Coupon redemption expiration is separate from granted access duration.
- Coupon revisions are versioned; redemption records snapshot the exact benefit revision.
- Discount campaigns are automatic promotions with start/end dates and benefit duration.
- Audience targeting supports everyone, selected users/organizations, new/existing/trial/custom audiences.
- Promotion changes are audited. Pause/reactivate/edit do not destructively delete history.
- Default stacking policy is best-single; governance can change policy.
- Super Admin controls maximum discount, maximum free days, availability of coupons/discounts/custom-plan coupons.
- Management Admin can create/edit/pause/activate coupons and campaigns.
- Subscription base plan, promotion, and effective entitlement remain separate concepts.
