# v332 Student UX repair audit

## Scope
- Student Home graphics
- Canonical Sage / game character presentation
- Gold coin visual across student/game surfaces
- Teacher vs Parent assignment distinction
- Student Assignments global hero/template repair

## Changes
1. Student Home no longer uses the generic cat emoji or robot emoji as product graphics.
   - Game hero uses the same canonical chibi cat SVG geometry/colors as `maihoc-game-world.js`.
   - Sage uses `MAIHOC_CHARACTER.renderSage()` from the same `student/assets/character-renderer.js` used by the game runtime.
   - Saved Sage customization is read from `maihoc.student.characters`, matching the avatar studio/game runtime.
2. Student Home now includes the standard `.mh-page` / `.mh-hero` blue global Student page header instead of a standalone white-only header.
3. Assignments page now loads `maihoc-universal-theme.css` and uses the standard blue `.mh-hero` header.
4. Assignment UX distinguishes:
   - `Bài giáo viên giao`
   - `Bài phụ huynh giao`
   on Student Home and the full Assignments page.
   Existing records without an explicit parent source remain teacher assignments for backward compatibility.
5. Coin visual is now a canonical CSS-rendered gold coin rather than the platform-dependent gray coin emoji.
   - 12/12 School English game pages use the gold coin component in the header and adventure pouch.
   - coin burst/reward coin animations use the same gold treatment.
   - Student Home, Wallet and Sage Games use the same gold coin component.

## Validation performed
- 12/12 Grade `play.html` pages contain the canonical gold coin component.
- 0/12 Grade `play.html` pages retain the old coin emoji.
- Node syntax check PASS for all 12 Grade `game.js` files.
- Node syntax check PASS for `assets/js/maihoc-game-world.js`.
- Extracted inline JavaScript syntax PASS for:
  - `student/home/home.html`
  - `student/assignments/home.html`
  - `student/wallet/home.html`
  - `student/sage-games/home.html`
  - `student/sage-games/play.html`

## Browser note
No browser click-through is claimed in this audit.
