# v525 — MainScreen Responsive Authority Consolidation

Date: 2026-10-03

- `.mse-main-screen` is the single named size container: `mse-main`.
- `#scene` is no longer a responsive container; it only owns the Game World.
- All game liquid breakpoints explicitly query `mse-main`.
- Answer Holders and Sage now react to the same actual MainScreen width.
- Removed superseded duplicate Grade 1 fish/control sizing and duplicate Sage anchor rules.
- Page-level media queries remain responsible only for page/sidebar/navigation layout.
- Liquid contract: >900 = 3 answers/Sage right; <=900 compact; <=720 = 2 columns/Sage left; <=560 = 1 vertical column; <=420 phone compact.
- No curriculum, question, reward, audio, engine, navigation, character art, or Sage behavior logic changed.
