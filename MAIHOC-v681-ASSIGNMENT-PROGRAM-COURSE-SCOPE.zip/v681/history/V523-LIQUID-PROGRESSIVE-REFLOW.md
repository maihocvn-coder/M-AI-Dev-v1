# v523 — Progressive liquid reflow

Baseline: v522.

Shared MainScreen CSS now contracts progressively rather than waiting for one narrow breakpoint.

- >720px: three answer holders, normal Sage.
- <=900px: compact holder/object/character/controller/Sage sizing.
- <=720px: answer holders reflow to two columns; Sage moves left/up; Report moves right.
- <=560px: answer holders become one vertical column; all controls, character, reward object and feedback shrink.
- <=420px: minimum usable compact presentation.
- Character and controller remain in separate vertical bands.
- No game/content/runtime logic changed.
