# v662 — Cute City Shiba

- Replaces the Grade 6 Corgi artwork/assignment with a newly coded City Shiba.
- Shiba silhouette: small triangle ears, round face, cream cheek mask, compact body, curled tail, tiny paws, blue explorer scarf.
- Character library remains the single artwork authority; Admin catalog/default Grade config updated to `shiba`.
- Removed `corgi` from the live canonical built-in library/catalog/default assignment.
- No changes to movement, Jump/contact geometry, worlds, questions, Sage, rewards, or homepage demo.
