# V561 — No-loss liquid navigation + game HUD

- Site navigation now progressively moves Student secondary items (Schedule, Progress, Wallet, Sage Games) into More at <=1280px instead of causing horizontal overflow.
- More is enabled for Student as well as Teacher.
- Narrow site header preserves current/primary navigation while reducing nonessential visible links.
- MainScreen and shell containers are constrained to available width; horizontal clipping is forbidden.
- Three answer holders remain a hard invariant: one row, all three visible; only holder internals reflow/shrink.
- Collapsed Sage is explicitly anchored inside the MainScreen right edge and remains visible in Learn/Play (hidden only in Test per existing policy).
- No curriculum, question bank, reward, movement, Sage tutoring, or mode/controller logic changed.
