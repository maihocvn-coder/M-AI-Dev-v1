# V356 Resource Preview / Save Functional Audit

## Root causes found
1. Teacher/Admin Resource Studio still loaded the old `maihoc-resource-studio-v209.js` URL. Browser cache could therefore continue executing the older preview code even after the file had been changed in-place.
2. Canonical CEFR worksheets/tests store canonical `questionIds`; the resource card showed metadata, but the editable-copy editor only knew the legacy `blocks/items` model. A copied CEFR worksheet/test could therefore appear empty even though its question references were preserved.
3. Canonical resource cards did not expose a distinct Preview action; the right pane was being used as an implicit preview, making it unclear whether content had actually resolved.
4. Save-to-library had no post-copy verification message tied to the copied record.

## Repairs
- New cache-safe `maihoc-resource-studio-v356.js` and `maihoc-scope-access-v356.js`; Teacher/Admin Resources pages explicitly load them with `?v=356`.
- CEFR worksheet/test preview resolves every `questionId` against `MAIHOC_CEFR_DATA.questions` and renders prompt, choices and correct answer (or open-response/rubric label).
- Added explicit **Preview content** action for canonical resources.
- Save to My Library now verifies that the copied resource exists before reporting success, switches to My Library, opens the saved copy, and preserves `questionIds`.
- Editable CEFR copies now render their linked questions instead of falling through to the legacy blank block/item editors. Questions can be removed from the copy without changing the canonical bank.
- CEFR data/test/worksheet scripts are cache-busted on Resource pages.

## Data integrity checks
- CEFR bank: 420 seed/prototype question records.
- CEFR worksheets: 70.
- Worksheet question references: 700.
- Missing worksheet question references: 0.

## Important content QA finding
The current 420-question CEFR bank is still a prototype/seed bank and is **not content-ready**. Example: some Pre-A1 grammar/reading/speaking items are substantially above Pre-A1. Therefore v356 fixes Resource Preview/Save/Edit functionality but does not certify the current CEFR questions as level-valid. The bank needs a separate CEFR content regeneration/QA pass before production use.

## Static checks
- JS syntax checked with Node.
- Resource page script wiring checked.
- All 700 CEFR worksheet question references resolve.
- ZIP integrity checked.
- Browser E2E click-through was not executed in this environment.
