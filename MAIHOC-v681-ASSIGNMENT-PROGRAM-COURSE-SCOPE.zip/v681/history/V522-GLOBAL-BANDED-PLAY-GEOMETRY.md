# v522 — Global banded Play geometry

Baseline: v521.

Changes are limited to the consolidated shared MainScreen CSS authority:
- Feedback is centered in its own visual band between Question and Answer Holders.
- Feedback remains a compact fit-content pill and does not shift answer geometry.
- Character and controller now occupy separate bottom bands: character above, controller below.
- Narrow/container-height rules preserve the same separation.
- No changes to question data, Answer Holder renderer, world art, engine, Sage, reward, report logic, or navigation.
