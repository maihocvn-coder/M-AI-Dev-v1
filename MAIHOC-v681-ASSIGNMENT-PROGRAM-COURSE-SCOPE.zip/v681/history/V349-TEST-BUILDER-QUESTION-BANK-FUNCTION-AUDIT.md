# v349 Test Builder / Question Bank Functional Audit

## Problem reproduced from v348
- Create New Test was hard-wired to the School English builder.
- The top "Choose question bank" links were navigation only, not an actual source control in the builder.
- There was no question browser/selector inside Create New Test.
- M-AI CEFR used a separate builder route, fragmenting the workflow.
- School English custom test save incorrectly persisted `grade: 6` regardless of selected grade.

## Repairs in v349
1. Unified Test Builder now has a real question-bank source selector:
   - M-AI School English Question Bank
   - M-AI CEFR Question Bank
2. School English path:
   - Grade -> Unit(s) -> Learning Objective(s) -> filtered question browser.
3. CEFR path:
   - CEFR Level -> Skill -> Content Target -> filtered question browser.
4. Exact questions can be checked before generation.
5. Select visible / Clear selection work on the current filtered pool.
6. If no individual questions are checked, Generate uses the requested count from the visible filtered pool.
7. Preview -> Save Test -> Existing Tests flow uses the selected source and questions.
8. School English saves the actual selected grade (removed hard-coded Grade 6 bug).
9. CEFR Question Bank "Create test from selected" now routes into the unified Test Builder with CEFR source active.
10. Legacy CEFR test-builder route redirects to the unified builder.
11. QA metadata remains hidden from teacher/student question display.

## Static/data checks performed
- Inline JavaScript syntax: PASS for unified Test Builder and CEFR bank page.
- Required DOM control IDs: PASS; no duplicate IDs.
- CEFR bank: 420 records, unique IDs, prompts present, MCQ answer indices valid.
- CEFR levels available: Pre-A1, A1, A2, B1, B2, C1, C2 (60 records each in current prototype data).
- School English bank JSON present for Grades 1-12.
- Stale teacher-facing `M-AI Question Bank` label search: no matches in audited teacher/resource paths.

## Limitation
No browser automation runtime (Playwright/jsdom) is installed in this environment, so this release is syntax/data/route audited but not claimed as a live browser click-through test.
