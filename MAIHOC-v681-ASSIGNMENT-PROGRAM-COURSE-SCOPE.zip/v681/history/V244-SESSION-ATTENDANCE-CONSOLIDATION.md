# v244 Session / Attendance Consolidation

- Canonical session identity remains in `assets/js/maihoc-calendar.js`.
- Added `MAIHOC_SESSION_OPS` as the shared operations layer for attendance marking, join evidence, attendance mode, dual Teaching/Admin confirmation, and session confirmation state.
- `MAIHOC_ATTEND` is now a compatibility alias to `MAIHOC_SESSION_OPS`.
- Removed `assets/js/maihoc-attendance-v236.js` and all direct page dependencies on it.
- `maihoc-teaching-records-v211.js` keeps teaching-hours/report APIs, but delegates attendance operations to the shared Session Operations layer.
- Added one-time migration bridge from legacy `maihoc.attendance.v211` records into teaching-side confirmation rows when confirmation data is absent.
- Teaching-side confirmation writes back to canonical student attendance, preventing Parent Attendance and Admin Attendance from diverging going forward.
- Teacher Hours remains a separate reporting/approval ledger because reported/confirmed payable hours are not the same entity as scheduled session duration.

QA: all JS parses with `node --check`; direct local JS/CSS dependency scan reports zero missing dependencies.
