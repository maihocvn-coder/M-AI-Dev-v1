# V572 — Game Geometry Single Authority Cleanup

- Removed obsolete V559–V564 liquid/geometry blocks from `maischoolenglish.css`.
- Removed live Play geometry ownership for bottom stack, character row, controller row, character anchor, answer lane and collapsed Sage launcher from `maischoolenglish.css`.
- Replaced the existing GAME FIT CONTRACT in `maihoc-responsive.css`; this is the sole live Play geometry authority.
- Top anchor: question/answers. Bottom anchor: character/controller/Sage. The world band between them is flexible.
- Width-driven answer reflow may consume flexible world space but cannot derive or push the bottom anchor.
- Removed Game `data-mse-height` fixed classification; fit state is based on actual overlap (`tight` vs `fit`).
- Site-wide responsive states remain in the canonical responsive runtime for non-game page presentation.
