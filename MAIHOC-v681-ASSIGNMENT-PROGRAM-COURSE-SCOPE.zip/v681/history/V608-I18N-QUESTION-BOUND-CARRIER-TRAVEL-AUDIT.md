# V608 audit — controls i18n + question-bound carrier travel

- Audited Grade 1 control labels: v607 rendered Vietnamese `label` fields directly even when UI locale was English.
- Replaced control rendering with locale-aware labels sourced from canonical `maihoc.ui.language`; listens to `maihoc:languagechange` and rerenders controls.
- Audited carrier lifecycle: v607 carriers were screen-fixed and rendered only on `questionchange` after world travel, so they appeared to follow the cat / pop in separately from the next scene.
- Added `maihoc:questionapproach` from the world transition authority with the actual next question before travel starts.
- Grade 1 answer carrier lane is tagged by stable question key (`data-question-key`). Next-question carriers are staged disabled, enter from the right for the same duration as world travel, then the matching `questionchange` activates the existing set instead of recreating it.
- Completed-question carriers are removed from DOM after catch; non-selected carriers no longer use the old exit/blur-like animation.
- No new version-specific CSS override file/block was added; lifecycle rules were changed in the existing canonical carrier section.
