# v660 — Single Student Home Route Cleanup

Canonical Student Home: `student/home/home.html`

Cleanup performed:
- Deleted legacy `student/home.html` redirect file.
- Audited executable source for navigation/routing references to `student/home.html`.
- Fixed Account Portal "Continue as Student" link to `student/home/home.html`.
- Fixed shared universal theme `roleHomes.student` to `student/home/home.html`.
- Fixed shared universal Student `Home` navigation item to `student/home/home.html`.
- Existing login, role switch, impersonation and canonical routing references already pointed to `student/home/home.html` and were retained.
- Historical/audit manifests were not rewritten because they are not runtime navigation authorities.

Static QA:
- Remaining executable references to `student/home.html`: 0
- Legacy file exists: no
- Canonical Student Home remains: yes
- `maihoc-universal-theme.js` syntax: PASS
