# V527 — Answer Holder Reflow Authority Fix

Baseline: v526.

Audit found the stage comments promised 2-column and 1-column layouts, but the CSS never changed `grid-template-columns` at those stages. The base `repeat(auto-fit,minmax(min(220px,100%),1fr))` therefore remained the winning column definition. `grid-auto-flow: row` at <=560px does not force one column.

Fix:
- <=720px: explicit `grid-template-columns: repeat(2,minmax(0,1fr))`.
- <=560px: explicit `grid-template-columns: minmax(0,1fr)`.
- MainScreen remains the sole named container authority.
- No JS, Sage logic, character, engine, curriculum, reward, or navigation changes.
