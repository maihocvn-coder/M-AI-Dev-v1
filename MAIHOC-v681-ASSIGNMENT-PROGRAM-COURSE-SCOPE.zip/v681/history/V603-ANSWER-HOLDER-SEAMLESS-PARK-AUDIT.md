# V603 — Answer Holder + Seamless Park Audit

## Root cause
The v596 answer-holder layout contract used `.mh-fish-holder-lane` in the canonical responsive geometry authority. The visual carrier was renamed to butterfly, and the renderer emitted `.mh-butterfly-holder-lane`, but the responsive authority was not renamed. The answer DOM (badge/text/audio) still existed, but its lane lost the canonical gameplay positioning/grid geometry.

## Consolidation
- Replaced carrier-specific lane naming with one generic `.mh-answer-holder-lane` authority.
- Updated the renderer and existing responsive authority in place.
- Removed old fish/butterfly lane-name dependencies; no compatibility selector or appended override was added.
- Kept butterfly as a replaceable visual inside the generic holder.

## Seamless park path
The previous path polygon had different left/right edge heights (`45%` vs `16%`), so repeated segments could never join seamlessly. Replaced it at the canonical park path rule with a constant-width path whose left and right boundaries are identical (`12%` top, `88%` bottom). Adjacent reusable park segments now share the same terrain/path seam; landmarks/decorations may vary independently.
