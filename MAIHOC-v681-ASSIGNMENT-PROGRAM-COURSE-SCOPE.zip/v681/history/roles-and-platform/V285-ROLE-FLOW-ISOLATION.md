# v285 Role Flow Isolation

## Canonical rule
A page has one role-context owner. Higher roles may manage lower-level records, but must not be routed into the lower role's workspace/page. **Manage down; switch sideways.**

## Analytics split
- Super Admin / Management Admin → Platform Performance & Management Analytics. Filters: department, role, organization, individual.
- Curriculum Admin → Content Analytics in Content Audit.
- Organizational Admin → Organization Performance & Analytics. Filters: program, course, class, teacher/student/person within that organization.
- Teacher → Teacher analytics for own assigned courses only (role switch when the person is actually teaching).
- Parent → child/family progress only.
- Student → own progress only.

## Audit gates
1. Breadcrumb role must match active workspace.
2. Hero/title must match page owner.
3. Filters must match role scope.
4. Data query must be bounded to role scope.
5. Navigation card must route to owner-specific page.
6. Guide must match active role only.
7. Higher role manages lower records without impersonating/labelling itself as lower role.
8. Preview As is QA; Impersonate is separate and audited.
9. No generic page may silently change meaning based only on who linked to it.
10. Shared code/data services are allowed; shared role-specific UI identity is not.
