# v383 — Backend CSS & Database Consolidation

## Goal
Create protected backend-owned source folders so UI/page updates do not overwrite canonical styling or data.

## Canonical ownership
- `backend/css/` — canonical CSS source of truth.
- `backend/database/` — canonical database/data source of truth.
- `backend/architecture.json` — machine-readable ownership contract.

## CSS consolidation
- Centralized all 47 pre-existing external CSS files under `backend/css/`.
- Rewrote 889 HTML stylesheet references so every page now loads CSS from `/backend/css/...`.
- Converted all legacy CSS files outside `backend/css` into compatibility import shims. They are not editable sources anymore.
- Extracted 137 inline `<style>` blocks from 108 HTML pages into `backend/css/pages-inline/...`.
- Consolidated Resource Library v359 + v360 into `backend/css/modules/resource-library.css`.
- Normalized Grades 7–12 missing Sage stylesheet references to the shared canonical Sage stylesheet used by the current package.
- Result: zero HTML `<style>` blocks and zero HTML stylesheet references outside `/backend/css/`.

## Database isolation
Canonical snapshots now live in:
- `backend/database/data/`
- `backend/database/assets-data/`
- `backend/database/core-database/`

The existing `/data`, `/assets/data`, and `/core/database` folders remain runtime compatibility mirrors so the current static prototype is not broken.

Do not edit those runtime mirrors directly. Update `backend/database` then run:

`node tools/sync-backend-database.js`

Validation tool:

`node tools/check-backend-boundaries.js`

## QA performed
- 889 CSS hrefs checked; 0 missing.
- Backend CSS `@import` targets checked; 0 missing.
- 243 JavaScript files passed `node --check`.
- 48 backend database JSON files parsed successfully.
- Backend/database mirror hash check passed.
- All legacy CSS files confirmed as compatibility shims.

## Important architecture rule
Future page/template/function updates should modify HTML/JS without copying CSS or database files into page folders. New shared styling belongs in `backend/css`; new canonical data belongs in `backend/database`.
