# v259 Grade 6 Runtime Bootstrap Repair

## Root causes repaired
1. v258 `engine/bank-data.js` exported a raw 1,680-question array, while `game.js` requires `MAIHOC_G6_BANK.levels`, `.skills`, and `.questions`. This caused a fatal exception during state initialization before click handlers could bind.
2. `game.js` expected Report UI IDs (`reportDialog`, `reportItem`, `category`, `reportDescription`, `submitReport`) that were absent from `play.html`, creating a second fatal bootstrap path.
3. Grade 6 play page title was contaminated with `Grade 5`.

## Repairs
- Restored runtime bank object from canonical `grade6-bank.json`; canonical content remains 1,680 questions.
- Restored complete Report dialog DOM contract.
- Corrected Grade 6 page identity.
- Added runtime error diagnostic marker.
- Added `qa-grade6-runtime-contract-v259.js` as a release-blocking contract test.

## QA
- Runtime bank contract: PASS (12 levels / 7 skills / 1,680 questions).
- Required DOM references: PASS.
- Script dependencies: PASS.
- 132 JS files syntax checked: 0 failures.
- Grade 5 identity contamination in Grade 6 runtime folder: 0 matches.

## Limitation
Chromium is present in the build environment but did not complete a reliable headless DOM session in this container, so this package does not claim browser click E2E or acoustic audio verification. The regression that caused every control to be inert was reproduced from the source contract and repaired at its two fatal bootstrap points.
