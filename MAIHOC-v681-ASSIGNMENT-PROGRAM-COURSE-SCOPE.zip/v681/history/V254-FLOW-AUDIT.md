# v254 M-AI School English flow audit

## Root causes fixed
1. Grade Home and legacy Unit redirects passed `mode=play`, bypassing orientation.
2. Level Map click auto-started play instead of selecting a level during orientation.
3. Sage pronunciation inherited generic/meta bank hints.
4. Pronunciation questions did not expose target-phoneme playback; Quick Quiz rendered no audio controls.
5. Phoneme and word playback were not explicit at the Sage UI boundary.
6. /t/ and /d/ were absent from the isolated phoneme map.

## Canonical flow
Grade -> Orientation -> choose Level/Unit -> choose Knowledge / Practice 10 / Play / Test -> question. Sage is visible at Orientation.

## Audio contract
- Isolated IPA target: `MAIHOC_PHONEME_AUDIO.play()` only. Never send isolated IPA to TTS.
- Orthographic English word: `MAIHOC_TTS.speak()` word pipeline.
- Pronunciation Sage and Quick Quiz expose both controls where relevant.
- If a target lacks an isolated recording, do not silently substitute word TTS for the IPA symbol.
