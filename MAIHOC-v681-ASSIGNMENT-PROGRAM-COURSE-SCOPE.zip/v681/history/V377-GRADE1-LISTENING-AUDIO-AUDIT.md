# v377 Grade 1 listening/audio audit

- Audited all 960 Grade 1 canonical questions.
- 640 questions are listening-like by prompt/type; 160 are `audio_choice`.
- Every `audio_choice` has a non-empty `audioPrompt`, hidden transcript, hidden stimulus placeholder, valid answer index, unique choices, and exact heard-target ↔ correct-option match.
- Every prompt that tells the learner to listen has a playable audio source (`audioPrompt` or an appropriate stimulus source).
- Runtime now renders a dedicated question-level `▶ Nghe` control whenever `audioPrompt` exists.
- The heard target itself is not rendered as text. Answer-option speaker buttons remain separate and continue to read each option.
- Canonical question bank was re-synced into `engine/grade1-bank.json` and `engine/bank-data.js`.
