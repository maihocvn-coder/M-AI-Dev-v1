# V316 — Global VI/EN UI + Protected Learning Content Audit

## Canonical i18n boundary

Default UI language is Vietnamese. Admin, Teacher, Parent, and Student use the same VI/EN UI rule.

### Translatable system UI
Navigation, breadcrumb, page headings, system function names, descriptions of what a function does, instructions/help text, buttons, form labels, placeholders, filters, table headings, system statuses, modal text, confirmation text, validation/errors, toasts, empty states, tooltips, scheduling/assignment/gradebook controls, and Sage controls.

### Never auto-translate
Learning/resource content: Knowledge, vocabulary, pronunciation/phonemes, grammar teaching text/examples, listening scripts, reading passages, speaking/writing tasks, questions, options, answers, explanations, Sage teaching/coaching content, curriculum/LO canonical content, worksheet/test/resource bodies, and learning audio transcripts.

Proper/user data also remains unchanged: person/organization/school names, authored book/program/resource titles, email, URL, slug, filename, IDs, and code/script.

## Release audit

- HTML pages scanned: **378**
- HTML pages loading `maihoc-i18n-v316.js`: **378 / 378**
- Default locale: **VI**
- Visible selector: **VN / EN**
- Existing language preference migration: **enabled** (v315/v314/v313/v312 → v316)
- Admin UI dictionary expanded: **yes**
- Teacher UI dictionary expanded: **yes**
- Parent UI dictionary expanded: **yes**
- Student system UI dictionary expanded: **yes**
- Student learning content excluded from automatic translation: **yes**
- Sage controls can translate while Sage teaching content remains protected: **yes**
- Resource/editor controls can translate while resource bodies remain protected: **yes**
- Protected JSON/MD/TXT/CSV files compared with v315: **290**
- Protected data files changed by i18n work: **0**
- JavaScript syntax check: **PASS**

## Regression rule

A VI → EN → VI toggle must never alter question text, answers, Knowledge, Sage teaching content, curriculum/LO content, resource bodies, IDs, URLs, names, or authored learning content. Any such change is a release-blocking failure.

## Runtime note

This package passed static/source audits and JavaScript syntax validation. A real localhost browser click-through is still required for visual/runtime confirmation of every dynamic modal/toast because this environment did not run Playwright.
