# v361 Library navigation / promo placement
- My Library remains default.
- M-AI promotional arrow slider is a compact top-of-page discovery strip above the Library workspace.
- Left side is a Library navigation list, not a carousel.
- M-AI Library expands in the left list to M-AI School English and M-AI CEFR.
- School English retains Grades 1–12 hierarchy.
- CEFR retains Pre-A1–C2 hierarchy with Tests and Worksheets.
- Full Preview / copy / assign behavior remains.
- Organization admin copy destinations remain My Library and Organization Library.
