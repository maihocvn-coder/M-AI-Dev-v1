# v391 Grade 1 Knowledge UX audit

Scope: all 16 Grade 1 levels × Vocabulary / Phonics / Sentence Patterns.

- Knowledge topic navigation is horizontal at the top of the Knowledge content area.
- Knowledge content is full width below the topic navigation; shared flex/grid rules cannot move it into a right-side column.
- Removed the nested 45vh Knowledge scroller; the main page owns vertical scrolling.
- Vocabulary uses responsive cards/grid; Phonics and Sentence Patterns remain in the same full-width content region.
- Mobile keeps topic navigation horizontal/scrollable.
- Knowledge UI labels now read the canonical `maihoc.ui.language.v326` locale instead of forcing Vietnamese.
- Internal skill IDs remain stable while visible labels follow VI/EN.
