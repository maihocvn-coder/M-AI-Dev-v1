# M-AI Học v304 — Impersonation + Organization Website Audit

- Impersonation now supplies effective user, role, and organization to authorization and navigation.
- Super/management-only routes are blocked while impersonating lower roles; UI renders target-role navigation.
- Organization context selector uses a responsive non-overlapping grid and is hidden during impersonation.
- Organization Website uses one draft source for edit/visual preview; header and Featured Programs header accept image/video URLs.
- Organization Admin can add and edit 2/3/4-box content rows; default prompt is 3.
- Save Draft rerenders the visual editor; Preview Draft reads the same draft; Publish requires preview.
