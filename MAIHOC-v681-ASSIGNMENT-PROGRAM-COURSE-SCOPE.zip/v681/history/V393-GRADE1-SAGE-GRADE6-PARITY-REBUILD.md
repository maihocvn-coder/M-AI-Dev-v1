# v393 Grade 1 Sage — Grade 6 parity rebuild

- Knowledge Sage and Question Sage are now mutually exclusive runtime contexts.
- Entering Knowledge emits question=null and MAIHOC_CURRENT_QUESTION returns null in Knowledge mode.
- Shared Sage no longer clears Grade 1 Knowledge context on questionchange.
- Knowledge context has priority when active.
- Grade 1 Knowledge Sage regenerated for all 48 concepts (16 levels × Vocabulary/Phonics/Sentence Patterns) using Grade 6 four-engine contract: Teach, Explore/Ask More, verified Quick Quiz, Play route.
- Question Hint now uses progressive authored question-bound scaffolds rather than only the first generic hint.
- Phonics keeps exact-audio safety: no isolated phoneme button without verified phoneme metadata.
