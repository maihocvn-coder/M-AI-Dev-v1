# M-AI Học History Archive

This directory preserves development evidence separately from the live application.

Rules:
1. Historical artifacts are immutable after archival.
2. Production HTML/JS/CSS must never import files from `history/`.
3. Every release must append an entry to `MASTER-CHANGELOG.md`.
4. `manifest.json` records the original path, archive path, SHA-256 hash, size, and archive date.
5. Current truth belongs in `docs/`, `config/`, `backend/`, or the runtime application — never in history.
6. New historical evidence is added; old entries are not rewritten.

The archive supports provenance and development chronology. It is not itself a legal determination of copyrightability or ownership.
