# v554 — Centered translucent feedback

- Replaced the small white Play feedback pill with one large centered overlay.
- Feedback uses translucent black (`rgba(0,0,0,.64)`) plus light backdrop blur.
- White high-contrast feedback text is centered vertically and horizontally.
- Removed inline controller geometry so CSS is the single visual authority for feedback.
- Feedback remains pointer-events:none and keeps the existing timing/logic.
