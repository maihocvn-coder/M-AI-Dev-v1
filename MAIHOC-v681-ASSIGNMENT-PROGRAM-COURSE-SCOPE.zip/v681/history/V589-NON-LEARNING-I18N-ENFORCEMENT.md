# v589 — Non-Learning i18n Enforcement

- Baseline: v588.
- Added `data-i18n-scope="ui"` to the general/public/account/Student/Teacher/Parent/Admin pages covered by the non-learning audit, without touching excluded game/engine/unit/question/content/worksheet/CEFR-bank paths.
- Explicitly tagged the English learning-question demo on public `index.html` as target/locked content; UI/support around it remains locale-controlled.
- Added missing canonical VI/EN pairs for public `index.html` and Student Home UI/support strings.
- Student Home static non-learning migration-required candidates: 0.
- Public `index.html` static non-learning migration-required candidates: 0.
- Updated audit logic to distinguish canonical visible-text pairs from genuinely unmigrated hard-coded locale candidates.
- Remaining pages continue to be reported by the audit tool; this release does not claim whole-site zero leakage.
- Source/syntax/static-audit verified. Browser VI→EN→VI runtime verification was not available in this build environment.
