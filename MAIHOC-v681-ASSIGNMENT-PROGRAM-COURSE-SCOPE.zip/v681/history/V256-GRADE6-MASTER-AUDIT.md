# v256 Grade 6 Master UX / Content Engine Audit

Scope: Grade 6 only. Do not propagate to other grades until user approves Grade 6.

## Flow contracts
- Game entry uses welcome/how-to-play state before queue rendering.
- Knowledge category navigation is sticky.
- Vocabulary is compact: word — meaning + speaker; example line + speaker.
- Word/example audio uses speaker/pause toggle; no large play controls.
- Pronunciation phoneme audio is skill-gated; slash text in Grammar cannot create phoneme audio.
- Listening and Speaking may have explicit content audio; Grammar is not inferred as pronunciation.
- Teaching rules in question stimulus are migrated to collapsed Hint.
- Sage non-pronunciation Hint is direct coaching, not a meta MCQ about how to answer.
- Sage avatar is rendered from maihoc.student.characters and opens Settings > Sage editor.
- Game scene rewardObject and collected bag object are identical.

## Data audit
- Grade 6 bank questions: 1680
- Grammar teaching-rule stimuli migrated to hidden hints: 62
- Remaining audited visible grammar formula stimuli: 0
- Reward object coverage: all questions
- Unique reward objects: 66

## Deliberate scope boundary
No Grade 1-5 or Grade 7-12 engine was migrated to these v256 Grade 6 master rules in this release.
