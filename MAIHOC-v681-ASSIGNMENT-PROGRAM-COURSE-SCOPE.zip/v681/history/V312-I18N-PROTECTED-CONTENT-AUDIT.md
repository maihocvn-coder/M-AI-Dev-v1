# V312 UI Language / Protected Content Audit

Result: **PASS**

- HTML pages with VI/EN control loader: 378/378
- Default language: VI
- Preference storage: per-browser/account-compatible local preference key `maihoc.ui.language.v312`
- Translation scope: UI chrome and exact-match controls only
- Protected learning/resource selectors: enabled
- Protected resource/admin routes: enabled
- Protected JSON/MD/TXT/CSV files byte-compared with v311: 285; changed: 0
- Learning/resource payload mutation by this patch: 0

Hard rule: VI/EN changes UI language only. Learning resources, bilingual Knowledge explanations, questions/options/answers, Sage coaching, curriculum/LO content, authored website content, names, IDs and URLs are excluded from translation.
