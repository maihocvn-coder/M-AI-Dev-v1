# v352 Resource Builder Function + UX Audit

## Root causes found
1. School English builder used the lightweight question-bank index. That index is for browsing/search and omits full answer/options payloads for many records. Builder now loads each grade canonical `question-bank.json` first, with index fallback only if unavailable.
2. CEFR Test Builder depended on an asynchronous fetch and could render before/without bank data in some local/static serving conditions. v352 ships an embedded CEFR data asset and the loader prefers it.
3. CEFR Worksheet Builder also depended on runtime JSON fetch for both bank and premade worksheets. It now prefers embedded data assets.
4. Builder UI used oversized source cards and excessive vertical spacing. v352 compacts source choice, fields, steps, hero, and helper copy while preserving keyboard focus/contrast.

## Intended teacher flow
Teacher does not browse individual questions. Test/Worksheet Builder: source → curriculum scope → count/template/settings → Generate → Preview → Save. Questions are resolved behind the scenes from the selected canonical bank.

## Static verification
- 420 CEFR seed records present: 60 per CEFR level.
- Grade 1–12 canonical question-bank.json files load and contain usable question records.
- Test and Worksheet pages both include embedded CEFR data.
- JS syntax checks pass.

## Limitation
No browser E2E automation was available in this environment; click-through is not claimed.
