# v250 Pre-Live Infrastructure Hardening

## Added
- Optimistic concurrency in MAIHOC_DATA records via `_rev` and `expectedRevision`.
- Stale writes throw `MAIHOC_REVISION_CONFLICT`; they do not silently overwrite the newer record.
- `MAIHOC_AUTH` boundary with separate demo and production providers.
- Production mode requires a server-verified auth context and fails closed on unverified browser identity.
- `MAIHOC_INFRA` backup/DR provider contract. Browser code can request/status backup operations but never receives DB credentials and never treats local application History as infrastructure backup.

## Live deployment contract
A production backend must implement durable server storage, server-side authorization, authenticated API requests, automated backup/retention/PITR, and restore drills. The local adapter remains for demo/local development only.

## Recovery separation
v249 application recovery remains object-scoped. v250 infrastructure backup is a separate provider boundary. Code/config rollback, object recovery, and database disaster recovery must not be conflated.
