# M-AI Học — Master Development & Change History

> Continuous human-readable project history. Earlier entries below were reconstructed on 2026-09-30 from retained project artifacts and development records. From v384 forward, entries are appended at release time and are not rewritten.

## 2026-09-30 — v384 — Repository & History Architecture Consolidation
**Area:** Whole platform architecture

**Why:** Production runtime, QA scripts, versioned reports, backups, and historical evidence had accumulated in the project root. This made the active implementation difficult to identify and increased the risk that unrelated changes could affect one another.

**Changed:**
- Established `history/` as an immutable development-evidence archive.
- Archived 211 root-level versioned/QA/audit/revision artifacts while preserving their original bytes and SHA-256 hashes in `history/manifest.json`.
- Established `backend/js/`, `config/`, `tests/`, and clearer `tools/` boundaries alongside the existing canonical `backend/css/` and `backend/database/` areas.
- Kept live application routes in their existing locations for this migration so the current site is not broken by a mass route rewrite.
- Added architecture guards preventing production references to `history/` and discouraging new versioned artifacts in the project root.
- Established this Master Change Log as the separate chronological record for all future releases.

**Behavior affected:** Repository/development architecture only; no intentional student/teacher behavior change.

## 2026-09-30 — v383 — Canonical CSS & Database Boundaries
**Area:** CSS / database architecture

- Centralized canonical CSS under `backend/css/`.
- Centralized canonical data under `backend/database/` with compatibility/runtime mirrors where required.
- Added architecture and synchronization checks so future data/style updates can be isolated from page code.

## 2026-09-30 — v382 — Grade 1 CSS Consolidation
**Area:** School English / Grade 1 game UI

- Consolidated competing Adventure Bag positioning rules.
- Established a single top-right bag contract and removed legacy drag/dock positioning behavior from the active implementation.

## 2026-09-30 — v381 — Grade 1 Continue / Bag Consistency
**Area:** School English / Grade 1

- Reworked Continue behavior toward direct question entry.
- Standardized Adventure Bag positioning behavior and continued Grade 1 game-state repair.

## 2026-09-29 — v300–v301 — Resource & Subscription Administration
**Area:** Resource system / administration

- Renamed My School English to M-AI School English across the platform.
- Unified subscription-plan editing around Edit → Save Draft → Publish.
- Added canonical Resource Management with content browsing, bulk operations, validation, snapshots/history, and restore behavior.

## 2026-09-28 — v252–v255 — Shared School English Runtime & Resource Work
**Area:** School English / resources / Sage / audio

- Expanded resource persistence and editable organization-resource behavior.
- Established shared Grade 1–12 entry/orientation behavior.
- Separated phoneme and word-audio pipelines and tightened phoneme mapping behavior.
- Added Grade 1–12 welcome-state work and continued Sage/Knowledge semantic QA.

## 2026-09-26 — Resource Authoring Architecture
**Area:** Teacher resources

- Defined one Test template, five Worksheet templates, and five Game templates with editable samples.
- Consolidated authoring around a shared Resource Builder and canonical question/resource references.
- Continued canonical School English source and impersonation/access architecture work.

## 2026-09-21–2026-09-22 — Grade 6 Canonical Unit & Sage Development
**Area:** Grade 6 / unit template / Sage

- Developed successive canonical unit-template iterations including render safety, Sage master scaffolding, Explore language-frame repair, and communication guidance.
- Grade 6 Unit 2 progressed through sound repair, learning-path repair, clean audit, and structured validation stages.
- Established Grade 6 as the reference implementation for later School English grade generation.

## 2026-09-19 onward — Character, Wallet & Learning-Game Foundations
**Area:** Student experience / Sage / game system

- Developed canonical Sage avatar/wardrobe behavior and student customization work.
- Developed wallet/coin/reward concepts and game-item collection behavior.
- Began the current multi-role, curriculum-driven M-AI Học platform development sequence.

---

## Release-entry rule
Every future release must append: **date, release, area, problem/why, changes, affected components, data/content impact, verification, and evidence path**. Historical entries are append-only.

## 2026-09-30 — v385 Non-destructive Repository Recovery

### Problem
The v383/v384 consolidation changed live stylesheet/data paths and altered the runtime dependency graph. This caused existing pages, including the homepage, to lose their established presentation/behavior.

### Decision
Rollback the live application to the verified pre-consolidation v382 runtime. Repository organization is now additive only: organizational copies/history may be created, but live paths/imports are not changed until each subsystem is migrated and visually regression-tested.

### Changed
- Restored the complete v382 application/runtime as the live baseline.
- Kept History as a separate, non-runtime archive.
- Added `repository/css`, `repository/js`, and `repository/database` as organizational snapshots only.
- Did NOT rewrite HTML stylesheet/script/data references.
- Did NOT move or delete runtime files.

### Migration rule going forward
One subsystem at a time: copy → compare → switch references → visual regression test → only then retire the old source. No whole-site path rewrite.

## 2026-09-30 — v387 Grade 1 Single-Shell / Single-Engine Consolidation
- Area: M-AI School English / Grade 1 / Game Design
- Decision: Grade 1 uses one canonical UX shell and one Letter Catch engine across all 16 units.
- Changed: Removed per-unit game-engine labels (Word Fishing, Jump & Catch, Build & Place, etc.) from Grade 1 runtime metadata; every level now reports Letter Catch.
- Changed: Grade 1 Play UX no longer changes mechanic/status from legacy question `engine` metadata. Question metadata remains for learning/audio semantics.
- Changed: All legacy Unit HTML redirects now use the canonical `level=` route; runtime still accepts old `unit=` URLs for compatibility.
- Preserved: Unit titles, curriculum content, questions, theme colors/landmarks, Knowledge, Practice, Test, Sage, Adventure Bag, coin rules and progress.
- Architecture rule: Unit-specific code supplies content/theme only; it must not redefine Grade 1 shell or gameplay UX.
