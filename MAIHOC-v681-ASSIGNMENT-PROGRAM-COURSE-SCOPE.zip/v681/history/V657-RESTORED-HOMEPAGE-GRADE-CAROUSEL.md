# v657 — Restored Homepage + Student Grade Book Carousel

- Restored the pre-v656 public homepage design/content.
- Removed only the old hero game/character preview.
- Moved the existing M-AI School English grade-book section directly below the hero.
- Kept the v656 real embedded 10-question School English demo directly after M-AI School English.
- Sage and the remaining original homepage sections follow after the demo.
- Rebuilt Student Home School English hero: left = primary School English CTA; right = one clickable Grade book at a time, with previous/next arrows for direct Grade navigation.
- Grade books use the same book visual language as the M-AI School English page and render the canonical Grade mascot library.
- Phone layout stacks content vertically; Student navigation remains hamburger.
