# v528 — Game Runtime Ownership Consolidation

Goal: one behavior, one JS owner; group runtime by subsystem and remove the old live aliases.

Changes:
- moved legacy global game registry -> `assets/js/game/core/game-registry.js`; deleted old live path.
- moved global game UX -> `assets/js/game/ui/game-ui-runtime.js`; deleted old live path.
- moved Grade 1 movement/controller -> `assets/js/game/character/character-movement.js`; deleted old live path.
- moved Sage master runtime -> `assets/js/game/sage/sage-runtime.js`; deleted old live path.
- updated live School English pages to grouped canonical paths.
- removed the second duplicate `character-renderer.js` load from all Grade 1-12 `play.html`; head/defer load remains.
- added `assets/js/game/OWNERSHIP.md` as the authority map.

Not changed: curriculum banks, question content, reward authority, world art, navigation, CSS design, Grade 1 visual behavior.
- moved `maihoc-grade-character-v333.js` -> `game/character/grade-character-library.js` and updated live homepage references.
- deleted unreferenced legacy `assets/js/maihoc-game-world.js`; world ownership is now only under `assets/js/game/world/`.
- deleted dead repository mirror copies of School English CSS/game registry/Sage/world and stale mirrored Grade 6 play page, so audits cannot encounter a second inactive runtime authority.
