# V532 — Grade 1 Controller Consolidation

- Removed physical `student/my-school-english/grade1/engine/game.js`.
- Grade 1 now loads canonical `assets/js/game/core/school-english-controller.js`.
- Renamed Grade-1 boot globals to generic School English controller aliases.
- Removed direct `#cat.className = ...` ownership from the controller; it emits `maihoc:characterstate` events.
- `game/character/character-movement.js` is the visual-state consumer for the Grade 1 character.
- Character Row now explicitly resets legacy `.cat` absolute positioning to normal row flow.
- Controller Row explicitly resets legacy absolute controller geometry.
- No new versioned runtime JS/CSS files were introduced.

Note: Grades 2–12 still have their existing page controllers in this release; this change removes the Grade 1 local controller and establishes the canonical shared controller path without silently changing their curriculum/runtime behavior.
