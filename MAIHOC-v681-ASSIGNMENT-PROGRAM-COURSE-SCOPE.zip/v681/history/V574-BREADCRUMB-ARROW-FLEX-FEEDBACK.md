# V574 — Breadcrumb Arrow + Flexible Feedback

- Replaced compact-game curtain placement: the transparent arrow is now mounted inside the canonical breadcrumb row and absolutely centered in that row, so it contributes zero height and shares the same grid band as the hamburger control.
- Removed the separate floating-header vertical arrow position.
- The game fit runtime now exposes the actual flexible world band between the answer lane and bottom-anchored character/controller stack.
- Replaced the old full-scene centered feedback geometry (`inset:0`, `min-height:78px`) with a compact content-sized feedback card centered only inside that measured flexible band.
- Feedback no longer owns a fixed minimum height and cannot be used to push the bottom anchor.
- No new stylesheet or version override block was added; existing canonical rules/functions were replaced in place.
