# V297 Resource Flow & Click Audit

## Canonical model
- Content Studio = site/app HTML pages only.
- Learning Resources = reusable learning materials.
- Game Books = collections of games + aligned banks/content. M-AI School English is seeded as the built-in Game Book.
- Workbooks = collections of worksheets and/or tests.
- Curriculum Truth remains a separate alignment layer.

## Round-trip update
Bulk Download / Update now uses a scoped resource group: type, collection, grade, unit. Download exports the current group. Upload shows replacement impact and requires explicit Yes/No confirmation. Replacement saves a full previous snapshot. History & Restore can restore the previous state and records the restore as another revision.

## Samples
Every built-in resource type has a real script sample. Question Banks have XLSX + script. Worksheets, Tests and Workbooks have XLSX + PDF + script. Samples include actual example questions/content rather than empty schemas.

## Question reports
Grade 6 game reports stored under `maihoc.schoolEnglish.reports` are imported into Content Audit. Learning Resources includes a direct Question Reports route. Reported questions can be previewed, edited, sent to review, approved and inspected through history.

## Audit fetch repair
Content Audit no longer depends only on runtime fetch for its canonical index/registry. V297 loads generated local JS data first and retains fetch as fallback, preventing the prior blank `Failed to fetch` audit state in local preview environments.

## Static click/content audit
`V297-CLICK-CONTENT-AUDIT.json` scans HTML pages for broken relative links and unlabeled buttons. Current result: 0 broken relative links and 0 unlabeled buttons across the scanned HTML set. This static audit does not claim every runtime state is semantically correct; critical resource actions were separately wired in the V297 Learning Resources controller.
