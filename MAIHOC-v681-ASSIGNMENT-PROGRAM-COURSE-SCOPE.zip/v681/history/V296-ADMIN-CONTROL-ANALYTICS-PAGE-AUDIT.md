# v296 Admin Control / Analytics / Page Flow Audit

- Management Admin can edit organization plan definitions and organization overrides.
- Organization selector is populated from the organization store and supports search + browse.
- Teacher and Student browse controls expose scoped people records.
- Organization-specific exceptions require a reason when seat overrides are used; promotion/group code is stored with the organization subscription record.
- Subscription changes remain in audit history with actor, role, time, action, and organization ID.
- Content Studio now has Browse Pages beside Search Pages.
- Student Home preview path repaired to student/home/home.html; Parent Home repaired to parent/home/home.html.
- Content/Resource Analytics now includes a usage graph.
- Management Analytics now includes a platform overview graph.
- QA target: no label-only controls; Browse/Search/Save/Reset/Preview controls have actions.
