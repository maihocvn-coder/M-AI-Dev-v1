# v678 — School English Library grade coverage + preview restoration

- School English game catalog now exposes Grades 1–12, Units 1–12 (144 canonical game references).
- Added Grade filter (All grades, Grade 1 … Grade 12).
- School English results are grouped by Grade for scanning.
- Restored the live visual game preview used previously instead of the synthetic placeholder art.
- In hover preview only, question/prompt and controller overlays are hidden so the world/character scene remains clean.
- Open continues to use the full canonical material viewer; assignment behavior is unchanged.
