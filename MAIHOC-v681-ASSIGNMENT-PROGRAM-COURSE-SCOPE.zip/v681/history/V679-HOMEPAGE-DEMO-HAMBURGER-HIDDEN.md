# v679 — Public homepage demo hamburger hidden

- Public School English preview (`preview=1`) no longer creates or displays the School English side-navigation hamburger.
- The side-navigation backdrop is also suppressed in public preview.
- Normal authenticated School English pages retain their responsive hamburger/navigation behavior.
- No gameplay, Jump/contact, carrier, Sage, question, reward, or world logic changed.
