# v595 — Game Auto Travel Between Questions

Baseline: v594 School English Content Authority.

## Scope
Prototype the requested continuous-adventure transition in Grade 1 Level Play without changing Knowledge, Question Bank, Sage content, Engine Registry, reward authority, or the v594 content authority.

## Behavior
- Correct answer keeps the existing collect/reward/praise sequence.
- Before the next Level Play question renders, the character automatically walks to the next visual checkpoint.
- Answer/controller interaction is locked during the transition.
- Wrong answers remain at the current checkpoint and continue the existing retry/Sage flow.
- Practice mode retains its compact question transition; the prototype is intentionally limited to Level Play.
- Character movement owns `autoTravel()`; the question/controller only requests the transition. Question content does not contain movement logic.
- Five liquid visual checkpoints are reused cyclically. At the end of a strip the character walks to the right edge and starts the next strip from the left, avoiding a direct visual teleport between ordinary adjacent questions.

## Verification
- Modified JS files pass `node --check`.
- ZIP integrity checked after packaging.
- Browser animation/runtime behavior is not claimed as browser-verified in this release.
