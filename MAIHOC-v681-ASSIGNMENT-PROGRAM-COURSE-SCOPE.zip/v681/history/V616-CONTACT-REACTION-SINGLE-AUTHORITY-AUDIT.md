# V616 — Carrier Contact + Character Reaction Single Authority Audit

## Audit findings
1. Character action success was not contact-gated: jump submitted the target at a fixed 320 ms point even if character/carrier rectangles never intersected.
2. Reaction runtime animated `#cat` while locomotion also animated `#cat`, creating competing transform/translate ownership.
3. Reaction runtime injected a second CSS authority at runtime instead of using canonical `assets/css/maischoolenglish.css`.
4. School English controller still emitted legacy `maihoc:characterstate` commands in parallel with semantic answer events (`maihoc:answercorrect`, `maihoc:answerwrong`).

## Consolidation
- `character-movement.js` is the only action/contact geometry authority.
- `character-reaction-runtime.js` is the only semantic emotion/reaction resolver.
- `maischoolenglish.css` is the only reaction visual/animation CSS authority.
- School English controller emits semantic result events; legacy `maihoc:characterstate` emissions were removed from the active controller.

## Contact contract
- Jump/Fly/Climb/Dive now watch real rendered rectangles on every animation frame.
- An answer is submitted only when `.g1v475-character-art` physically intersects the selected `.mh-answer-carrier`.
- No intersection by action end => `maihoc:charactermiss`; the English answer is not marked wrong.
- Clicking a carrier may aim/start the action, but cannot bypass collision.

## Reaction contract
- Correct => configured happy/celebration reaction.
- Wrong English answer => configured sad/cry/pout reaction.
- Gameplay miss => `oops` reaction, not English wrong.
- Level complete/perfect => configured larger celebration.
- Reaction animation is applied to the inner character SVG; outer `#cat` remains owned by locomotion/contact geometry, so emotion can display while jump/fly is completing.

## QA
- `node --check`: character-movement.js PASS
- `node --check`: character-reaction-runtime.js PASS
- `node --check`: school-english-controller.js PASS
- Runtime style injection in reaction runtime: 0
- Active core controller `maihoc:characterstate` emitters: 0
- `sample-cat.js` retains its sample listener for the Grades 2–12 sample kit and is not loaded by Grade 1.
