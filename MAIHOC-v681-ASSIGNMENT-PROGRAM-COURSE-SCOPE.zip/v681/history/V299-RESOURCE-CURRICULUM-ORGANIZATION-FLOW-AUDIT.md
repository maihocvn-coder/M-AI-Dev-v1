# V299 Resource / Curriculum Truth / Organization Context Audit

Implemented:
- Organization Administration now has organization search, dropdown context selection, and Browse Organizations; Sunshine is retained only as a sample organization, not the forced landing context.
- Resource type Browse buttons open a real Resource Browser with checkbox selection and columns: Preview, Name/Content, Location, Type, Status, Actions.
- Canonical M-AI School English questions are loaded into the Resource Browser from the canonical audit index, so bulk exports contain actual editable content rather than an empty custom-resource array.
- Selected resources can be downloaded as JSON script or Excel-compatible CSV, edited by script, curriculum-linked, status-changed, and revisioned.
- Bulk Update now uses cascading selectors (type, collection, grade, unit, skill, LO), shows actual matched rows with checkboxes, and replaces only checked IDs after confirmation.
- History/Restore records edits and replacements.
- M-AI School English is treated as a Game Book collection.
- New Curriculum Truth Library is collection-specific. M-AI School English has its own Curriculum Truth; LOs show linked resource counts and can be edited, added, archived, imported, downloaded, or pasted as script.
- Curriculum Truth no longer routes to the generic Learning Objectives page.
