# M-AI Học v279 — Grades 1–5 Primary Flow Rebuild

- Curriculum source: FINAL v19 Primary Normalized.
- Knowledge is hard-locked to **Vocabulary · Phonics · Sentence Patterns** only.
- 92 primary Units rebuilt.
- Each Unit has 10 Practice + 10 reserved Test items for each of the three Primary skills.
- Question Sage: 3 progressive, age-appropriate hints bound to each practice item.
- Knowledge Sage: concept-bound Teach / Explore; Quick Quiz remains fail-closed when a semantically unique authored quiz is unavailable.
- **Chơi với Sage is route-only everywhere** (Knowledge and Question Sage) and links to the shared Sage Games hub with grade/unit/skill context.
- Phonics: word/example audio uses English TTS; isolated phoneme audio is allowed only through the verified phoneme registry. IPA is never spoken by TTS.
- Core curriculum targets remain mastery/test eligible; no invented enrichment is silently assessed.
- Game level scenarios from the existing Primary shell are preserved while curriculum content/questions/Sage are rebuilt.

See `V279-PRIMARY-QA.json` for machine audit results.
