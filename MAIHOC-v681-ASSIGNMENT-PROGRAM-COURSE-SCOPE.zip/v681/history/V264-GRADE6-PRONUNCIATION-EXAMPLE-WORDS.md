# v264 — Grade 6 Pronunciation Example Words

Knowledge Pronunciation now renders a compact reference row for every target phoneme:
`/phoneme/ [speaker] as in word [speaker] · word [speaker] · word [speaker]`.

The example words come from the same University of Hamburg English-phoneme manifest used by the phoneme registry:
- /p/: play, happen, cap
- /b/: baby, double, tab
- /t/: tidy, flat, hint
- /d/: dust, dad, cuddle, bed
- /s/: speak, sun, hassle, mess
- /z/: zebra, hazelnut, houses, tease
- /ʃ/: sure, chic, fisherman, harsh
- /θ/: therapy, thing, tooth
- /ð/: there, feather, teething

Audio roles remain separate: phoneme speaker uses MAIHOC_PHONEME_AUDIO; example-word speaker uses the English word-audio/TTS path. Question Sage content is unchanged.
