# Grade 6 Content Revision v127

- Active runtime: `student/my-school-english/grade6/engine/bank-data.js` + `lesson-data.js`.
- Replaced artificial vocabulary examples with natural, unit-specific English.
- Removed curriculum-source labels from student vocabulary cards.
- Rebuilt Grammar distractors as concrete grammatical/morphological errors instead of placeholder meta choices.
- Rewrote Sage coaching to use the actual answer/evidence/rule for Vocabulary, Pronunciation, Grammar, Listening and Reading.
- Converted Speaking and Writing bank items to genuine open-response tasks. Practice and Test now use record/text response UI and are explicitly not auto-graded.
- Removed stale Grade-6 copies embedded under Grade 1 from canonical flow by renaming them `.legacy.json`.
- Synced active Grade 6 bank to canonical JSON copies.
