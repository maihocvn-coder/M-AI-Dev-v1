# v249 Universal History & Scoped Recovery

- Settings > History is available to every role and shows the user's own activity timeline.
- Safe recoverable actions expose Restore directly.
- Unsafe/conflicting recovery automatically creates a Restore Request.
- Management Admin handles organization-scoped requests; Super Admin can handle platform-wide requests.
- Deletes use recovery snapshots/tombstone semantics for supported business entities; Class deletion is wired into the recovery engine.
- Restore never rewinds protected learning/financial data: submissions, grades, attendance, attendance confirmations, transactions, and progress.
- Recovery records both original actor and recovery actor.
- Newer data is preserved; ambiguous ID/dependency conflicts escalate instead of overwriting.
