# V559 — Canonical MainScreen Liquid

- MainScreen (`.game-shell.mse-main-screen`) is the single responsive authority.
- Responsive observer now measures MainScreen itself, not `#scene`; hidden Learn/Test scene can no longer report 0px and collapse responsive state.
- Publishes both `--mse-main-w` and `--mse-main-h`, plus width state (`phone/narrow/compact/medium/wide`) and height state (`short/medium/tall`).
- Play bottom stack, character, answer holders, feedback, and Sage size from MainScreen geometry.
- Three answer holders stay on one horizontal row; only answer payload internals reflow on narrow screens.
- Expanded Sage prefers 430×440 but fits within smaller MainScreens; body scrolls instead of changing panel size with content.
- No curriculum, question bank, Sage coaching, reward, movement, or mode/controller logic changed.
