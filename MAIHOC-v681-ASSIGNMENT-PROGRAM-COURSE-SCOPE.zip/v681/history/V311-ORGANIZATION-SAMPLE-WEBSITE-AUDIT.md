# V311 Organization Sample Website Flow Audit

## Locked flow
- Organization website template is a **Sample Organization** template, not a real-looking Sunshine organization.
- External website example is `https://yourwebsitename.com`.
- Each organization has a unique **M-AI Học Name** (`maiName`) used as its public website slug.
- Free-name generation: normalized first 8 alphanumeric characters + four-digit sequence, e.g. `sample0001`.
- Public display URL: `https://maihoc.com/organization/{maiName}.html`.
- Internal organization ID remains separate from the public M-AI Học Name.
- Editing the sample invokes `ensureOrgCopy()` and creates organization-scoped draft/published storage. Changes do not modify the shared sample template or another organization's site.

## Fixed public-site structure
1. Navigation
2. One large image-only Hero/Header (drag/reposition in editor)
3. Exactly three boxes beneath the Hero (image/video)
4. Editable About Us
5. Editable Contact

## Media behavior
- Header is image-only and supports drag/reposition.
- Three boxes support images, YouTube/Vimeo links, and direct MP4/WebM/Ogg.
- YouTube uses a thumbnail/play-link fallback in the static/local prototype to avoid displaying an Error 153 iframe.

## Automated regression
- V311 website flow: 15/15 PASS
- V310 locked UX: 14/14 PASS
- Impersonation role isolation: 7/7 PASS
- Direct-page impersonation isolation: 19/19 PASS
- JS syntax checks: PASS for V311 website and Organization Admin home runtimes.
