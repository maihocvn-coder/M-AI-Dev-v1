# V598 — Persistent Park World Authority

Audit fix for v597. The travel park is now the persistent renderer during both idle and travel. Arrival commits the destination park segment as the current stationary scene instead of clearing the travel track and revealing the legacy world. The next transition starts from that committed segment and pans to the next generated park segment.
