# v369 Grade 1 landing + icon bag repair

- Scope intentionally limited to Grade 1 first.
- Selecting a Grade 1 level now opens the game landing/instruction state before question 1.
- Landing identifies the selected Level, engine, visual-choice interaction, icon collection, bag, coin, and Sage.
- Existing Grade 1 visual answer choices are preserved.
- One shared `visualIconForOption()` maps the visible answer word to the same visual reward icon.
- Correct answer rewards store/render icons in Adventure Bag rather than answer text.
- Legacy text entries in the Grade 1 bag are normalized to visual icons on read.
- Correct icon animates toward the Adventure Bag.
- Grade 1 game JS/CSS cache-busted to v369.
