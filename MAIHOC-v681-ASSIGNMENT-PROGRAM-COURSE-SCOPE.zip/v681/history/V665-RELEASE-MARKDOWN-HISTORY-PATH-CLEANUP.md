# v665 — Release Markdown History Path Cleanup

- Canonical release-note path is now `history/V###-*.md`.
- Moved all version markdown files that had leaked into the project root into `history/`.
- Added `config/release-artifacts.json` as the path policy.
- Added `tools/release-history.js` to resolve/move/audit release notes.
- Root `V###-*.md` files are not allowed.
- Product/runtime behavior is unchanged from v664.
