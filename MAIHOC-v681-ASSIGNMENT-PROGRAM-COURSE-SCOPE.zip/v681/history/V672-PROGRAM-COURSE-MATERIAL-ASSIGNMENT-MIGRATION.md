# v672 — Program → Course learning workflow migration

## Canonical structure
Organization → Program → Course. Course contains Modules, People, Assignments, Gradebook, Calendar. Module is an internal course organizer, not a third administrative level.

## Retired teacher-facing authorities
- Classes
- My Library
- Organization Library
- Create Worksheet / Create Test / CEFR builders
- Copy-to-library requirement before assignment

Legacy entry routes redirect to Courses or M-AI Learning Library so old links do not dead-end.

## Material authority
One M-AI Learning Library. M-AI School English and M-AI CEFR default to FREE. Materials are referenced by materialId + revision when assigned; assignment does not duplicate source content.

## Assignment authority
Library → Assign and Course → Module → Assign material converge on MAIHOC_LEARNING_WORKFLOW.assign(). Recipient may be whole course or selected students. Assignment stores availability and due date. Extension model supports course-wide or individual student overrides.

## Course model
Course supports program, start/end date, class time, teacher, TA(s), students, modules, assignments, gradebook, and calendar projection.

## Follow-up backend integration
The current package remains a local/demo front-end architecture. Server persistence, real account rosters, notification delivery, and production-grade automatic grading should bind to these canonical contracts rather than creating parallel UI authorities.
