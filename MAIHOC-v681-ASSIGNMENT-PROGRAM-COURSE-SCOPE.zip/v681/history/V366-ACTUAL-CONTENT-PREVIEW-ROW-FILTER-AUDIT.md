# V366 — Actual-content preview, row-open, filter alignment

- School English table thumbnail now embeds the actual grade learning route in a scaled, non-interactive iframe miniature instead of drawing a synthetic G1/G2 card.
- School English Full Preview embeds the same actual learning route at full preview size.
- CEFR worksheet/test miniature uses the real first prompt and real answer choices from the canonical resource data; no generic book/file icon.
- Resource rows have delegated click handling so clicking preview/title/row opens the resource; the three-dot menu stops propagation.
- Canonical M-AI menu removes direct Assign. It offers Full Preview and Copy to My Library, with helper text: “Copy it first to edit and assign.” Organization mode also offers Copy to Organization Library.
- Canonical full preview repeats the copy-first explanation.
- Type/Level/Focus filter checkbox rows use a fixed checkbox column + aligned label column; entire option row remains clickable.
- JS syntax checked. ZIP integrity checked. Browser E2E not run in this environment.
