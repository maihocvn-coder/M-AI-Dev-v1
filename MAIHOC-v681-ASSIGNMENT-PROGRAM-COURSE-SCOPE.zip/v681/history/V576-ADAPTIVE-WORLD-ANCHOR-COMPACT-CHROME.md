# V576 — Adaptive World Anchor + Compact Chrome Cleanup

- Removed the legacy 72px reserved site-header grid row while the game curtain is active. The curtain arrow/breadcrumb no longer sits below an empty white header band.
- Wide Play geometry: bottom stack uses the MainScreen bottom HUD line (12px), matching collapsed Sage bottom alignment. Controller therefore returns to the bottom instead of floating high in the world.
- Narrow/phone Play geometry: bottom stack remains content-anchored from Answers + live character-relative gap, preventing width-only narrowing from pushing the character down through newly created vertical space.
- Bottom remains a collision/safety clamp in compact layouts.
- No new stylesheet or versioned CSS file was added; changes replace the existing canonical liquid rules/runtime.
