# V258 — Grade 6 Editorial Natural-English Review

Scope: Grade 6 only. Curriculum identity, LO IDs, vocabulary targets, pronunciation targets, grammar targets and skill targets remain locked.

## Source-of-truth repairs
- Reviewed all 1,680 canonical Grade 6 bank records across 12 units × 7 skills.
- Repaired canonical JSON and runtime bank together; no runtime-only text masking.
- Rewrote Grammar meta prompts into learner-facing contexts.
- Rewrote Vocabulary prompts so sentence completion and Vietnamese-meaning items use natural instructions.
- Removed instructional/meta stimulus from Pronunciation questions.
- Standardized Listening instruction to a concise student-facing prompt.
- Removed answer-revealing Sage language and rebuilt Hint 1/Hint 2 without naming the answer.
- Quick Quiz now points to a different question ID in the same learning target when a peer exists; it never says “try this same question again”.
- Added/verified `knowledgeTargetId`, `audioRole`, `publishable`, and editorial-review metadata on every question.

## Knowledge editorial repairs
- Preserved all curriculum LO/skill targets.
- Corrected Unit 1 Grammar examples so affirmative, negative and question examples match their headings.
- Corrected Reading display targets to match the actual approved reading texts instead of stale/generated titles.
- Corrected Unit 1 Speaking display target to match the actual task (“A normal school day”).
- Marked Grade 6 lesson records as editorially reviewed without changing LO IDs.

## Sage/data integrity
- Corrected the student Grade 6 Sage-bank mirror, which was incorrectly carrying Grade 5 data, by synchronizing it to the canonical Grade 6 Sage bank.
- Canonical question Sage no longer contains “Đáp án phù hợp là …” before submission.

## Release checks
- Meta prompts: 0
- Answer-leaking Sage patterns: 0
- Old same-question Quick Quiz prompt: 0
- Visible Grammar-rule leakage patterns: 0
- Same-ID Quick Quiz: 0
- Questions with editorial review metadata: 1,680 / 1,680
- Questions with LO ID: 1,680 / 1,680
- Questions with Knowledge target ID: 1,680 / 1,680

Editorial note: distractors may intentionally contain plausible learner grammar errors because the task is to discriminate the target form; machine-garbage artifacts and answer-sign markers are not acceptable distractors.
