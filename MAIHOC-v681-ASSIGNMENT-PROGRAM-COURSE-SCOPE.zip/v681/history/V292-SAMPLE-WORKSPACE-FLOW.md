# v292 Sunshine Sample Workspace

Sunshine is explicitly SAMPLE data. It includes 1 Organization Admin, 1 Management Admin, 2 Teachers, 2 Students, 1 Parent, connected class/course/progress and computed analytics.

Rules: sample edits use a working copy; Reset restores baseline; Create My Organization clones to a new ownership graph; sample people/history are opt-in and remain marked sample/training-only; Management/Super can save a new sample revision; published sample is never overwritten.
