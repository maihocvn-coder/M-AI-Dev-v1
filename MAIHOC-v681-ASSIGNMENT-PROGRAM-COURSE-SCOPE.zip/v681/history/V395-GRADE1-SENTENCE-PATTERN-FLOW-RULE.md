# Grade 1 Sentence Patterns Flow Rule v1

Applies to Grade 1 Sentence Patterns Knowledge.

Knowledge is the complete lesson; Sage is support only.

Flow: Meaning & use → Key words → Listen & repeat → Choose for situation → Swap name/word → Your turn.

Student-facing bans: curriculum/meta wording (Unit, communicative pattern, slot/noun), generic “Dùng mẫu câu này để giao tiếp trong chủ đề của Unit”, and role labels such as “Người nói”.

Sage flow: meaning/use → needed vocabulary/name → guided combination → retry current activity.
