# v353 Resource Library integration audit

## Fixed
- Resource Library now registers two canonical program collections: **M-AI School English** and **M-AI CEFR**.
- Removed the user-facing `gamebook-mse` collection label from the current Resource Library UI; School English resources use the `mse` collection ID and display **M-AI School English**.
- Added **420 M-AI CEFR Question Bank** records to Question Banks.
- Added **7 M-AI CEFR level tests**, 20 questions each, to Tests.
- Added **70 M-AI CEFR worksheets**, 10 per CEFR level, to Worksheets.
- Collection filters display human-readable program names rather than internal IDs.
- Resource preview now handles questions, tests, and worksheets instead of assuming every resource is a question.

## Data checks
- CEFR question records: 420.
- CEFR level tests: 7; each contains 20 questions.
- CEFR worksheets: 70.
- Levels: Pre-A1, A1, A2, B1, B2, C1, C2.

## Scope
This fixes Resource Management / Learning Resources visibility. It does not merge M-AI CEFR curriculum with M-AI School English; they remain separate canonical collections.
