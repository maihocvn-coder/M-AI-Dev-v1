# v379 Grade 1 runtime/data contract repair

Root cause found in v377/v378: `bank-data.js` had been regenerated directly from the canonical question bank. The canonical question bank contains questions but not the Grade 1 engine `levels` metadata. `game.js` requires `bank.levels` during boot and returns immediately when it is absent. That exactly produces the observed state: default Level 01 header, empty Level Map, blank question area, and dead controls. Cache busting in v378 could not repair a missing runtime data contract.

Repairs:
- Restored all 16 Grade 1 engine level metadata records while preserving the v377 audited 960-question bank.
- Added a game boot guard that restores Grade 1 level metadata if a future question-bank sync accidentally drops `levels` again.
- Hardened Continue resume selection: it now chooses the newest snapshot matching Grade 1 + requested Level + mode instead of letting a stale resume snapshot from another Level shadow the homepage activity.
- Preserved v377 listening/audio question fixes.
- Cache-busted Grade 1 runtime/data to v379.

Tests run before packaging:
- Node syntax check: game.js PASS; bank-data.js PASS.
- Runtime data contract: 16 levels PASS; 960 questions PASS; every Level 1–16 has at least 30 playable Grade 1 questions across Vocabulary, Phonics, Sentence Patterns PASS.
- Level 8 specifically: 30 playable questions + complete level metadata PASS.
- Homepage Continue contract: Grade 1 supports 16 levels and generates `resume=1` PASS.
- Resume selector rejects stale snapshots from a different level/mode PASS.
- Audio-choice audit remains intact: all detected audio-choice records have `audioPrompt` PASS.
- Browser E2E was attempted with the container Chromium but Chromium does not complete headless startup in this environment, so no browser-E2E claim is made.
