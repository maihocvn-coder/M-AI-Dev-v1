# V318 Role Ownership Audit

## Change
- Removed Organizations Browser from Organizational Admin function set.
- Organizations Browser is owned by Management Administration via `organizations.manage`.
- Organizational Admin retains organization-scoped functions only: People, Teachers, Courses & Classes, Assignments & Gradebook, Attendance, Organization Analytics, Organization Website, Organization Settings, Organization Payroll (subject to ACL).
- Management Admin retains cross-organization browse/search and organization context selection.

## Audit
- PASS: `org.sample` no longer exists in governance function registry.
- PASS: `organizations.manage` is in `management` section and links to Organizations Browser.
- PASS: Organizational Admin section contains 9 organization-scoped functions in registry (before ACL filtering).
- PASS: Organizations Browser route remains available to Management Admin/Super Admin through authority rules.
- PASS: Vietnamese/English exact-match labels remain available for Organizations Browser and its description.
- PASS: JavaScript syntax checks passed for governance and i18n scripts.
- Learning/resource content was not modified by this role-ownership patch.
