# v373 Grade 1 — Welcome + all-level visual renderer

- External Grade 1 entry shows the single welcome/instruction landing before questions.
- Internal Level Map routes keep `start=1` and open the selected level directly.
- Removed the `state.unit===1` visual-choice restriction.
- Every Grade 1 Play item whose options can be mapped to meaningful visual objects renders icon + text in the game scene.
- Sentence options resolve concrete nouns (for example `I have a car.` -> 🚗).
- Correct visual object is collected into Adventure Bag.
- When scene choices are active, duplicate prompt/options below the scene are hidden.
- Text/audio fallback remains for choices without a meaningful visual mapping.
