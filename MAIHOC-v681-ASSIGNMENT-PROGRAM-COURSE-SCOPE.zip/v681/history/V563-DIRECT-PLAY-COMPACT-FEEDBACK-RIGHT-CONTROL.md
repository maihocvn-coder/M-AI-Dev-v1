# V563 — Direct Play + Compact Feedback + Right Controller Repair

- Grade 1 engine entry now initializes in `play` mode regardless of a previously saved Knowledge mode. Learn/Test remain available from Học & Chơi.
- Feedback overlay reduced to a compact centered toast (max 260px wide, 54–72px high).
- Root cause addressed for the on-screen right controller: Sage launcher had a higher stacking layer in the same bottom-right HUD region. Sage is moved above the controller stack and the controller row/buttons receive the winning pointer hit-zone.
- Keyboard ArrowRight logic is unchanged because it already maps correctly to `move(5)`.
- No question bank, reward, Sage tutoring, answer-holder, or curriculum changes.
