# M-AI Học v309 — Organization Website Builder Audit

Rebuilt the Organization Website flow around four explicit components: Header, Featured Boxes, About Us, and Contact.

## Release gates
- Header is image-only and supports drag-to-reposition with persisted X/Y focal position.
- Featured section is a fixed 2/3/4-box component (default 3), not a generic content-row builder.
- Featured boxes accept image, YouTube, Vimeo, or direct video media.
- About Us and Contact have working field editors and Save Draft behavior.
- Organization Settings supports organization-name updates, multiple external websites, M-AI Học site slug, availability checks, free generated slugs, paid custom slugs, and prior-slug aliases.
- Draft and published website states are separate.
- Edit/preview mode is role guarded using the effective impersonated role.
- v308 impersonation regression: PASS 7/7 roles.
- v308 direct-page impersonation access: PASS 19/19 cases.
- v309 Website Builder contract audit: PASS 14/14.

Note: the older v307 website contract test intentionally fails three checks because it asserts the retired generic content-row implementation. v309 replaces that contract with the explicit Featured Boxes model requested for this release.
