# v634 — Canonical Content + Config + Sage Architecture

## Runtime authority
Context is the key. Grade config is data only. `MAIHOC_GAME_CONFIG.resolve(context)` is the single gameplay selection API used by the shared runtime. Engine/world/character/carrier/reaction implementations remain reusable assets in their registries.

## Content authority
`MAISCHOOLENGLISH.select({grade, unit, skill, pool, surface})` returns the selected canonical content package. Content selection is independent of gameplay selection.

Content owns learning truth:
- Knowledge
- Question Bank
- Sage contracts attached to Knowledge/Question
- learning asset references

Practice/Game/Test/Worksheet are consumers/surfaces of canonical content, not separate content authorities.

## Sage
`MAIHOC_SAGE_SERVICE` resolves Sage from the selected content. Each Knowledge/Question can carry a `sageContract`. Existing authored Sage is normalized into a contract when a contract is not yet physically authored.

Sage Core is deterministic and can run without AI tokens. `needsAI()` is the boundary for a future AI personalization layer; AI must remain constrained by content/LO/correct-answer/tested-distinction/contract.

## Grade 1 preservation
Grade 1 declares only context on the page. The controller consumes central content/config authorities. The old `game-config-data.js` per-unit engine assignment is no longer loaded by the Grade 1 page.

Frozen movement and reaction files were not edited.

## Deferred cleanup
`game-registry.js` remains as the current Admin persistence/control-plane store and asset catalog during migration. `game-config-data.js` remains in the repository for other unmigrated grade pages but is not a Grade 1 runtime authority. Remove/migrate those only when Grades 2–12 are moved to the universal frame.
