# v295 Content / Resource Separation

- Content Studio now manages website/app pages only.
- Learning Resources manages question banks, worksheets, tests, slide decks, games, learning materials and custom categories.
- Programs own Curriculum Truth; resources may map to Program/Curriculum/LO or remain general.
- M-AI School English remains a built-in curriculum program.
- Audit exposes Page Content and Learning Resources scopes.
- Analytics exposes Page Analytics and Resource Analytics scopes.
- Create, upload, sample download, resource edit, preview, download, category creation and program creation controls are wired.
