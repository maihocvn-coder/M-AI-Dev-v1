# V635 Universal School English Frame — Grades 1–12

- Grades 1–12 boot the shared `school-english-controller.js`.
- Grade identity is supplied through `MAIHOC_SCHOOL_ENGLISH_CONTEXT`.
- Canonical content resolves through `MAISCHOOLENGLISH.select(context)`.
- Grade-specific Knowledge globals are resolved by grade inside the content authority.
- Gameplay resolves through Grade Config + `MAIHOC_GAME_CONFIG.resolve(context)`.
- Removed grade-local `engine/game.js` for Grades 2–12.
- Removed runtime `game-config-data.js` after all grades migrated.
- Fixed Knowledge context to use the active grade instead of Grade 1.
- Grade 1 movement/reaction implementation files were not edited.
- Root cleanup: version/history notes moved to `history/`, QA/regression artifacts to `history/qa/`, obsolete backups to `archive/`.
