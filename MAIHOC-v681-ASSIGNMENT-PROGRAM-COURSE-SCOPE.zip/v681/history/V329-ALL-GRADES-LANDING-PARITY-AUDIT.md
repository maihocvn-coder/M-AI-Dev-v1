# V329 — All Grades Landing Parity Audit

## Requirement
Every M-AI School English Grade must open to the same **Học & Chơi orientation/landing state** used by Grade 6. It must not immediately render Vocabulary / Question 1 merely because an old URL contains `mode=play`.

## Root cause found
The v328 shared entry controller treated any URL containing `mode=knowledge|practice|play|test` as an explicit activity launch. Older Grade links/runtime history can contain `mode=play` without the student actually choosing **Chơi Level** in the current visit. That allowed Grades such as Grade 3 to bypass the orientation screen and render Question 1 immediately.

## V329 contract
- A Grade runtime opens the landing/orientation page unless `start=1` or an assignment launch is present.
- `mode=play` alone no longer bypasses the landing page.
- Landing copy/layout is shared across Grades 1–12 and follows the Grade 6 model:
  - BẮT ĐẦU
  - Chào mừng em đến với Học & Chơi!
  - Em muốn bắt đầu ở đâu?
  - Level-map guidance
  - Sage guidance
  - Chơi Level N
  - Học kiến thức
- The persistent left rail still exposes all four choices: Học kiến thức / Luyện 10 câu / Chơi Level / Bài luyện kiểm tra.
- Choosing an activity adds `start=1`; only then does the actual Knowledge/Practice/Play/Test runtime begin.
- Choosing a Level on the Level Map changes the selected Level and remains on the landing page; it does not auto-launch Question 1.
- Assignment launches remain direct runtime launches.

## Scope audit
- Grade 1 play.html: v329 controller present — PASS
- Grade 2 play.html: v329 controller present — PASS
- Grade 3 play.html: v329 controller present — PASS
- Grade 4 play.html: v329 controller present — PASS
- Grade 5 play.html: v329 controller present — PASS
- Grade 6 play.html: v329 controller present — PASS
- Grade 7 play.html: v329 controller present — PASS
- Grade 8 play.html: v329 controller present — PASS
- Grade 9 play.html: v329 controller present — PASS
- Grade 10 play.html: v329 controller present — PASS
- Grade 11 play.html: v329 controller present — PASS
- Grade 12 play.html: v329 controller present — PASS

## Safety
No curriculum/question/Knowledge/Sage bank content was rewritten in this change. The change is limited to the shared Grade-entry/orientation controller and its references in Grade play pages.

## Verification
- `node --check assets/js/maihoc-grade-entry-v329.js` — PASS.
- 12/12 Grade play pages reference `maihoc-grade-entry-v329.js?v=329` — PASS.
- Browser click-through is not claimed by this audit.
