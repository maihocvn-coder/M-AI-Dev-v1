# v359 Unified Library UX Flow Audit

Implemented from v358 baseline.

## UX flow
- Learning Library opens My Library first for teachers; Organization Library first for organization admins.
- Persistent discovery banner links to M-AI Library and states M-AI resources are currently free.
- M-AI Library resources use icon/thumbnail cards and Full Preview.
- Canonical M-AI resources are read-only.
- Teacher canonical actions: Full Preview, Copy to My Library to Edit, Assign as-is.
- Organization admin canonical actions: Full Preview, Copy to My Library, Copy to Organization Library, Assign as-is.
- Owned copies expose Full Preview, Save, Assign, Duplicate, Delete.
- CEFR Test/Worksheet owned editor exposes Add Question, Edit Question, Remove, Maximum points, completion coins (0–10), duration and attempts.
- Assignment dialog exposes due date, duration, maximum points, completion coins and attempts.
- Game-local EN/VI switch beside coin removed from Grades 1–12; interface language remains global navigation responsibility.
- Teacher/admin resource page source markup is English-only; VI/EN UI translations are added through the global i18n dictionary rather than mixed hard-coded labels.

## Preview contract
- Icon preview is the default resource-card presentation.
- Full Preview resolves CEFR question IDs into real prompts, choices and correct answers.
- M-AI original must be copied before editing.

## Static checks
- Resource Studio JS syntax: PASS.
- Global i18n JS syntax: PASS.
- Grade 1–12 game.js syntax: PASS.
- No local `id="lang"` game button remains in Grade 1–12 play.html.

Browser click-through was not executed in this environment.
