# v382 Grade 1 CSS consolidation audit

Scope: Grade 1 game Adventure Bag CSS.

Removed obsolete competing implementations from v85, v88, v91, v92, v375, v376, and v381, including corner-mini, free-drag, left/right full-row, and collapsed positioning variants.

Canonical contract now lives in one section at the end of `student/my-school-english/grade1/engine/game.css`:
- Bag is always inside the game scene, top-right.
- Expanded state is a compact horizontal row.
- Collapsed state remains top-right and shows only the newest collected icon plus title/count controls.
- No draggable/corner/left variants remain in CSS.
- Mobile keeps the same top-right ownership and only reduces spacing/coin visibility.

`setupPrimaryAdventure()` in game.js already removes legacy movement/dock classes at runtime; this remains as defensive cleanup for old DOM/local state.

Validation:
- Grep audit confirms one canonical `#adventurePouch` positioning block.
- `node --check game.js` passes.
- play.html cache keys bumped to v382.

Final cleanup also removes the obsolete `.pouch-movable`, `.pouch-free`, `.pouch-free-drag`, and `.dock-*` helper rules, so legacy movement classes cannot reposition the Grade 1 bag even if stale markup appears.
