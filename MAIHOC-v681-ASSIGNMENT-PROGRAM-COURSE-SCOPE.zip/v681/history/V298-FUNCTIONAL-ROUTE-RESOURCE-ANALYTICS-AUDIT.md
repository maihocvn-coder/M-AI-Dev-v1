# V298 Functional Route / Resource Audit

Acceptance chain: visible control → real destination/action → meaningful content/state → save/cancel → history/restore where mutation is material.

Implemented:
- Ready/approved routes to Content Release; System oversight routes to Platform Health. Compatibility route pages added.
- Management Admin attention cards receive destinations.
- Feature Control Cancel restores page-open state.
- Organization plans retained; Individual Plans added for Teacher, Student and Parent. Student/Parent Basic Free defaults stay enabled; future paid definitions default OFF. Individual plan toggles create history.
- Analytics pages gain custom From/To dates and comparison modes (previous period/day/month/year). No historical growth is fabricated; snapshots accumulate from v298 forward.
- Resource Audit actions collapsed to three-dot menu; Approved has visible check; sort control added.
- Resource Preview has breadcrumb/context and direct Edit, Approve, Send to Review, History and Close actions.
- Compatibility destinations prevent known dead Ready/approved and System oversight routes.
