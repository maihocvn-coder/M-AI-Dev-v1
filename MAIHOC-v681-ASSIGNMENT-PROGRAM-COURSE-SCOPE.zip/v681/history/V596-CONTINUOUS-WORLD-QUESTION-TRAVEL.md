# v596 — Continuous World + Question Travel

Baseline: v595 GAME-AUTO-TRAVEL-PROTOTYPE.

## Canonical change
- Replaced five on-screen character checkpoints with a stable character travel anchor.
- Correct answer keeps the existing reward/coin sequence, then character walks in place while the world track pans.
- The next question is rendered as an object inside the incoming world segment, so scenery and question enter the viewport together.
- The incoming question is non-interactive during travel. After world arrival, the canonical controller advances and renders/activates the real next question.
- Wrong answers do not travel and retain the existing Sage/retry flow.
- Travel is owned by shared World Transition + Character Movement; question content only supplies the next question payload.
- No new version-specific CSS/JS runtime file was added; the current canonical files were edited in place.

## Files changed
- assets/js/game/world/world-transition.js
- assets/js/game/character/character-movement.js
- assets/js/game/core/school-english-controller.js
- assets/css/maischoolenglish.css

## Verification
- Modified JS files pass node --check.
- Old five-checkpoint/wrap travel code is absent.
- ZIP integrity checked after packaging.
- Browser animation is not claimed browser-verified in this environment.
