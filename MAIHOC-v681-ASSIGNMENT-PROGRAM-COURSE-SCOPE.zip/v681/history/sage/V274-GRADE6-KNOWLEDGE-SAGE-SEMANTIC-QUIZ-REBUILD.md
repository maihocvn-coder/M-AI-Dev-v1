# v274 Grade 6 Knowledge Sage — Semantic Quiz Rebuild

## Changes
- Removed free-text Knowledge Sage ask input/button. Explore uses authored semantic prompts only.
- Removed neighbor-example MCQ fallback that could create multiple semantically correct answers.
- Knowledge Quiz now accepts authored quick checks or explicitly verified semantic grammar MCQs only.
- Added fail-closed UX: unverified concepts do not publish a generated MCQ.
- Added verified tense-definition distinctions for Present Simple, Present Continuous, and Past Simple.
- Corrected question-form concept leakage in tense feedback/notice text.

## Semantic MCQ contract
Every published MCQ must have an explicit learning target, tested distinction, one keyed answer, unique options, and distractor reasons. Structural validation runs at runtime; release QA rejects the old neighbor-example fallback.

## QA
- 356 Knowledge concepts scanned.
- 72 authored quick checks structurally validated.
- Present Continuous screenshot regression: PASS.
- Free-text Knowledge Ask absent: PASS.
- Neighbor-example distractor fallback absent: PASS.
- v270 Question Bank whole-item semantic audit: 1680/1680 PASS.
- v268 runtime flow: PASS.
- v273 semantic language audit: 356 concepts / 2306 utterances / 1082 Explore questions PASS.
- JS syntax: 145 files / 0 errors.
