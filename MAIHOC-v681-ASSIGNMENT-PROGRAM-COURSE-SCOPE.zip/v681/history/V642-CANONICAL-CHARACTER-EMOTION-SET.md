# v642 — Canonical Character Emotion Set

Universal semantic emotion attachment layer for School English G1–12.

Canonical visible states: happy, excited, sad, cry, surprised, confused, dizzy, celebrate, plus super-celebrate for perfect completion.

Semantic mapping:
- correct on first try -> excited
- correct after retry -> happy
- first wrong -> sad
- repeated wrong (2+) -> confused
- correct but carrier miss -> surprised
- obstacle bump -> dizzy
- level complete -> celebrate
- perfect level -> super-celebrate

All effects attach to the character's inner artwork / overlay layer only. The outer character root remains owned by character-movement.js. No jump/contact/carrier lifecycle code was changed.
