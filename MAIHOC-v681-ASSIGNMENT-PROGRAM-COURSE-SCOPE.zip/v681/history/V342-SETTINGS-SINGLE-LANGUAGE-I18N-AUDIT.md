# v342 Settings single-language / VI-EN audit

- Settings source UI normalized to Vietnamese as the canonical/default visible language.
- Removed bilingual labels such as `Mã QR của tôi · My QR code`; canonical label is `Mã QR của tôi`.
- Normalized Settings tabs, Profile/Avatar, Connections, Schedule, Security, Appearance, Notifications, Language and History labels/buttons to one language.
- Added VI↔EN dictionary pairs for the newly normalized Settings strings so the shared VN/EN selector can translate them.
- Preserved technical identifiers, localStorage keys, IDs, URLs, email, QR, M-AI and Sage names.
- Preserved the canonical Add/Connect Person relationship flow from v341.
- JS syntax check: PASS.
- Static mixed-label audit for Settings: PASS for known bilingual labels.
- ZIP integrity checked after packaging.
- Browser click-through not claimed.
