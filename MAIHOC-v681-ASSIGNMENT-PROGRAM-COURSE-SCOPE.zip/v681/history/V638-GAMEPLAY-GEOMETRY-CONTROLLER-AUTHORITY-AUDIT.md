# V638 Gameplay Geometry + Controller Authority Audit

## Root causes found
1. `game-ui-runtime.js` created `#g1v475Controls` only when `usesG1Sample()` was true. Grades 2–12 therefore had no controller mount even though the shared `character-movement.js` was loaded.
2. `maischoolenglish.css` still contained a second Grade 2–12 absolute-position authority for `.mse-game-character` and `.mse-game-controls`.
3. `maihoc-responsive.css` already owns the canonical bottom stack (`.mse-play-bottom-stack`) for character + controller. The second authority could compete with that measured geometry and detach the character/controller from the bottom HUD.

## Repair
- Universal Frame now creates exactly one `#g1v475Controls` mount for Grades 1–12.
- `character-movement.js` remains the single action/controller renderer and movement authority.
- Removed the redundant Grade 2–12 absolute character/controller positioning rules from `maischoolenglish.css`.
- `maihoc-responsive.css` bottom-stack rules remain the single geometry authority.
- Cache-busted `game-ui-runtime.js` and `character-movement.js` includes to v638 on Grade 1–12 pages.

## Frozen behavior
`character-movement.js` implementation was not edited. Grade 1 v617 jump/contact behavior remains untouched.

## Static QA
- All JS under assets/js and student/my-school-english: node --check PASS.
- Grade 1–12 play pages load game-ui-runtime.js?v=638.
