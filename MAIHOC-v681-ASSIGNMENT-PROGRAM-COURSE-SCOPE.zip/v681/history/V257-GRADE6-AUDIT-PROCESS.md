# M-AI Học Grade 6 Master Build, Audit & Repair Process — v257

1. Lock curriculum truth: Unit/topic/LO/vocabulary/pronunciation/grammar/listening/reading/speaking/writing targets are immutable during content repair.
2. Review grade-equivalent public references for difficulty only; never copy protected exercises/textbook content.
3. Build/repair Knowledge first; every Knowledge section maps to Unit + skill + LO + knowledgeTargetId.
4. Audit Knowledge Sage against the current concept.
5. Build/repair the canonical Question Bank from locked curriculum + approved Knowledge.
6. Run hard question quality gate: META_QUESTION, UNNATURAL_ENGLISH/editorial review, ANSWER_LEAK, AMBIGUOUS_ANSWER, GENERIC_SAGE_HINT, INVALID_AUDIO_ROLE, KNOWLEDGE_COVERAGE_GAP. Repair canonical source immediately; do not hide source defects in the renderer.
7. Build audio by explicit role (phoneme, word, example, listeningPrompt, speakingPrompt, model, readAloud). IPA must never be sent to TTS. Actual playback is a separate runtime QA gate.
8. Build/rebuild Question Sage only after the question is final; Sage must bind to questionId and knowledge target.
9. Cross-content review: Curriculum → Knowledge → Knowledge Sage → Bank → Question Sage.
10. Assemble Practice/Game/Test/Worksheet only from approved canonical bank items.
11. Game experience QA: Welcome is never blank; level selection, rewards, bag and Sage state are coherent.
12. Full runtime journey: fresh and returning student; navigation, audio, Q transitions, Sage rebind, reload persistence.
13. Editorial quality review: natural English, age appropriateness, accuracy, instructional usefulness and student experience. Automated validation does not replace editorial review.
14. Release/freeze only after hard gates and runtime journey pass. Grade 6 freezes before propagation to other grades.

## v257 benchmark note
Public Grade 6 Global Success Unit 1 summaries were reviewed only for scope/difficulty signals (school vocabulary, pronunciation, present simple/adverbs of frequency and four-skill work). British Council LearnEnglish Teens A1–A2 reading/listening organization was reviewed as a general learner-level complexity reference. M-AI Học content remains independently authored.
