# V607 Grade 1 Jump/Catch + Air Carrier Audit

- Grade 1 now forces the same action policy for all 12 levels: base horizontal movement + Jump. Later level action progression remains available to Grades 2–12; Grade 1 does not inherit Fly/Climb/Swim/Dive/etc.
- Grade 1 active carrier pool contains only airborne carriers: butterflies, dragonfly, bee, and birds. Ground/tree species are not selected for Grade 1.
- Carrier vertical offsets vary deterministically by question and option so carriers are not a rigid horizontal row and change heights on the next question.
- Canonical character movement now owns Jump & Catch: keyboard Jump catches a horizontally reachable carrier near the jump apex; clicking/tapping a carrier moves the cat beneath it and performs the same jump/catch path. Audio-button clicks are excluded from catch handling.
- Correct Grade 1 carrier is collected at contact rather than flying into the cat after the answer has already been caught.
- Every Grade 1 carrier answer badge exposes audio. It first delegates to the canonical hidden option-audio control (preserving phoneme-specific audio behavior); when no canonical option-audio exists, it speaks exactly the text displayed on that carrier through MAIHOC_TTS.
- Controls guide tells Grade 1 learners to move under the answer carrier and use Up/Space to jump and catch; Up+Right / Up+Left remains supported through held horizontal input.
- Existing authorities were edited in place: game-config.js, character-movement.js, game-ui-runtime.js, maihocschoolenglish.css. No version-specific runtime override file was added.
