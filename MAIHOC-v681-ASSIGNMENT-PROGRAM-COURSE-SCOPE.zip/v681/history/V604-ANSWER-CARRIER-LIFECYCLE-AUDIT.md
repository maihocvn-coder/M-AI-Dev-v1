# V604 — Answer Carrier Lifecycle Consolidation

- Audited v603 before changing behavior.
- Removed the old click behavior where the cat ran/jumped to the answer holder.
- Consolidated all active grade play pages onto `assets/js/game/character/character-movement.js`; sample-cat is no longer an active loader authority.
- Question/answer rendering remains owned by `game-ui-runtime.js` and the proven canonical question contract.
- Replaced the single front-facing butterfly emoji with a code-drawn SVG carrier library: butterfly plus nine side-profile bird variants (bluebird, robin, sparrow, finch, canary, swallow, hummingbird, chickadee, dove).
- Carrier facing is calculated toward the character and mirrored by one canonical facing rule.
- New question sets enter from ahead with staggered flight.
- Correct answer lifecycle: selected carrier flies to character -> disappears/collects -> other carriers exit -> existing reward/coin authority runs -> only then existing delayed character walk/world pan runs.
- Carrier is screen/gameplay interaction UI and is not attached to the world travel track, so it cannot travel with the cat/world.
- Existing seamless park path geometry from v603 is retained.
