# M-AI Học i18n + Content Classification Contract — v584

## Core rule
Language switch changes interface language, navigation, instructions, and explanations. Explicit English learning content remains English.

## Semantic HTML / tags
- `<nav data-i18n-scope="navigation">...</nav>` — navigation; always follows VI/EN.
- `data-i18n-scope="ui"` — non-navigation interface chrome; always follows VI/EN.
- `data-content-type="instruction"` — learner/user instructions; follows VI/EN.
- `data-content-type="explanation"` — explanatory teaching/support text; follows VI/EN.
- `data-content-type="english" data-language-lock="true" lang="en"` — English learning material; NEVER changes when UI language changes.

## Recommended next content taxonomy
Use stable content IDs separately from language:
- instruction
- explanation
- english (target-language material)
- example-english
- question-prompt
- answer-option
- transcript
- pronunciation-model
- vocabulary-item
- grammar-form
- reading-passage
- writing-prompt
- sage-coaching

For each content object also store `language`, `translationPolicy`, `skill`, `loId`, and `contentId`. English target material should use `translationPolicy: locked`; instructions/explanations should use `translationPolicy: ui-language`.

## v584 implementation
- One physical canonical runtime: `assets/js/maihoc-i18n.js`.
- One physical canonical catalog: `assets/js/maihoc-i18n-catalog.js`.
- HTML references to v316-v326 i18n runtimes/catalogs are removed and replaced with the canonical pair.
- Existing `<nav>` elements are explicitly tagged as navigation scope.
- School English Grade 1-5 game Journey/Mode/Level Map navigation is tagged semantically.
- Added exact UI translation for `Chơi & Luyện` ↔ `Play & Practice` and related Grade game chrome.
- Site-shell profile menu no longer hard-codes mixed `English / Vietnamese` labels.

## Migration rule
Legacy learning-content protection remains temporarily so v584 does not accidentally translate existing English lesson/question content. During the later content pass, migrate each content block to an explicit `data-content-type` and remove legacy blanket protection only after classification QA.
