# V584 — Canonical i18n + semantic language/content classification

- Consolidated versioned i18n runtime/catalog references into `assets/js/maihoc-i18n.js` and `assets/js/maihoc-i18n-catalog.js`.
- Removed physical versioned i18n runtime/catalog files v316–v326 after migration.
- All HTML pages load the canonical i18n pair once.
- All existing semantic `<nav>` regions are tagged `data-i18n-scope="navigation"`.
- Grade 1–5 School English Journey, mode navigation, Level Map and readiness navigation are classified as navigation UI.
- Added `Chơi & Luyện` ↔ `Play & Practice` and related School English chrome translations.
- Removed mixed bilingual profile labels from the canonical site shell.
- Added classification contract for `navigation`, `ui`, `instruction`, `explanation`, and locked `english` content.
- Kept legacy learning-content protection temporarily; learning content migration is deferred to the content pass.
