# v661 Standalone Homepage Demo

- Replaces the authenticated Grade 6 iframe with a standalone homepage-only demo.
- No dependency on student login, Grade pages, progress, Level Map, School English routing, or post-login state.
- 10 curated non-pronunciation questions: Vocabulary, Grammar, Reading.
- Each question has three Sage coaching hints tied to the exact tested distinction.
- Cat + simple Jump/left/right presentation lives only inside the homepage demo.
- This demo intentionally does not write progress, coins, mastery, wallet, or user state.
- Canonical Student Home remains `student/home/home.html`.
