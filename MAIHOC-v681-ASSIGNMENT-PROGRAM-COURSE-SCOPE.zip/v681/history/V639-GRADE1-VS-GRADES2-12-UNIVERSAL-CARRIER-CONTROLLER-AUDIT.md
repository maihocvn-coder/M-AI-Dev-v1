# v639 — Grade 1 vs Grades 2–12 Universal Carrier/Controller Audit

## Root cause found
Grade 1 was not fully represented by the Universal Frame DOM contract. Grade 1 play markup contained `#catchLane`; Grades 2–12 did not. `maihoc-responsive.js::fitGame()` requires `#scene`, `.mh-world-question`, `#catchLane`, and `.mse-play-bottom-stack`; without the lane it exits before setting `--mse-bottom-stack-top` and character row geometry. This left the shared character/controller stack without its measured anchor on Grades 2–12.

A second split remained in `game-ui-runtime.js`: Grade 1 used `renderAnswerCarriers()`, while Grades 2–12 used `renderGenericWorldAnswers()`. Therefore Grade 1 was only partially universal; the page shell was shared, but the carrier presentation/runtime contract was not.

## Canonical repair
- `mountPlayRows()` now guarantees the same `#catchLane` mount for every Grade 1–12.
- `renderAnswerCarriers()` is shared by every grade for MCQ questions.
- Carrier lane supports 1–4 options; Grade 1's existing 3-option behavior remains unchanged.
- Generic world answer buttons are only a fallback for non-MCQ/open-response surfaces, not a Grade 2–12 authority.
- Shared bottom stack owns Character + Controller for every grade.
- `character-movement.js` resolves config through `MAIHOC_GAME_CONFIG.resolve({program,grade,unit})` and requests responsive geometry sync after painting controls/character.
- Grade 1 and Grades 2–12 all expose the same `mse-game-character` / `mse-game-controls` runtime hooks.
- v617 jump/contact algorithm was not rewritten.

## Side-by-side result
All Grade 1–12 `play.html` files load the same v639 game UI runtime and character movement runtime. No grade-local `engine/game.js` is present. Grade 1 keeps its static lane markup; Grades 2–12 receive the identical canonical lane from Universal Frame bootstrap.
