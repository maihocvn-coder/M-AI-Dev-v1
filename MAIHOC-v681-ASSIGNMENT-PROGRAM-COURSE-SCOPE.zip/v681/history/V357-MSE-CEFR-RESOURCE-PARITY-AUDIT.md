# V357 — M-AI School English ↔ M-AI CEFR Resource Parity Audit

Scope: find every user-facing place where M-AI School English learning resources are exposed for use, excluding game play/engine surfaces, then place M-AI CEFR in the equivalent location when the resource model applies.

## Canonical rule
M-AI School English and M-AI CEFR are separate curricula/resource banks but peer sources for teacher/admin resource use.
- School English hierarchy: Grade → Unit → Learning Objective → Skill.
- CEFR hierarchy: CEFR Level → Skill → Content Target.
- Shared resource types: Question Bank, Tests, Worksheets, assignments/copies, analytics/resource management.
- Excluded from parity: School English Game Book / game engines and student grade game pages. CEFR is not represented as a Game Book.

## Audited resource-use surfaces

| Surface | School English before | CEFR before | V357 result |
|---|---|---|---|
| Teacher left navigation / Course Tools | Direct M-AI School English entry | Missing direct peer entry | Added direct **M-AI CEFR** entry |
| Teacher Question Banks / learning library | School English browse | CEFR secondary button existed | Both retained as peer sources |
| Teacher Resources / Resource Studio | School question bank, tests, worksheets | CEFR seeds existed | Verified peer Question Banks / Tests / Worksheets |
| Teacher Test Builder | School source | CEFR source | Verified dual-source curriculum selection |
| Teacher Worksheet Builder | School source | CEFR source | Verified dual-source curriculum selection |
| Teacher Course quick actions | Browse M-AI School English | Missing | Added **Browse M-AI CEFR** |
| Teacher Create Course curriculum | School English Grades 1–12 | Missing | Added CEFR Pre-A1–C2 options |
| Teacher course empty assignment guidance | School English only | Missing | Updated to School English or CEFR |
| Super Admin Question Bank | School canonical bank | CEFR link existed | Verified peer bank access |
| Admin Learning Resources / Resource Library | School collection | CEFR collection existed | Verified peer collection and filters |
| Admin Resource Analytics | School English program selector | Missing | Added **M-AI CEFR** selector |
| Program Resource Registry | School English hierarchy only | Missing | Added CEFR hierarchy + shared resource scope |

## Deliberate exclusions
- Student M-AI School English grade/game pages.
- Game Book / game engine resources and game preview links.
- School English Knowledge/Sage runtime content where there is no CEFR equivalent yet.
- Curriculum Truth authoring pages that are specifically the School English curriculum source. CEFR has its own Truth Table and target matrix contract.

## Required parity behavior
When a teacher is choosing learning material rather than entering a game, School English and CEFR must be visible as peer source choices. Selecting one changes only the curriculum filters, never the resource workflow:

Source → Scope → Resource Type → Preview → Copy/Use → Assign/Create

School English scope = Grade → Unit → LO → Skill.
CEFR scope = Level → Skill → Content Target.

Question text is not duplicated between banks. Tests and worksheets retain references to the correct source bank.
