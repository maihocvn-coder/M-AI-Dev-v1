# v375 Grade 1 Continue + Answers + Compact Bag

- Student Home Continue now marks the route as resume and opens the saved level directly; welcome is reserved for explicit `welcome=1` entry.
- Grade 1 visual choices remain in the game scene, while the full answer choices are restored below the scene.
- Adventure Bag is a compact single row at the top of the scene, collapsed by default and expandable/collapsible.
- Bag no longer occupies a large fixed block over scene choices.
