# V571 — Two-anchor no-overlap game geometry

- Replaced v570 vertical fit algorithm.
- Width reflow can change answer-holder height but cannot move Character/Controller/Sage downward.
- Question/answers are top-anchored; Character/Controller are bottom-anchored; only the world band between them flexes.
- Character row height is measured from the live character; no version-specific character height is assigned by the responsive runtime.
- Sage bottom anchor is derived from live controller/Sage dimensions and clamped inside MainScreen.
- Removed critical vertical geometry ownership (`--mse-answer-top`, bottom-stack height, character height, Sage bottom) from `maischoolenglish.css`; canonical geometry lives in `maihoc-responsive.css` + `maihoc-responsive.js`.
- Canonical responsive runtime now owns `mh-game-site-curtain-enabled` directly. `maihoc-site-shell.js` only handles curtain interaction/open-close.
- Game liquid chrome selector no longer depends on breadcrumb/title direct-child placement.
- When game is compact, breadcrumb and level title are removed from the live layout before MainScreen fit is evaluated.
