# V526 — Delete legacy responsive authorities

Baseline: v525.

## Consolidation
- Deleted legacy fixed/viewport Sage authorities that competed with MainScreen geometry.
- MainScreen remains the only named responsive container (`mse-main`) and uses `container-type:inline-size`.
- Answer Holder no longer relies on hard 3/2/1 column breakpoint ownership. Its canonical lane uses intrinsic CSS Grid `auto-fit/minmax`, so holders progressively reflow from horizontal to fewer columns to a vertical stack based on available MainScreen width.
- Sage open/collapsed geometry is bounded by MainScreen container units (`cqw`) and narrow rules keep it inset from both sides.
- Removed the obsolete generic-frame 800px responsive block that separately resized Sage/layout.
- Canonical school-English rail split uses a fluid rail width (`clamp(220px,25vw,320px)`) before the canonical narrow navigation transition.
- No changes to curriculum, question/Sage content, rewards, world art, game engine, character facing, or navigation behavior.
