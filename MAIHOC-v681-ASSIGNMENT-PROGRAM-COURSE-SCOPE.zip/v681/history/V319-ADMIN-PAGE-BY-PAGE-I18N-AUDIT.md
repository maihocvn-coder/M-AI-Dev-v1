# V319 — Admin Vietnamese UI Completeness Audit

## Release rule
- Default UI language: Vietnamese (`vi`).
- VN/EN toggle remains available and restores English system UI.
- Learning/resource content is protected from UI translation.
- Proper names, organization/school names, book/resource titles, URLs, IDs, slugs, filenames and code remain unchanged.

## Terminology decision
- Save → **Lưu / Lưu thay đổi**.
- Cancel → **Hủy**.
- Archive Course → **Ngừng sử dụng khóa học** (avoids confusion between “Lưu” and “Lưu trữ”; records are preserved).
- Missing course name → **Khóa học chưa đặt tên** in Vietnamese / **Untitled Course** in English; raw `undefined` is not rendered by the course list.

## Screenshot regressions fixed
- `No classes yet.` → `Chưa có lớp học.`
- `Open / Edit` → `Mở / Chỉnh sửa`.
- `Favorite` → `Yêu thích`; `Navigation` → `Điều hướng`; `Homepage` → `Trang chủ`.
- Settings cards and descriptions: Academic, Teaching & Staffing, Notifications, Integrations, Roles & Permissions, Plan & Usage, Security & Data and their helper text are covered.
- Course page actions, labels, statuses, confirmation text and empty states are covered.

## Whole-admin audit
- Admin HTML pages inspected: **81**.
- All admin pages load `maihoc-i18n-v319.js`: **PASS**.
- Whole-site HTML pages loading v319 i18n: **378/378**.
- Dynamic DOM is translated by MutationObserver.
- Admin alert/confirm/prompt messages now pass through the same UI translator.
- Non-resource Admin pages have a Vietnamese UI fallback for common system vocabulary, so newly generated labels do not silently remain English merely because an exact dictionary entry is missing.
- Resource/content-heavy Admin routes keep the conservative protected-content boundary; only explicit UI dictionary entries are translated there.

## Content safety
- Compared JSON/MD/TXT/CSV files against v318: **293 checked, 0 changed**.
- Learning/resource content protection remains enabled.

## Syntax / packaging
- `node --check assets/js/maihoc-i18n-v319.js`: **PASS**.
- Course list missing-name fallback: **PASS**.

## Browser-test limitation
A Playwright package and Chromium executable are present, but this environment blocks navigation to both localhost and file URLs with `ERR_BLOCKED_BY_ADMINISTRATOR`. Therefore this release was source/static/runtime-logic audited, but a real Chromium click-through could not be completed in this environment.
