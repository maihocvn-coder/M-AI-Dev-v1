# v658 — Homepage hero embedded demo

- Restores the old homepage hero copy/layout.
- Places the existing real 10-question M-AI School English demo in the original right-side preview area.
- Removes the duplicate standalone demo section below M-AI School English.
- Demo remains Cat + Jump & Catch + Sage coaching, using the canonical game runtime.
- Desktop: hero copy left, playable demo right.
- Phone/tablet: demo moves below hero copy as a full-width playable block; no squeezed two-column layout.
- No changes to game movement, question, Sage, world, mascot, or Student Home behavior.
