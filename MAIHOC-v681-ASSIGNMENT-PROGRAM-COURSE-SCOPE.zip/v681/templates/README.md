# M-AI Học page template

Every new HTML page loads `assets/css/maihoc-universal-theme.css` and `assets/js/maihoc-universal-theme.js`, with paths relative to its own directory. This is the single shared theme contract. The default is Sky, and the persisted theme key is `maihoc.student.theme` for all roles and pages. `MAIHOC.setTheme(name)` changes the whole site on this browser; valid names are `sky`, `forest`, `coral`, `violet`, `sun`.

Role-specific pages also load their navigation shell: `student/assets/student-shell.css` and `student-shell.js` for Student, `assets/css/role-shell.css` and `assets/js/role-shell.js` for Teacher, Parent and Admin. Account and public pages get the universal header/breadcrumb directly from the universal script. Build components using `--mh-primary`, `--mh-dark`, `--mh-soft`, `--mh-bg`, `--mh-line` and `--mh-text`; preserve separate topic colors only for illustrated game scenes. Do not use a role-specific theme storage key.

A new page example inside `student/new-feature/home.html`:

```html
<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>New Feature | M-AI Học</title>
<link rel="stylesheet" href="../assets/student-shell.css"><script defer src="../assets/student-shell.js"></script>
<link rel="stylesheet" href="../../assets/css/maihoc-universal-theme.css"><script defer src="../../assets/js/maihoc-universal-theme.js"></script>
</head><body><main><h1>New Feature</h1></main></body></html>
```

The common shell adds navigation and breadcrumb automatically. Parent, Teacher and Admin pages follow the same rule with their role shell.

## Shared appearance and account controls

All 209+ HTML pages use the single root universal theme CSS and JavaScript. The system-wide Sky theme and optional PNG/JPEG/WebP icon can be set by an authenticated Admin at `admin/appearance/home.html` through `GET/POST /wp-json/maihoc/v1/appearance`. Personal themes override the default in this browser. The brand logo returns to root `index.html`. The avatar menu routes to the role's My Space, Account Settings, Billing placeholder, and WordPress logout. Account photo and personal theme in the ZIP are browser-local; server account photo sync and payments need dedicated account/payment infrastructure.

## Family linking

An authenticated Student creates or revokes a 24-hour one-use family invite at `student/space/home.html`; a Parent scans the locally rendered QR or enters the code at `parent/my-family/home.html`. Both can remove their active link. Family endpoints live in `includes/maihoc-settings-family.php` and require WordPress login and REST nonce for writes. Directly opening static HTML from the ZIP cannot connect two users; the UI reports when the server is unavailable. WordPress authentication is required for protected endpoints.

## Tạo trang mới từ shell

Tạo một trang theo đúng shell, breadcrumb và CSS chung bằng lệnh:

```bash
python3 tools/new_page.py --role student --slug new-feature --title "Tính năng mới"
```

Có thể chọn `student`, `teacher`, `parent` hoặc `admin`. Công cụ không ghi đè trang đã có. Thêm đường dẫn vào navigation của vai trò tương ứng nếu trang cần hiện trên thanh menu. Đừng đặt `header`, breadcrumb hoặc màu cố định trong nội dung trang: shell tự dựng chúng, và thiết kế thẻ lấy từ CSS chung. Bộ kiểm tra `tools/audit_shell.py` phát hiện trang thiếu tài nguyên shell, đường dẫn gãy và breadcrumb trùng trước khi đóng gói.
