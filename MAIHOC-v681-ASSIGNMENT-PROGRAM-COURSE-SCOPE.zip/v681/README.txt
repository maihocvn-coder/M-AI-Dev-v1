M-AI HỌC — MASTER PLATFORM PACKAGE v1.0

SOURCE OF TRUTH
- Architecture: Master Architecture & Build Spec v4.
- Folder baseline: M-AI-Hoc-Grade6-ADAPTIVE-WALLET structure.
- Visual system: canonical Grade 6 Unit 1 Sage Green design.
- Logo: exact M-AI Học homepage logo code copied from canonical Unit 1 v14.
- WordPress owns registration/login/logout/password/session/wp_users.ID. No second authentication system.

POST-LOGIN FLOW
WordPress Login → account/portal/home.html Role Gateway → Student/My Space | Parent/My Family | Teacher/My Teaching | Admin Portal. Role selection is NOT another login.

DATABASE FOUNDATION
Plugin activation creates M-AI tables for profiles, family links, programs, courses, classes, enrollment, teacher assignments, lessons, live sessions, presence, assignments, submissions, grades, learning events, mastery, wallet ledger, recordings, teacher time and notifications. All people reference WordPress user IDs.

WORDPRESS PAGE SHORTCODE
Create WordPress pages and use [maihoc_page path="account/portal/home.html"] or the appropriate path. This injects REST nonce/config while keeping templates reusable.

TEMPLATES INCLUDED
- Authenticated Role Gateway
- Student My Space, My Journey, School English, Schedule, Programs, Live Learning, Notifications
- Grade 1–12 landing dashboards; Grade 6 Unit 1 is canonical v14; other Units are structural shells
- Skills Boost and Explore course landing templates with Unit 1, Unit 2, Unit 3... labels only
- Parent My Family dashboard
- Teacher My Teaching dashboard + assignment form + lesson workspace shell
- Admin Portal + Courses + Live Operations + Payroll + Content Library

IMPORTANT
Do not rename/replace Unit 1 content blindly. New Units must be curriculum-mapped and independently authored. Course grade and adaptive mastery remain separate.


VISUAL BASELINE v2: Common pages are built from the Grade 6 landing-page design language in M-AI-Hoc-Grade6-ADAPTIVE-WALLET(5).zip. Grade 6 itself is preserved from that package. WordPress owns authentication; M-AI pages consume wp_user identity and M-AI REST data.


V2 — SCHOOL ENGLISH + TEACHER PLATFORM FRAMEWORK (2026-09-23)
- Current product focus: Student School English + always-available M-AI games + teacher-assigned work.
- Teacher can own/create classes, invite students, and invite a student's parent by email/code.
- Teacher Content Bank supports printable/assignable worksheets and assigning M-AI game Units.
- Gradebook foundation supports auto-graded assignments; students have My Assignments + My Grades.
- My Programs is designed for both M-AI-created programs/classes and teacher-created classes.
- Admin Feature Control Center provides feature flags so unfinished/future modules remain OFF until enabled.
- Initial defaults: Student Experience ON; Teacher, Parent, Live, Commerce, Skills Boost, Explore, Advanced OFF.
- Reporting foundation: any reportable question/content can POST to /report-content; reusable maihoc-reporting.js adds “Report this question” to elements marked data-reportable.
- Admin Reported Content queue and Visual Content Editor shells are included for future database-backed editing.
- Content revisions table provides audit/version foundation.
- This package builds the architecture/framework; email delivery, production WYSIWYG persistence, full auto-grading engine, and game-specific question binding still require implementation/integration.


V3 STUDENT LANDING / ROLE ROUTING
- Public homepage is separate from logged-in student landing.
- M-AI Hoc Learn -> Login/Create Account -> multi-role selector -> role landing.
- Student landing dynamically hydrates current unit and active program; primary navigation is M-AI School English + My Programs.


ACCOUNT ACCESS
Sign in with an existing WordPress account. The plugin does not create a default account or assign multiple roles automatically. Static local files can display pages and run browser-only game interactions; server-backed family links, teacher classes, editing and publishing need WordPress and the plugin endpoints.


LOCAL DEMO ACCOUNT
Username: demo
Password: demo
Roles: Student, Teacher, Parent, Admin. This local-only shortcut is intercepted by account/login/home.html and does not replace WordPress production authentication.

MODULAR CONTENT UPDATE
- Replace one grade only with tools/grade_module.py. Shared navigation/account/teacher/gradebook files remain outside the grade module.
- Add/bulk assignment banks as JSON under data/assignments/. Validate with tools/assignment_module.py. No navigation edit is required.
- Grade 6 follows Smart Game Engine Design v12: separate Knowledge/Practice/Level Play/Test evidence, teacher assignments, and floating/dockable Sage.
