# M-AI Học Question Bank Plug-in Contract v37

Game frame is independent from curriculum bank. Each Excel row becomes one question. Required columns:
`grade, unit, id, lo, skill, pool, engine, prompt, option_a, option_b, option_c, option_d, answer, sage_1, sage_2, sage_3, explanation_vi, explanation_en, stimulus, version`

- `answer` is A/B/C/D or 0/1/2/3.
- `pool`: practice or test.
- `engine`: catch, shoot, route, jump, build, collect, detective, sound, fix.
- Sage belongs to the same row/question. Test-reserved rows should use pool=test and Sage is hidden by runtime.
- Curriculum/Level visual design remains in `curriculum-map.json`; Excel replaces question content only.

Run: `python tools/import-question-bank.py path/to/question-bank.xlsx`
This writes each Grade's `question-bank.json` plus engine `bank-data.js` while preserving Level/game configuration.
