#!/usr/bin/env node
/* Canonical release-note path authority.
   Usage:
     node tools/release-history.js path V665-NOTE.md
     node tools/release-history.js move V665-NOTE.md
     node tools/release-history.js audit
   Version markdown belongs ONLY in /history. */
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');
const HISTORY = path.join(ROOT, 'history');
const VERSION_MD = /^V\d{3}-.+\.md$/i;
function ensureHistory(){ fs.mkdirSync(HISTORY,{recursive:true}); }
function safeName(input){
  const name=path.basename(String(input||''));
  if(!VERSION_MD.test(name)) throw new Error('Release note must match V###-*.md');
  return name;
}
function canonical(input){ ensureHistory(); return path.join(HISTORY,safeName(input)); }
function rootNotes(){ return fs.readdirSync(ROOT).filter(n=>VERSION_MD.test(n)); }
const [cmd,arg]=process.argv.slice(2);
if(cmd==='path'){
  console.log(path.relative(ROOT,canonical(arg)).replace(/\\/g,'/'));
}else if(cmd==='move'){
  const name=safeName(arg); const src=path.join(ROOT,name); const dst=canonical(name);
  if(!fs.existsSync(src)) throw new Error(`Root release note not found: ${name}`);
  fs.renameSync(src,dst); console.log(path.relative(ROOT,dst).replace(/\\/g,'/'));
}else if(cmd==='audit'){
  const bad=rootNotes();
  if(bad.length){ console.error(`FAIL: ${bad.length} release note(s) at root:\n${bad.join('\n')}`); process.exit(1); }
  console.log('PASS: no V###-*.md release notes at project root; canonical path is history/.');
}else{
  console.error('Usage: node tools/release-history.js <path|move|audit> [V###-NAME.md]'); process.exit(2);
}
